/********************************************************************
 ********** COPYRIGHT (c) 2024 by Joe Haas DBA FF Systems   *********
 *
 *  File name: srec.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for S-record processing.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    04-12-24 jmh:  Adapted to Tiva FFPGMR
 *    11-05-13 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

// S-rec defines
#define SRSTART 	'S'
#define IRSTART 	':'
#define SRS_NULL 	0
#define BCMD_BUFLEN 48						// max length of bcmd line
#define	RAM_START	0

//#define  RAM_START     0x0000				// base address of external RAM
//#define  RAM_LEN       0x8000				// length of RAM window in bytes

// process_data() cmds: (also used in process_srx())
#define	PD_QERY 0x00			// querry status
#define	PD_QERYH 0x01			// querry fail addr H
#define	PD_QERYL 0x02			// querry fail addr L
#define	PD_QEMBED 0x03			// do nothing with data
#define	PD_INIT 0x10			// init vars (IPL), defaults to VRFY mode
#define	PD_STOR	0x11			// set store mode
#define	PD_VRFY	0x12			// set verify mode

// process_data() modes:
#define	PD_WR	0x01			// store data mode
#define	PD_CMP	0x00			// compare data mode

// process_data() status:
#define	PD_OK	0x00			// status OK (no compare errors)
#define	PD_VERR	0x01			// verify compare error
#define	PD_WERR	0x02			// write compare error

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------

char process_srx(U8 dmode, char* obuf, U16* offset);		// get and process S or I record file
char* pass_bcmd(void);										// return pointer to bcmd buffer
char ram_pattern_pass(void);
void put_byte(U8 d);
U8 process_data(U16 addr, U8 d, U8 dmode);
//char	toupper(char c);
void process_stx(U32 addrstart, U32 addrstop, U8 addr24, U8 source);
U32 put_sline(U8 source, U32 addr, U8 len, U8 rectype);
