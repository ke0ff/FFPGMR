/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  BUS I/O Fns
 *
 *******************************************************************/

// generally required includes
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "typedef.h"

// application-specific includes
#include "inc/tm4c123gh6pm.h"
#include "init.h"						// App-specific SFR Definitions
#include "tiva_init.h"

//==========================================================================
// BUS I/O Fns

// Local variables/Fn defines
void	wait_lat(void);


//==========================================================================


//=============================================================================
// put_addr() drives address to target
//=============================================================================
void	put_addr(U32 addr){

	GPIO_PORTB_DIR_R = 0xff;					// portb = output
	GPIO_PORTB_DATA_R = (U8)addr;
	GPIO_PORTC_DATA_R |= LAT_AL;				// pulse addr low latch
	wait_lat();
	GPIO_PORTC_DATA_R &= ~LAT_AL;
	GPIO_PORTB_DATA_R = (U8)(addr>>8);
	GPIO_PORTC_DATA_R |= LAT_AH;				// pulse addr high latch
	wait_lat();
	GPIO_PORTC_DATA_R &= ~LAT_AH;
	if(addr & 0x10000L){						// set/clear A16
		GPIO_PORTC_DATA_R |= A16;
	}else{
		GPIO_PORTC_DATA_R &= ~A16;
	}
	return;
}

void	wait_lat(void){
	volatile U8	i;

	for(i=0; i<250; i++);
	return;
}

//=============================================================================
// dataio() does a bus read/wr
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	dataio(U32 addr, U8 data, U8 dir){
	U8	d=data;

	put_addr(addr);
	if(dir){
		GPIO_PORTB_DIR_R = 0xff;
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N;
		GPIO_PORTE_DATA_R &= ~(WE_N|WEDAT_N|CS_N|OE_N);
		GPIO_PORTB_DATA_R = d;
		wait(100); //!!!
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|CS_N|OE_N;
	}else{
		GPIO_PORTB_DIR_R = 0;
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N;
		GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);
		d = GPIO_PORTB_DATA_R;
		GPIO_PORTE_DATA_R |= CS_N|OE_N;
	}
	return d;
}

//=============================================================================
// dutpwr() turns on/off DUT power
//	1 = 0, 0 = off
//=============================================================================
void	dutpwr(U8 on){

	if(on){
		GPIO_PORTD_DIR_R &= ~(BZY);
		GPIO_PORTD_DATA_R |= VCCON;
		GPIO_PORTC_DATA_R &= ~LAT_OE_N;
	}else{
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|CS_N|OE_N|VPPFON_N|VPPON_N;
		GPIO_PORTD_DIR_R |= (BZY);
		GPIO_PORTD_DATA_R &= ~(VCCON|SKT28|SKTEE|BZY);
		GPIO_PORTC_DATA_R |= LAT_OE_N;
	}
	wait(200);
	return;
}
