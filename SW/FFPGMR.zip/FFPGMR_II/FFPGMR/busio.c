/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  BUS I/O Fns
 *
 *******************************************************************/

// generally required includes
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "typedef.h"

// application-specific includes
#include "inc/tm4c123gh6pm.h"
#include "init.h"						// App-specific SFR Definitions
#include "tiva_init.h"
#include "busio.h"
#include "cmd_fn.h"

//==========================================================================
// BUS I/O Fns

// Local variables/Fn defines
U8	bank_dev;							// if 0, device is a standard memory with all address lines available on pins
										// else, this register defines the address mask for A[23:16] which is transferred to
										// the device internal latch.
U8	bank_shft;							// # of right shifts to addr to align address to bank port
U8	lastbank;							// bank change reg... reduces execution time by only setting device bank if it changes
U32	lastaddr;

void	wait_lat(void);


//==========================================================================


//=============================================================================
// put_addr() drives address to target
//=============================================================================
void	set_dev(U8 dev, U8 shft){

	if(dev == 0xff){
		lastbank = 0xff;
	}else{
		bank_dev = dev;
		bank_shft = shft;
	}
	return;
}

void	set_addr(void){

	lastaddr = 0xfe000000L;
	return;
}

//=============================================================================
// wait_lat() cheesy GPIO settling delay
//=============================================================================
void	wait_lat(void){
	volatile U8	i;

	for(i=0; i<50; i++);
	return;
}

//=============================================================================
// put_addr() drives address to target
//=============================================================================
void	put_addr(U32 addr){
	U8	bank;
	volatile U8	i;

	if(lastaddr != addr){
		GPIO_PORTB_DIR_R = 0xff;					// portb = output
		if(bank_dev){								// if a banked device, write the internal bank register of the DUT
			// set internal bank register
			bank = (U8)(addr >> bank_shft) & bank_dev;
			if(lastbank != bank){
				lastbank = bank;
				GPIO_PORTB_DATA_R = bank;					// present bank bits to data port
				GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|OE_N;		// make sure these signals are inactive
				GPIO_PORTE_DATA_R &= ~(CS_N);				// enable DUT bus
				for(i=0; i<16; i++);						// cheesy settling delay
				GPIO_PORTE_DATA_R &= ~(WE_N|WEDAT_N);		// write data
				for(i=0; i<16; i++);						// cheesy settling delay
				GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|CS_N;		// clear bus
			}
		}
		GPIO_PORTB_DATA_R = (U8)addr;				// low addr byte
		GPIO_PORTC_DATA_R |= LAT_AL;				// pulse addr low latch
		wait_lat();
		GPIO_PORTC_DATA_R &= ~LAT_AL;
		GPIO_PORTB_DATA_R = (U8)(addr>>8);			// high addr byte
		GPIO_PORTC_DATA_R |= LAT_AH;				// pulse addr high latch
		wait_lat();
		GPIO_PORTC_DATA_R &= ~LAT_AH;
		if(!bank_dev){								// if not a banked device...
			if(addr & 0x10000L){					// set/clear A16
				GPIO_PORTC_DATA_R |= A16;
			}else{
				GPIO_PORTC_DATA_R &= ~A16;
			}
		}
	}
	return;
}

//=============================================================================
// dataio() does a bus read/wr
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	dataio(U32 addr, U8 data, U8 dir){
	volatile U8	d=data;
	volatile U8	i;

	put_addr(addr);									// set address
	if(dir == WR){
		// write/pgm
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|OE_N;		// failsafe the control lines for write
		GPIO_PORTB_DIR_R = 0xff;
		GPIO_PORTB_DATA_R = d;						// drive data port with data
		GPIO_PORTE_DATA_R &= ~(CS_N);				// select DUT
		for(i=0; i<4; i++);							// cheesy settling delay
		GPIO_PORTE_DATA_R &= ~(WE_N|WEDAT_N);		// set write
		for(i=0; i<16; i++);						// cheesy settling delay
		GPIO_PORTE_DATA_R |= WE_N;			// terminate write
		for(i=0; i<4; i++);							// cheesy settling delay
		GPIO_PORTE_DATA_R |= WEDAT_N|CS_N|OE_N;		// end cycle
	}else{
		// read
		GPIO_PORTB_DIR_R = 0;						// set port for read
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N;			// config control lines for read
		GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);
		for(i=0; i<16; i++);						// cheesy settling delay
		d = GPIO_PORTB_DATA_R;						// read data
		GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	}
	return d;
}

//=============================================================================
// fast_read() does a DUT read using the last address setup
//	assumes PortB & /WE are already configured for read
//=============================================================================
U8	fast_read(void){
	volatile U8	d;
	volatile U8	i;

	// read
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);			// enable read
	for(i=0; i<8; i++);							// cheesy settling delay
	d = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	for(i=0; i<8; i++);							// cheesy settling delay
	return d;
}

//=============================================================================
// fast_write() does a DUT write using the last address setup
//=============================================================================
void	fast_write(U8 d){
	volatile U8	i;

	// write
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTB_DATA_R = d;						// data for write
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~(WE_N);				// enable write
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= CS_N|WEDAT_N;			// end cycle
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	return;
}

//=============================================================================
// fast_pgm_vfy() does a FLASH pgm vfy cycle. Returns data read
//=============================================================================
U8	fast_pgm_vfy(U8 d){
	volatile U8	e;
	volatile U8	i;

	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	// PGM cmd
	GPIO_PORTB_DATA_R = PGM_101;
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~(WE_N);				// cycle write
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	// CS hi/low
	GPIO_PORTE_DATA_R |= CS_N;
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~CS_N;

	// PGM data
	GPIO_PORTB_DATA_R = d;						// data
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~(WE_N);				// cycle write
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= CS_N;
	for(i=0; i<DLYQ; i++);						// cheesy 10us delay
	// CS hi/low
	GPIO_PORTE_DATA_R &= ~CS_N;

	// PGMV cmd
	GPIO_PORTB_DATA_R = PGMV_101;
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~(WE_N);				// cycle write
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R |= CS_N;
	for(i=0; i<DLYQ; i++);						// cheesy 10us delay
	// CS hi/low
	GPIO_PORTE_DATA_R &= ~CS_N;

	// read data
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= WEDAT_N;				// end cycle
	GPIO_PORTE_DATA_R &= ~(OE_N);				// enable read
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	e = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~WEDAT_N;
	return e;
}

//=============================================================================
// byte_flash() does a flash write
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	byte_flash(U32 addr, U8 data){
	volatile U8	d=data;
	volatile U8	i;
	volatile U8	e;

	put_addr(addr);									// set address
	// write/pgm
	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	// PGM cmd
	dataio(addr, PGM_101, WR);

	// PGM data
	dataio(addr, data, WR);
	for(i=0; i<DLYQ; i++);						// cheesy 10us delay

	// PGMV cmd
	dataio(addr, PGMV_101, WR);
	for(i=0; i<DLYQ; i++);						// cheesy 10us delay

	// read data
	e = dataio(addr, 0, RD);
	for(i=0; i<CDLY; i++);						// cheesy settling delay
	GPIO_PORTE_DATA_R &= ~WEDAT_N;
	return e;
}

//=============================================================================
// dutpwr() turns on/off DUT power
//	1 = 0, 0 = off
//=============================================================================
void	dutpwr(U8 on){

	if(on){
		GPIO_PORTD_DIR_R &= ~(BZY);
		GPIO_PORTD_DATA_R |= VCCON;
		GPIO_PORTC_DATA_R &= ~LAT_OE_N;
	}else{
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|CS_N|OE_N|VPPFON_N|VPPON_N;
		GPIO_PORTD_DIR_R |= (BZY);
		GPIO_PORTD_DATA_R &= ~(VCCON|SKT28|SKTEE|BZY);
		GPIO_PORTC_DATA_R |= LAT_OE_N;
	}
//	wait(200);
	return;
}

//=============================================================================
// vpp() turns on/off VPP power
//	1 = 0, 0 = off
//=============================================================================
void	vpp(U8 on){

	if(on){
		GPIO_PORTE_DATA_R &= ~VPPON_N;
	}else{
		GPIO_PORTE_DATA_R |= VPPON_N;
	}
	wait(500);
	return;
}

//=============================================================================
// vppf() turns on/off VPPF power
//	1 = 0, 0 = off
//=============================================================================
void	vppf(U8 on){

	if(on){
		GPIO_PORTE_DATA_R &= ~VPPFON_N;
	}else{
		GPIO_PORTE_DATA_R |= VPPFON_N;
	}
	wait(500);
	return;
}

//=============================================================================
// skt() sets the socket config
//	28 = 28 pin, 0xee = eeprom, 0xe0 = no ee, 32 = 32 pin
//=============================================================================
void	skt(U8 id){

	switch(id){
	case 28:
		GPIO_PORTD_DATA_R |= SKT28;
		break;

	case 32:
		GPIO_PORTD_DATA_R &= ~SKT28;
		break;

	case 0xee:
		GPIO_PORTD_DATA_R |= SKTEE;
		GPIO_PORTD_DIR_R &= ~(BZY);
		break;

	case 0xe0:
		GPIO_PORTD_DATA_R &= ~SKTEE;
		break;

	default:
		break;
	}
	return;
}

// {eof}
