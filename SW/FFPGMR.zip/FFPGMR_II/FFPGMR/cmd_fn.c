/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: cmd_fn.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  CLI Command Interpreter
 *  
 *******************************************************************/

// generally required includes
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "typedef.h"

// application-specific includes
#include "inc/tm4c123gh6pm.h"
#include "init.h"						// App-specific SFR Definitions
#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "version.h"
#include "tiva_init.h"
#include "spi.h"
#include "busio.h"
#include "adc.h"
#include "srec.h"

//#include "lcd_test.h"

//===================================================================================================
// Command token syntax defines and instantiations.
//
// This is the define list for the command line tokens used in this CLI.  Each "CMD" define is a quoted string that
//	corresponds to the minimum typed command line token.  The "ENUM" define sets the token used in the parsing
//	switch.  The "CMD" defines are entered into an array of arrays with a terminating array of 0xff, eg:
//		char* cmd_list[] = { CMD_1, CMD_2, ... , "\xff" };
//	The "ENUM" defines are likewise entered into an "enum" statement, eg:
//		enum cmd_enum{ ENUM_1, ENUM_2, ... , ENUM_LAST };
//	The primary requirement is for the subscript numbers for the "CMD" and "ENUM" must be in matching order.
//		The list order of the CMD/ENUM defines establishes the search order.  Lower-indexed (left-most) items are
//		searched first.  This means that the least-ambiguous items should be included earlier in the list to prevent
//		situations whereby a command of "BT" is entered, but matches on "B" in the list because it was the first
//		encountered.  So, for this example, "BT" should be first in the
//
// cmd_type is adjusted to the number of tokens in the list:

#define	cmd_type	char	// define as char for list < 255, else define as int

#define	CMD_00		"nodev"			// device selects
#define	ENUM_00		dev00_cmd
#define	CMD_0A		"28c64"
#define	ENUM_0A		dev28_cmd
#define	CMD_0B		"28f101"
#define	ENUM_0B		devFL1_cmd
#define	CMD_0C		"27c011"
#define	ENUM_0C		devEP1_cmd
#define	CMD_0D		"27c256"
#define	ENUM_0D		devEP2_cmd
#define	MAX_DEV		5

#define	CMD_A0		"ad"			// adc test command ID
#define	ENUM_A0		adc_cmd

#define	CMD_B0		"bu"			// bus test command ID
#define	ENUM_B0		bus_cmd

#define	CMD_D0		"dev"			// device status
#define	ENUM_D0		dev_cmd

#define	CMD_D1		"dump"			// device status
#define	ENUM_D1		dump_cmd

#define	CMD_I0		"idump"			// intel hex dump
#define	ENUM_I0		idump_cmd

#define	CMD_M0		"mt"			// mem test
#define	ENUM_M0		mem_cmd

#define	CMD_O0		"off"			// vcc off
#define	ENUM_O0		vccoff_cmd
#define	CMD_O1		"on"			// vcc on
#define	ENUM_O1		vccon_cmd

#define	CMD_P0		"pgm"			// DUT PGM
#define	ENUM_P0		pgm_cmd

#define	CMD_S0		"sdump"			// srec dump
#define	ENUM_S0		sdump_cmd

#define	CMD_S1		"sload"			// srec dump
#define	ENUM_S1		sload_cmd

#define	CMD_S2		"sver"			// srec dump
#define	ENUM_S2		svfy_cmd

#define	CMD_T0		"te"			// sram test
#define	ENUM_T0		test_cmd

#define	CMD_97		"help"			// Alternate help syntax
#define	ENUM_97		help2
#define	CMD_98		"?"				// help list
#define	ENUM_98		help1
#define	CMD_99		"vers"			// version info
#define	ENUM_99		vers
#define	ENUM_LAST	lastcmd


char* cmd_list[] = { CMD_00, CMD_0A, CMD_0B, CMD_0C, CMD_0D, CMD_A0, CMD_B0, CMD_D0, CMD_D1, CMD_I0, CMD_M0, CMD_O0, CMD_O1, CMD_P0, CMD_S0, CMD_S1, CMD_S2, CMD_T0, CMD_97, CMD_98, CMD_99, "\xff" };

enum       cmd_enum{ ENUM_00, ENUM_0A, ENUM_0B, ENUM_0C, ENUM_0D, ENUM_A0, ENUM_B0, ENUM_D0, ENUM_D1, ENUM_I0, ENUM_M0, ENUM_O0, ENUM_O1, ENUM_P0, ENUM_S0, ENUM_S1, ENUM_S2, ENUM_T0, ENUM_97, ENUM_98, ENUM_99, ENUM_LAST };

// enum error message ID
enum err_enum{ no_response, no_device, target_timeout };

// device list
char		dev_list[MAX_DEV][7] = { {CMD_00}, {CMD_0A}, {CMD_0B}, {CMD_0C}, {CMD_0D} };

//===================================================================================================

//=============================================================================
// local registers

#define MAX_PRESP_BUF 80
char bcmd_resp_buf[MAX_PRESP_BUF + 10];
char* bcmd_resp_ptr;
U16	device_eprom_start;					// device parameter regs
U16	device_eprom_end;
U16	device_eeprom_start;
U16	device_eeprom_end;
U16	string_addr;						// string-parse next empty address
U16 sernum;								// serial number utility register
S8	device_eprom;
S8	device_eeprom;
U8	device_type;
S8	boot_len_fixed;
U16	device_max_bootlen;
U16	device_pprog;
char device_valid;
// HM-133 MFmic support
U8	hm_buf[HM_BUFF_END];				// signal buffer
U8	hm_hptr;
U8	hm_tptr;
U8	shftm;								// fn-shift mem register (MFmic)
char srbuf[STAT_BUF_LEN];				// status sending array
U8	key_count;
char key_hold;
U8	devid;								// current device ID ordinal
U32	device_maxaddr;						// device max address

//=============================================================================
// local Fn declarations

void get_BCD32(char *sptr, U32 *bcdval);
U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U32 params[ARG_MAX]);
cmd_type cmd_srch(char* string);
char do_cmd_help(U8 cmd_id);
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str);
void parse_ehex(char * sptr);
void disp_error(U8 errnum);
void disp_fail(char* buf, char* s, U16 c, U16 d);
void disp_wait_addr(char* buf);
U16 boot_se(U8* bptr, U16 start, U16 end, U16 ppaddr);
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a);
void disp_error_log(U8* lbuf, U16 len);
void do_help(void);
void disp_esc(char flag);
U8 sto_nvmem(U8 band, U8 memnum, char* sptr);
char* char_srch(char* sptr, char searchr);
U8 str_chks(char* sptr);
U32 dpl_calc(U16 dplcode);
U8 cadd(U16 dplcode, U8 index);
void putOK(U8 tf);
void dump_mem(U32 addrb, U32 addre, U8 dut, char* obuf);
void	dump_str(U8* data);
void	pgm_dut(U32 srt, U32 end, U8 dev_id);

//=============================================================================
// CLI cmd processor entry point
//	Somewhere in the application, there must be a constant polling for input characters or end of
//		line signal.  The goal is to produce a command line array that was terminated by an EOL
//		(ASCII 0x0d).  This array is passed through parse_args() before calling x_cmdfn().  The
//		base command line array and the args arrays are maintained elsewhere in the application
//		(usually in main.c).
//	Uses number of args (nargs) and arg pointer array (args[]) to lookup command and dispatch to
//		a command-specific code code block for execution.
//
//	offset is srecord offset value which is maintained in main() and passed
//	forward for the srecord functions (upload), if used.
//
//	Note that the original command line array is "chopped up" by parse_args() by replacing
//		whitespace characters with null-terminators (unless brackets by quotes, as described below).
//
//	"Switch" operands, such as "-C", are processed here.  These switches set flags and are then
//		removed from the parameter arrays, so that the subsequent command code doesn't have to
//		try and filter them out.  If a switch is included in a parameter field for a command that
//		does not interpret it, the switch flag is simply ignored.
//
//	get_Dargs() (get decimal args) converts ASCII numbers into integer values and is called from
//		each individual parser so that "no-parameter-entered" defaults can be established.  To
//		enforce these defaults, first initialize the params[] array with the default values, then
//		call get_Dargs().
//
//	whitespace() defines what ASCII characters are white-space parameter separators used to separate
//		parameters within the command line array.  Multiple, consecutive whitespaces are allowed and
//		are filtered out by parse_args().
//	quotespace() defines what ASCII characters are to be used as quotes inside the parameter field.
//		Quotes allow character strings which contain whitespace to be contained within a single
//		arg[] array.  Quotes effectively suspend whitespace delimiting within quote pairs.
//		The system doesn't differentiate opening or closing quotes.  As long as it is defined in
//		quotespace(), any character can be used to open and close a quoted parameter string.
//			e.g.: if a double (") and single (') quote character are defined in quotespace(),
//			any of the following are valid quoted strings:
//				"Now is the time on schprockets when we dance'
//				'No monkeys allowed!"
//				"Go for launch"
//
//	Parameter ordinal management is specified by the command-specific parser code blocks and Fns.
//		Generally, a fixed order is easiest to manage.  Non-entered values in a list of 2 or more
//		parameters are indicated by a "-" character.  Negation of decimal values must also be
//		addressed in the cmd-specific code.  Other management schemes are possible but would be
//		up to the cmd-specific code to execute.
//
//		Parametric switches ("-x" in the command line) do not have any ordinal requirements nor can
//		any be enforced under the current architecture.
//
//=============================================================================

int x_cmdfn(U8 nargs, char* args[ARG_MAX], U16* offset){

#define	OBUF_LEN 110				// buffer length
#define	MAX_LOG_ERRS (OBUF_LEN / 4)	// max number of errors logged by verify cmd
	char	obuf[OBUF_LEN];			// gp output buffer
//	char	abuf[30];				// temp string buffer
//	char	bbuf[6];				// temp string buffer
	U32		params[ARG_MAX];		// holding array for numeric params
	char	c;						// char temp
//	char	d;						// char temp
//	volatilechar	pm = FALSE;				// M flag, MAIN (set if "-M" found in args)
volatile	char	ph = FALSE;				// H flag, (set if "-h" found in args)
volatile	char	ps = FALSE;				// S flag, SUB (set if "-S" found in args)
volatile	char	pc = FALSE;				// C flag (set if "-C" found in args)
volatile	char	pw = FALSE;				// W flag (set if "-W" found in args)
volatile	char	px = FALSE;				// X flag (set if "-X" found in args)
volatile	char	pv = FALSE;				// V flag (set if <wsp>-V<wsp> found in args)
volatile	char	pr = FALSE;				// R flag (set if <wsp>-R<wsp> found in args)
	int		cmd_found = TRUE;		// default to true, set to false if no valid cmd identified
//	char*	q;						// char temp pointer
	char*	s;						// char temp pointer
	char*	t;						// char temp pointer
	char	cmd_id;					// command enumerated id
//	U8		g;						// temp
//	U8		h;						// temp
	U8		i;						// temp
	U8		j;						// temp
//	U8		k;						// temp
	U16		ii;						// U16 pointer
	U16		kk;
//	U16*	ip;						// U16 pointer
	U32		aa;
	U32		dd;
	U32		bb;

	U16		ia[16];					// adc test array

//	S32		mem_buf8[7];			// U8 mem buffer
//	U8*		ptr0;					// U8 mem pointer
//	U16		ki;						// U16 temp
//	U16		kk;						// U16 temp
//	U32		hh;						// U16 temp
//	U16		adc_buf[8];				// adc buffer
//	U16		tadc_buf[8];			// adc buffer
//	uint32_t ii;
//	uint32_t jj;
//	volatile uint32_t* pii;					// u32 pointer
//	S32		si;
//	float	fa;
//	char	gp_buf[25];				// gen-purpose buffer

#ifdef DEBUG
//	U8		m;						// temp
//	U8		dbuf[10];				// U8 disp buf
//	S8		si;						// temp s
//	S8		sj;
//	float	fb;
#endif

	bchar = '\0';																// clear global escape
    if (nargs > 0){
    	if((args[0][0] != '~')){
//    		for(i = 0; i <= nargs; i++){										//upcase all args !!! might just upcase command token ???
//    			s = args[i];
//    			str_toupper(s);
//    		}
    	}
		t = args[0];															// point to first arg (cmd)
		cmd_id = cmd_srch(t);													// search for command
		s = args[1];															// point to 2nd arg (1st param)
		if(*s == '?'){
			if((cmd_id == help1) || (cmd_id == help2)){
				do_help();														// set to list all cmd helps
				putsQ("");
				for(i = 0; i < lastcmd; i++){
					if(do_cmd_help(i)) putsQ("");
				}
			}else{
				do_cmd_help(cmd_id);											// do help for cmd only
			}
		}else{
			c = parm_srch(nargs, args, "-s");									// capture sub floater
			if(c){
				ps = TRUE;
				nargs--;
			}
/*			c = parm_srch(nargs, args, "-m");									// capture main floater
			if(c){
				pm = TRUE;
				nargs--;
			}*/
			c = parm_srch(nargs, args, "-h");									// capture main floater
			if(c){
				ph = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-v");									// capture v-flag floater (verbose)
			if(c){
				pv = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-c");									// capture c-flag floater
			if(c){
				pc = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-w");									// capture w-flag floater
			if(c){
				pw = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-x");									// capture x-flag select floater
			if(c){
				px = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-r");									// capture x-flag select floater
			if(c){
				pr = TRUE;
				nargs--;
			}
			gas_gage(2);														// init gas gauge to disabled state

// ====== PARSING SWITCH ==========================================================================================================================================

			switch(cmd_id){														// dispatch command
				case help1:
				case help2:														// MAIN HELP
					do_help();
					break;

				case vers:														// SW VERSION CMD
					dispSWvers();
					break;

// ==  DEBUG Fns FOLLOW +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=

				case bus_cmd:													// DUT bus test cmd
					params[0] = 0x1ffffL;
					params[1] = 0L;
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					dutpwr(1);													// power on
					for(aa=0L; aa<257; aa++){
						dataio(0L, (U8)aa, 1);
						wait(1);
					}
					dutpwr(0);													// power off
					break;

				case adc_cmd:													// process LCD bus test cmd
					do{
						adc_in(ia);
						aa = ((U32)*(ia+3) * (U32)VDDA * (U32)ADCK)/40950L;		// (mV)
						sprintf(obuf,"adc: %d mV\n", aa);
						putssQ(obuf);
						aa = 1470L - (((U32)*(ia+7) * VDDA * 75L) / 40950);
						sprintf(obuf,"Tj: %d.%d C\n", aa/10, aa%10);
//						sprintf(obuf,"Tj: %d C\n", *(ia+7));
						putssQ(obuf);
						wait(200);
					}while(bchar != ESC);
					break;

				case vccon_cmd:													// process LCD bus test cmd
					if(devid != dev00_cmd){
						dutpwr(1);													// power on
						putsQ("Device ON");
					}else{
						putssQ("!! No device selected !!\n");
					}
					break;

				case vccoff_cmd:													// process LCD bus test cmd
					dutpwr(0);													// power off
					putsQ("Device off");
					break;

				case mem_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
					params[0] = 0;		// addr
					params[1] = 1;		// len
					params[2] = 0;		// data
					params[3] = 0;		// +mod
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					if(pw){
						// write
						sram_write_start((U32)params[0]);
						do{
							sram_write(params[2]);
							params[2] += params[3];
						}while(--params[1]);
						sram_close();
					}else{
						// read
						dump_mem((U32)params[0],(U32)params[0]+(U32)params[1],0, obuf);
					}
					break;

				case dev_cmd:
					putssQ("Current device: ");
					putssQ(dev_list[devid]);
					putssQ("\n\n");
					putssQ("Device List:\n");
					for(i=0; i<MAX_DEV; i++){
						putssQ(dev_list[i]);
						putssQ("\n");
					}
					putssQ("\n");
					break;

				case dev28_cmd:
					putssQ("Set device = 28C64.\n");
					set_dev(0x00, 0);												// clear mask for A[18:16]
					devid = dev28_cmd;
					vpp(0);
					vppf(0);
					skt(28);
					skt(0xee);
					device_maxaddr = 0x2000L;
					dutpwr(1);
					break;

				case devFL1_cmd:
					putssQ("Set device = 28F101.\n");
					set_dev(0x00, 0);												// clear mask for A[18:16]
					devid = devFL1_cmd;
					vpp(0);
					vppf(0);
					skt(32);
					skt(0xe0);
					device_maxaddr = 0x10000L;
					dutpwr(1);
					wait(10);
					// read & display dev/mfg
					break;

				case devEP1_cmd:
					putssQ("Set device = 27C011.\n");
					set_dev(0x07, 14);											// set mask for A[18:16]
					devid = devEP1_cmd;
					vpp(0);
					vppf(0);
					skt(28);
					skt(0xee);
					device_maxaddr = 0x10000L;
					dutpwr(1);
					break;

				case devEP2_cmd:
					putssQ("Set device = 27C256.\n");
					set_dev(0x00, 0);												// clear mask for A[18:16]
					devid = devEP2_cmd;
					vpp(0);
					vppf(0);
					skt(28);
					skt(0xe0);
					device_maxaddr = 0x4000L;
					dutpwr(1);
					break;

				case dump_cmd:													// DUT <addr> <data> <length> <+data modifier>
					params[0] = 0;		// addr
					params[1] = 1;		// len
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					// read device
					dump_mem(params[0], params[0]+params[1], 1, obuf);
					break;

				case sdump_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
					params[0] = 0;		// addr
					params[1] = 1;		// len
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					// read device
					if(ps){
						// process sram
						sram_read_start(params[0]);								// init SRAM seq read
						process_stx(params[0], params[0]+params[1], ADDR_24, SRAM_SRC);
						sram_close();											// close SRAM
					}else{
						// process dut
						process_stx(params[0], params[0]+params[1], ADDR_24, DUT_SRC);
					}
//					dump_mem((U32)params[0],(U32)params[0]+(U32)params[1],1, obuf);
					break;

				case pgm_cmd:													// program DUT from SRAM
					params[0] = 0;		// addr
					params[1] = 0;		// len
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					// pgm device
					pgm_dut(params[0], params[0]+params[1], devid);				// start, end, devid
					break;

				case sload_cmd:													// program DUT from SRAM
					handshake = 1;
					params[0] = 0;		// addr offset
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					// load sram from SREC
					while(gotmsgn()){											// clear input
						getss(obuf);
					}
					putssQ("Send SREC file ");
					process_srx(PD_STOR, obuf, &params[0]);						// get and process S or I record file (dmode, strptr, offset)
					putssQ(" Done!\n");
					break;

				case svfy_cmd:													// program DUT from SRAM
					params[0] = 0;		// addr offset
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					// load sram from SREC
					process_srx(PD_VRFY, obuf, &params[0]);						// get and process S or I record file (dmode, strptr, offset)
					break;

				case test_cmd:													// process sram test cmd <addr> <data> <length> <+data modifier>
					params[0] = 0;		// addr
					params[1] = 2;		// len
					params[2] = 0;		// data
					params[3] = 0;		// +mod
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					sram_write_start(params[0]);
					dd = 0L;
					kk = 0;
					bb = params[0];
					do{
						i = (U8)(dd>>8);
						kk = calcrc(i, kk, XPOLY);								// update crcsum
						sram_write(i);
						i = (U8)(dd);
						kk = calcrc(i, kk, XPOLY);								// update crcsum
						sram_write(i);
						bb += 2;
						dd += 1;
					}while((bb != (params[0]+params[1])) && (bchar != ESC));
					sram_close();
					// read device
					dump_mem((U32)params[0],(U32)params[0]+(U32)params[1],0, obuf);
					sprintf(obuf,"CRC16: $%04x (written)\n", kk);
					putssQ(obuf);
					break;

				default:
				case lastcmd:													// not valid cmd
					cmd_found = FALSE;
					break;

			} //=========== END PARSING SWITCH ======================================================================================
		}
    }
	if(bchar == ESC) while(gotchrQ()) getchrQ();									// if ESC, clear CLI input chrs
	return cmd_found;
}

//=============================================================================
// putOK() displays OK status response if true, else err
//=============================================================================
void putOK(U8 tf){

	if(tf){
		putsQ("#-OK$");
	}else{
		putsQ("#-ERR$");
	}
	return;
}

//=============================================================================
// do_help() displays main help screen
//=============================================================================
void do_help(void){
		//          1         2         3         4         5         6         7         8
		// 12345678901234567890123456789012345678901234567890123456789012345678901234567890
	putsQ("IC-900 DU-Clone CMD List:");
	putsQ("Syntax: <cmd> <arg1> <arg2> ... args are optional depending on cmd.");
	putsQ("\t<arg> order is critical except for floaters.");
	putsQ("\"?\" as first <arg> gives cmd help,  \"? ?\" lists all cmd help lines. When");
	putsQ("selectively entering <args>, use \"-\" for <args> that keep default value.");
	putsQ("\"=\" must precede decimal values w/o spaces. Floating <args>: these non-number");
	putsQ("<args> can appear anywhere in <arg> list: \"W\" = wait for operator\n");
//	putsQ("\tFreq set\tofp VERSion");

	putsQ("Supports baud rates of 115.2, 57.6, 38.4, 19.2, and 9.6 kb.  Press <Enter>");
	putsQ("as first character after reset at the desired baud rate.");
}

//=============================================================================
// do_cmd_help() displays individual cmd help using cmd_id enum
//=============================================================================
char do_cmd_help(U8 cmd_id){
	char 	c = TRUE;	// temps
//	U16		k;
//	U8		i;
//	char	hbuf[10];

	switch(cmd_id){														// dispatch help line
		case bus_cmd:
			putsQ("bu");
			putsQ("\tdebug: DUT bus test");
			break;

		case adc_cmd:													// process LCD bus test cmd
			putsQ("ad");
			putsQ("\tdebug: ADC read (ESC to exit)");

		case vccon_cmd:													// process LCD bus test cmd
			putsQ("on");
			putsQ("\tDUT power ON");
			break;

		case vccoff_cmd:													// process LCD bus test cmd
			putsQ("off");
			putsQ("\tDUT power off");
			break;

		case mem_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
			putsQ("mt <srt> <len> <data> <+mod> <-w>");
			putsQ("\tSRAM mem test, \"-w\" to write, else read in hex dump format");
			break;

		case dev_cmd:
			putssQ("dev\n");
			putssQ("\tDisplay current device & list all supported devices\n");
			break;

		case dev28_cmd:
			putssQ("28c64: Set device = 28C64\n");
			break;

		case devFL1_cmd:
			putssQ("28f101: Set device = 28F101\n");
			break;

		case devEP1_cmd:
			putssQ("27c011: Set device = 27C011\n");
			break;

		case devEP2_cmd:
			putssQ("27c256: Set device = 27C256\n");
			break;

		case dump_cmd:													// DUT <addr> <data> <length> <+data modifier>
			putsQ("dump <srt> <len>");
			putsQ("\tDUT hex dump");
			break;

		case sdump_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
			putsQ("sdump <srt> <len>");
			putsQ("\tDUT SREC (S28) dump");
			break;

		case pgm_cmd:													// program DUT from SRAM
			putsQ("pgm <srt> <len>");
			putsQ("\tDUT program");
			break;

		case test_cmd:													// process sram pattern test cmd <addr> <data> <length> <+data modifier>
			putsQ("te <srt> <len>");
			putsQ("\tSRAM pattern test");
			break;

		default:
			c = FALSE;
			break;
	}
	return c;
}
/*
//=============================================================================
// disp_error() displays standard error messages & device off status
//=============================================================================
void disp_error(U8 errnum){

	do_red_led(LED_BLINK);
	switch(errnum){
		case no_response:
			putsQ("!! ERR !! No response from DUT.");
			break;

		case no_device:
			putsQ("!! ERR !! No DUT selected.");
			break;

		case target_timeout:
			putsQ("!! ERR !! DUT timeout.");
			break;

		default:
			break;
	}
	if(!dut_pwr(TARGET_STAT)) putsQ("DEVICE OFF");		// signal device off
}*/
/*
//=============================================================================
// disp_fail() displays pgm/read error message with params
//	this is a debug function that displays the HC11 fn comms status
//	Also, this fn sets the status LED to blink to indicate a failure was encountered
//=============================================================================
void disp_fail(char* buf, char* s, U16 c, U16 d){

	do_red_led(LED_BLINK);
	sprintf(buf,"%s Failed!! errs: %02x %02x", s, (U16)c, (U16)d);
	putsQ(buf);
}*/

//=============================================================================
// disp_wait_addr() dead code
//=============================================================================
void disp_wait_addr(char* buf){

	sprintf(buf,"disp_wait_addr = dead code\n");
	putsQ(buf);
}

//=============================================================================
// exec_bcmd() dead code
//=============================================================================
void exec_bcmd(char* bcmdbuf_ptr, char* obuf, U32* offset){

}

//***********************//
// bcmd functions follow //
//***********************//

//******************************//
// hosekeeping functions follow //
//******************************//

//=============================================================================
// pgm_dut() dispatches to the device algorithm passed.
//	data is pulled from the SRAM
//=============================================================================
void	pgm_dut(U32 srt, U32 end, U8 dev_id){
	U32	addr = srt;
	U32	ii;
	U8	d;
#define	LOOP_MAX	20

	sram_read_start(srt);									// init SRAM seq read
	switch(dev_id){
	case dev28_cmd:		// 28C64
		while(addr != end){
			d = sram_read();
			dataio(addr++, d, WR);
			ii = 0;
			do{
				wait(1);
			}while((ii++<LOOP_MAX) && (d != fast_read()));
		}
		break;

	case devFL1_cmd:	// 28F101
		// erase the entire array to device_maxaddr
		// prog/pgvfy

		break;

	case devEP1_cmd:	// 27C011
		break;

	case devEP2_cmd:	// 27C256
		break;
	}
	sram_close();											// close SRAM
	return;
}

//=============================================================================
// dump_mem() displays SRAM memory in hexdump format
//=============================================================================
void dump_mem(U32 addrb, U32 addre, U8 dut, char* obuf){
	U8	j;
	U8	data[16];
	U8	d;
	U32	ii = addrb;
	U16	crcsum = 0;

	j = 255;
	if(dut){
		do{
			if((j==0)||(j>LINELEN)){
				if(j==0){
					dump_str(data);
				}
				sprintf(obuf,"\n%05x: ", ii);
				putssQ(obuf);
				j = LINELEN;
			}
			d = dataio(ii, 0, RD);
			data[LINELEN-j] = d;
			crcsum = calcrc(d, crcsum, XPOLY);			// update crcsum
			sprintf(obuf,"%02x ", d);
			putssQ(obuf);
			ii += 1;
			j -= 1;
		}while((ii != addre) && (bchar != ESC));
		dump_str(data);
	}else{
		sram_read_start(addrb);
		do{
			if((j==0)||(j>LINELEN)){
				if(j==0){
					dump_str(data);
				}
				sprintf(obuf,"\n%05x: ", ii);
				putssQ(obuf);
				j = LINELEN;
			}
			d = sram_read();
			data[LINELEN-j] = d;
			crcsum = calcrc(d, crcsum, XPOLY);			// update crcsum
			sprintf(obuf,"%02x ", d);
			putssQ(obuf);
			ii += 1;
			j -= 1;
		}while((ii != addre) && (bchar != ESC));
		sram_close();
	}
	if(bchar == ESC){
		putssQ("\n!! ABORTED !!\n");
	}else{
		sprintf(obuf,"\nCRC16: $%04x\n", crcsum);
		putssQ(obuf);
	}
	return;
}
/*
for(i=XM_DATASTART;i<XM_DATAEND;i++){
	if(xcrc){
		checksum = calcrc(xmbuf[i], checksum, XPOLY); // if crc, update crcsum
	}else{
		checksum += (U16)xmbuf[i]; // else do checksum
		checksum &= 0xff;
	}
}*/

void	dump_str(U8* data){
	U8		i;
	char	c;

	putssQ("    ");
	for(i=0; i<LINELEN; i++){
		c = (char)data[i];
		if((c < ' ') || (c > '~')) c = '.';
		putcharQ(c);
	}
	return;
}


//-----------------------------------------------------------------------------
// calcrc() calculates incremental crcsum using supplied poly
//	(xmodem poly = 0x1021)
//-----------------------------------------------------------------------------
U16 calcrc(U8 c, U16 oldcrc, U16 poly){

	U16 crc;
	U8	i;

	crc = oldcrc ^ ((U16)c << 8);
	for (i = 0; i < 8; ++i){
		if (crc & 0x8000) crc = (crc << 1) ^ poly;
		else crc = crc << 1;
	 }
	 return crc;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// process_CMD() handles periodic polling tasks for the cmd_fn.c file scope
//-----------------------------------------------------------------------------

char process_CMD(U8 flag){

	if(flag == PROC_INIT){
		// init file-local statics
		return 0;
	}
	return 0;
}

//=============================================================================
// get BCD param from string
//=============================================================================
void get_BCD32(char *sptr, U32 *bcdval){

	char*	s = sptr;

	*bcdval = 0;
	while(*s){
		*bcdval <<= 4;
		*bcdval |= asc_hex(*s++);
	}
	return;
}

//=============================================================================
// get numeric params from command line args
//	argsrt specifies the first item to be searched and aligns argsrt with params[0]
//	for multi-arg cmds, fields must be entered in order.
//=============================================================================
U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U32 params[8]){

	char*	s;
	U32*	ptr1;
	S32		temp32;
	U8		i;
	U8		count = 0;

	if(argsrt < nargs){											// test for start in limit (abort if not)
		for(i = argsrt; i < nargs; i++){						// convert strings to values
			s = args[i];										// set pointers to array items
			ptr1 = &params[i - argsrt];
			switch(*s){
				case '-':										// skip if user specified default
				case '\0':										// or if arg is empty
					break;

				default:
					count += sscanf(s,"%d",&temp32);			// get decimal value
					*ptr1 = temp32;
					break;

				case '$':
					s++;
					count += sscanf(s,"%x",&temp32);			// get hex if leading "$"
					*ptr1 = temp32;
					break;

				case 'O':
				case 'o':
					s++;
					count += sscanf(s,"%o",&temp32);			// get octal if leading "O"
					*ptr1 = temp32;
					break;
			}
		}
	}
	return count;
}

//=============================================================================
// search for command keywords, return cmd ID if found
//	uses the cmd_list[] array which is constructed as an array of null terminated
//	strings compressed into a single string definition.  Commands are added by
//	placing the minimum required text from the command name with a '\0' terminating
//	null.  cmd_list[] is terminated by an $ff after all of the command names.
//	cmd_enum{} holds an enumerated, named list of all valid commands.  The enum
//	definition must be at the top of this file, so the commented-out version shown
//	below must be copied and pasted to the top of the file whan any changes are
//	made (commands added or deleted).
//
//	Some thought must be put into the order of command names.  Shorter matching
//	names (e.g., single chr entries) must follow longer names to allow the algortihm
//	to properly trap the shorter cmd name.
//	
//=============================================================================
cmd_type cmd_srch(char* string){
// dummy end of list, used to break out of search loop
const char end_list[] = {0xff};
// list of minimum length command words. cmd words are separated by '\0' and list terminated with 0xff
//const char cmd_list[] = {"H\0K\0A\0D\0L\0P\0E\0U\0S\0TI\0T\0?\0H\0VERS\0\xff"};
//enum cmd_enum{ hm_data,kp_data,adc_tst,log_data,tst_pwm,tst_enc,tstuart1,timer_tst,tst_tempa,help1,help2,vers,lastcmd,helpcmd };
//!!! make changes to cmd_enum here, move them to top of file, then un-comment !!!

	char*	ptr;							// temp ptr
	char	cmdid = 0;						// start at beginning of cmd_enum
	char	i;								// temp
	char	found = FALSE;					// cmd found flag (default to not found)

	ptr = cmd_list[cmdid];										// start at beginning of search list
	while((*ptr & 0x80) != 0x80){								// process until 0xff found in search list
		i = strncmp(string, ptr, strlen(ptr));					// inbound string match search list?
		if(i){
			cmdid++;											// no, advance to next cmdid
			ptr = cmd_list[cmdid];
//			while(*ptr++);										// skip to next item in search list
		}else{
			ptr = (char*)end_list;								// found match,
			found = TRUE;										// set break-out criteria
		}
	}
	if(!found) cmdid = lastcmd;									// not found, set error cmd id
	return cmdid;
}

/*	char*	ptr;							// temp ptr
	char	cmdid = 0;						// start at beginning of cmd_enum
	char	i;								// temp
	char	found = FALSE;					// cmd found flag (default to not found)

	ptr = (char*)cmd_list;										// start at beginning of search list
	while((*ptr & 0x80) != 0x80){								// process until 0xff found in search list
		i = strncmp(string, ptr, strlen(ptr));					// inbound string match search list?
		if(i){
			cmdid++;											// no, advance to next cmdid 
			while(*ptr++);										// skip to next item in search list
		}else{
			ptr = (char*)end_list;										// found match,
			found = TRUE;										// set break-out criteria
		}
	}
	if(!found) cmdid = lastcmd;									// not found, set error cmd id
	return cmdid;
}*/

//=============================================================================
// parm_srch() looks for a match of parm_str in any non-empty args[] strings
//	if found, remove the args entry from param list and return 1st chr of parm_str,
//	else return '\0'
//=============================================================================
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str){

	U8		i;								// counter temp
	char	c = '\0';						// first chr of matched parm_str (first time thru loop, there is no match)
	static char null_str[] = "";			// null string that persists

//	if(nargs > 1){
	    for(i = 1; i <= nargs; i++){							// search starting with first args[] item
			if(c){												// if(c!=null)...
				args[i] = args[i+1];							// if there was a match, move the subsequent pointers down one
			}else{
				if(strlen(parm_str) == strlen(args[i])){		// in order to match, the lengths have to be equal...
					if(strncmp(args[i], parm_str, strlen(parm_str)) == 0){ // look for match
						c = *parm_str;							// if match, capture 1st chr in matched string
						i--;									// back-up one to edit this item out of the list
					}
				}
			}
	    }
//	}
 	if(c != '\0'){
		args[ARG_MAX - 1] = null_str;							// if there was a match, the last pointer goes to null
		
	}
	return c;													// return first chr in matched string, or null if no match
}

//=============================================================================
// disp_esc() if param true, display "Press esc to exit" msg
//=============================================================================
void disp_esc(char flag){

	if(flag){
		putsQ("  Press <ESC> to exit.");
	}
	putsQ("");
}

//=============================================================================
// convert all chrs in string to upper case
//=============================================================================
void str_toupper(char *string){

    while(*string != '\0'){
        *string++ = toupper(*string);
    }
}

//=============================================================================
// parse command line array for delimited arguments.  Called prior to entry into x_cmdfn().
//  on exit, the args[] array (an array of char pointers) holds each delimited argument
//	from the command string input:
//  args[0] holds first arg (the command token)
//  args[1] holds next arg
//  args[2] etc...
//  up to args[ARG_MAX]
//
//  nargs holds number of arguments collected.  i.e., nargs = 3 specifies that args[0] .. args[3]
//      all hold arguments (three total, including the command).
//=============================================================================
int parse_args(char* cmd_string, char* args[ARG_MAX]){
	int i;
	char quote_c = 0;
	static char null_string[2] = "";

    // clear args pointers
    for (i=0; i<ARG_MAX; i++){
        args[i] = null_string;
    }
    i = 0;
    do{
        if(quotespace(*cmd_string, 0)){         // process quotes until end quote or end of string
            quote_c = *cmd_string;              // close quote must = open quote
            args[i++] = ++cmd_string;               // start args with 1st char after quote
            while(!quotespace(*cmd_string,quote_c)){
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                cmd_string++;
            }
            *cmd_string++ = '\0';               // replace end quote with null
        }
        if(*cmd_string == '\0'){
            return i;                           // end of cmd string, exit
        }
        if(!whitespace(*cmd_string)){
            args[i++] = cmd_string++;			// when non-whitespace encountered, assign arg[] pointer
            if(i > ARG_MAX){
                return i;						// until all args used up
            }
            do{
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                if(whitespace(*cmd_string)){
                    *cmd_string = '\0';			// then look for next whitespace and delimit (terminate) the arg[] string
                    break;
                }
                cmd_string++;					// loop until end of cmd_string or next whitespace
            } while (1);
        }
        cmd_string++;							// loop...
    } while (1);
    // no return here, we'll never get here anyway...
}

//=============================================================================
// parse_ehex() for embeded hex ($$) arguments
//  on exit, the string holds the original text with %xx replaced by a single
//	hex byte.
//=============================================================================
void parse_ehex(char * sptr){
	char* tptr;
	U8	i;

	while(*sptr){
		if((*sptr == '$') && (*(sptr+1) == '$')){
			i = asc_hex(*(sptr+2)) << 4;
			i |= asc_hex(*(sptr+3));
			*sptr++ = i;
			tptr = sptr;
			do{
				*tptr = *(tptr+3);
				tptr++;
			}while(*(tptr+2));
		}else{
			sptr++;
		}
	}
}
//=============================================================================
// test characer for whitespace
//=============================================================================
int whitespace(char c){

    switch (c){					// These are all valid whitespace:
        case '\n':          	// newline
        case '\r':          	// cr
        case '\t':          	// tab
        case 0x20:{         	// space
		case '/':				// slash is also wsp
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// test characer for quote
//=============================================================================
int quotespace(char c, char qu_c){

    if(qu_c == '\0'){
        switch (c){				// if qu_c is null, these are valid quotes:
            case '\'':          // single
            case '\"':          // double
            case '\t':          // tab
                return TRUE;
            }
    } else {
        if(c == qu_c){			// else, only qu_c results in a TRUE match
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// gas_gage() display up to 16 "*" chrs based on count rate.
//	Gauge appearance:
//	[****************]	all OK
//	[***.............]	errors detected
//
//	"len" cmds:
//	0: process gauge counter/display
//	1: set gauge error character = "."
//	2: disable gage counter/display (set clen = 0)
//	all others: set creset = count = len/16, display initial gauge characters
//	This calculation identifies how many bytes are in 1/16th of the total
//	byte count (len).  For count events (len == 0), this Fn decrements count, &
//	displays a gauge chr when count == 0.  count is then reloaded with creset.
//	process continues until 16 gauge chrs have been displayed.  After this,
//	any further count events result in no further change to the display.
//=============================================================================
U8 gas_gage(U16 len){

#define LENCMD_MAX 2		// max # of gas-gage() cmds

	static U16	creset;		// holding reg for data counter reset value
	static U16	count;		// data counter
	static U8	clen;		// gage chr counter
	static U8	gchr;		// gage chr storage
		   U8	c = 0;		// gage printed flag

	if(len <= LENCMD_MAX){
		if(!len && clen){
			if(--count == 0){ 
				putchar(gchr);					// disp gage chr
				count = creset;					// reset loop counters
				clen--;
				if(clen == 0) putchar(']');		// if end of gage, print end bracket
				c = 1;
			}
		}else{
			if(len == 1) gchr = '.';			// if error flag, change gauge chr to err mode
			if(len == 2) clen = 0;				// disable gauge
		}
	}else{
		creset = count = len >> 4;				// init count & count reset (creset) = len/16
		if(creset == 0) creset = 1;				// if overall length too short, set 1:1
		clen = 16;								// 16 gage chrs max
		gchr = '*';								// set * as gage chr
		putchar('[');							// print start bracket
		for(c = 0; c < 16; c++) putchar(' ');
		putchar(']');							// place end bracket for scale
		for(c = 0; c < 17; c++) putchar('\b');	// backspace to start of scale
		c = 1;
	}
	return c;
}

//=============================================================================
// log_error_byte() places error data into log buffer.  Log format is:
//	(device) (host) (addrH) (addrL).  Called by target verify fns to allow
//	a limited number of errors to be trapped (limit is the buffer used to
//	hold the error log).
//	returns updated pointer to next available log entry
//=============================================================================
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a){

	*lbuf++ = d;								// store device data
	*lbuf++ = h;								// store host data
	*lbuf++ = (U8)(a >> 8);						// store addr
	*lbuf++ = (U8)(a & 0xff);
	return lbuf;								// return updated pointer
}

//=============================================================================
// disp_error_log() displays errors logged into error string.  Log format is:
//	(device) (host) (addrH) (addrL)
//	Display format is:
//	nn: Dev ($xx) != $xx @$xxxx\n = 28 printed chrs
//	nn = err number (ordinal)
//	xx = data bytes
//	xxxx = error address
//=============================================================================
void disp_error_log(U8* lbuf, U16 len){

	char obuf[32];				// local buffer
	// use U16 type to simplify sprintf variable list
	U16  i;						// loop counter
	U16  d;						// device data
	U16  h;						// host data
	U16  a;						// addr

	len++;										// add 1 to end so that we can start loop at "1"
	for(i = 1; i < len; i++){					// loop from 1 to len+1 entries
		d = (U16)*lbuf++ & 0xff;				// format device data
		h = (U16)*lbuf++ & 0xff;				// format host data
		a = ((U16)*lbuf++ & 0xff) << 8;			// format addr
		a |= (U16)*lbuf++ & 0xff;
		sprintf(obuf,"%02u: Dev ($%02x) != $%02x @$%04x", i, d, h, a); // display err line
		putsQ(obuf);
	}
}

//=============================================================================
// bcmd_resp_init() inits bcmd_resp_ptr
//=============================================================================
void bcmd_resp_init(void){

	bcmd_resp_ptr = bcmd_resp_buf;
	*bcmd_resp_ptr = '\0';
}

//=============================================================================
// asc_hex() converts ascii chr to 4-bit hex.  Returns 0xff if error
//=============================================================================
U8 asc_hex(S8 c){

	U8 i;

	if((c >= 'a') && (c <= 'f')) c = c - ('a' - 'A');	// upcase
	if((c >= '0') && (c <= '9')){			// if decimal digit,
		i = (U8)(c - '0');					// subtract ASCII '0' to get hex nybble
	}else{
		if((c >= 'A') && (c <= 'F')){		// if hex digit,
			i = (U8)(c - 'A' + 0x0A);		// subtract ASCII 'A', then add 0x0A to get hex nybble
		}else{
			i = 0xff;						// if not valid hex digit, set error return
		}
	}
	return i;	
}

//=============================================================================
// temp_float() converts MCP9800 binary temp to a float (degrees C)
//=============================================================================
float temp_float(U16 k){
	U8		i;			// temp
	U8		j = 0;		// temp sign
	float	fa;			// temp float

	if(k & 0x8000){												// if negative,
		j = 1;													// preserve sign and
		k = ~k + 1;												// convert value to positive
	}
	i = k >> 8;													// get integer portion
	fa = (float)i;												// convert to float
	if(k & 0x0080) fa += 0.5;									// add fractional portion
	if(k & 0x0040) fa += 0.25;
	if(k & 0x0020) fa += 0.125;
	if(k & 0x0010) fa += 0.0625;
	if(j){														// if negative, convert
		fa *= -1;
	}
	return fa;
}

// eof
