/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.h
 *
 *  Module:    Control, FFPGMR, MK-II
 *
 *  Summary:   defines and global declarations for busio.c
 *
 *******************************************************************/

void	put_addr(U32 addr);
U8		dataio(U32 addr, U8 data, U8 dir);
void	dutpwr(U8 on);
