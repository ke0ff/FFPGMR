/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.h
 *
 *  Module:    Control, FFPGMR, MK-II
 *
 *  Summary:   defines and global declarations for busio.c
 *
 *******************************************************************/

#define	DEVRST	0xff
#define	RD	0
#define	WR	1
#define	DLYQ	80
#define	CDLY	16


void	put_addr(U32 addr);
U8		dataio(U32 addr, U8 data, U8 dir);
void	dutpwr(U8 on);
void	vpp(U8 on);
void	vppf(U8 on);
void	skt(U8 id);
void	set_dev(U8 dev, U8 shft);
U8		fast_read(void);
void	fast_write(U8 d);
U8		fast_pgm_vfy(U8 d);
U8	byte_flash(U32 addr, U8 data);
void	set_addr(void);
