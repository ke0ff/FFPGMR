/********************************************************************
 ************ COPYRIGHT (c) 2021 by ke0ff, Taylor, TX   *************
 *
 *  File name: init.h
 *
 *  Module:    Control, IC-900 RDU Controller Clone
 *
 *  Summary:   defines and global declarations for main.c
 *  			Also defines GPIO pins, timer constants, and other
 *  			GPIO system constants
 *
 *******************************************************************/

void	put_addr(U32 addr);
U8		dataio(U32 addr, U8 data, U8 dir);
void	dutpwr(U8 on);
