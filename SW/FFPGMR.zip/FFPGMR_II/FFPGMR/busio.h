/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.h
 *
 *  Module:    Control, FFPGMR, MK-II
 *
 *  Summary:   defines and global declarations for busio.c
 *
 *******************************************************************/

#define	DEVRST	0xff
#define	RD	0
#define	WR	1
#define	DLYQ	80
#define	CDLY	16

// voltage set defines
#define	VCC_SHFT	3
#define	VCC_424		0
#define	VCC_500		(1<<VCC_SHFT)
#define	VCC_600		(2<<VCC_SHFT)
#define	VCC_625		(3<<VCC_SHFT)
#define	VCC_650		(4<<VCC_SHFT)
#define	VCC_MASK	(VCC_SEL0|VCC_SEL1|VCC_SEL2)

#define	VPP_SHFT	6
#define	VPP_500		0
#define	VPP_120		(1<<VPP_SHFT)
#define	VPP_122		(2<<VPP_SHFT)
#define	VPP_127		(3<<VPP_SHFT)
#define	VPP_MASK	(VPP_SEL0|VPP_SEL1)


// us time delay defines -- all of the following represent time delays * 1us
#define	LAT_SETUP	50
#define	LAT_HOLD	50
#define	BUS_DLY		2
#define	DLY_10US	10
#define	DLY_01MS	1000
#define	DLY_10MS	10000


void	wrport_ahh(U8 set, U8 clear);
void	wrport_ah3(U8 set, U8 clear);
void	set_vcc(U8 voltmask);
void	set_vpp(U8 voltmask);

void	put_addr(U32 addr);
U8		dataio(U32 addr, U8 data, U8 dir);
void	dutpwr(U8 on);
void	vcc(U8 on);
void	vpp(U8 on);
void	vppf(U8 on);
void	skt(U8 id);
void	set_dev(U8 dev, U8 shft);
U8		fast_read(void);
void	fast_write(U8 d);
U8		fast_pgm_vfy(U8 d);
U8	byte_flash(U32 addr, U8 data);
void	set_addr(void);
U8	ds1216e_bit(U8 wrbit, U8 write);
U8	ds1216c_bit(U8 wrbit, U8 write);
void	wait_lat(U16 numus);
