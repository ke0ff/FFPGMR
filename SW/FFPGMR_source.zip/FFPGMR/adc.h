/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: adc.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for adc.c
 *
 *******************************************************************/

#include "typedef.h"

#ifndef ADC_H_
#define ADC_H_


//-----------------------------------------------------------------------------
// defines
//-----------------------------------------------------------------------------

#define	VDDA	329L			// div by 100 (Vref * 100)
#define	ADCK	601L			// div by 100 (includes -1% correction)
#define	ADCK2	605L			// div by 100 (includes -1% correction)
#define	TCK		68 //75L				// temperature const (gain)
#define	TCK2	0L				// temperature const (offs)
//		VMON = (ADCRAW*VDDA*ADCK)/40950 (mV)
#define		IB_MAX	8			// adc sample count

// Engineering units - limits
// VPP limits
#define	P0_LIMLO	4930		// 5.03V +/-100mV
#define	P0_LIMHI	5130
#define	P1_LIMLO	11840		// 12.04V +/- 200 mV
#define	P1_LIMHI	12240
#define	P2_LIMLO	12130		// 12.33V +/- 200 mV
#define	P2_LIMHI	12530
#define	P3_LIMLO	12600		// 12.8V +/- 200 mV
#define	P3_LIMHI	13000

// VCC limits
#define	C0_LIMLO	4150		// 4.25V +/-100mV
#define	C0_LIMHI	4350
#define	C1_LIMLO	4900		// 5.00V +/-100mV
#define	C1_LIMHI	5100
#define	C2_LIMLO	5900		// 6.00V +/-100mV
#define	C2_LIMHI	6100
#define	C3_LIMLO	6150		// 6.25V +/-100mV
#define	C3_LIMHI	6350
#define	C4_LIMLO	6400		// 6.5V +/-100mV
#define	C4_LIMHI	6600

#define	PCORRECT	40			// VCC correction factor if VPP > 8V (subtract if true)
#define	PC_LIM		8000

//-----------------------------------------------------------------------------
// Fn prototypes
//-----------------------------------------------------------------------------

U16 adc_init(void);
U8 adc_in(U16* p, U8 muxn);
U32 adc_ave(U16* p, U8 muxn);
U32 get_vpp(void);
U32 get_vcc(void);
U8 check_vpp(void);
U8 check_vcc(void);

#endif /* ADC_H_ */

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
