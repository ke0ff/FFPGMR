/********************************************************************
 ********** COPYRIGHT (c) 2024 by Joe Haas DBA FF Systems   *********
 *
 *  File name: srec.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the S-record I/O module for the FF-PGMR11
 *             protocol converter.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    07-15-24 jmh:  Debug:
 *    					Had to remove '/0' trap in abort_char().
 *    					Added suppress of "bchar" update in serial.c if xmode is true (xmodem stream was inserting
 *    						pseudo-random escape chrs, likely the checksum/crc fields, causing an abort).
 *    				 Clean-up of basic algorithms - caught some addr refs that were 16b, and other issues.
 *    				 Settled "S0" record formats for bank select, offset +/-, and comments
 *    				 Added disp_crc() to break out crc displays so that they could be displayed post-xmodem xfr.
 *    04-12-24 jmh:  Adapted to Tiva FFPGMR, Mk-II
 *    11-05-13 jmh:  creation date
 *
 *******************************************************************/

#define	SREC_C
#include <stdint.h>
#include <ctype.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"
#include "stdio.h"
#include "srec.h"
#include "init.h"
#include "serial.h"
#include "cmd_fn.h"
#include "busio.h"
#include "spi.h"

//-----------------------------------------------------------------------------
// Local Variable Declarations & defines
//-----------------------------------------------------------------------------

char bcmdbuf[BCMD_BUFLEN];	// bcmd data buffer
U8   bcmdptr;					// bcmd buf pointer

#define SR_BUFLEN 110			// max length of srec line packet
char srbuf[SR_BUFLEN];	// srec data buffer
U8   srptr;						// srec buf pointer
#define SR_TYPE 1				// Srec type pointer
#define	SR_LEN	2				// Srec length pointer
#define SR_ADDR 4				// Srec target ADDR pointer
#define SR_DATA 8				// start of Srec data pointer

U8	sr_err;						// srec error reg

#define	RAM_LEN	100

U8	dut_xdata[RAM_LEN]; // _at_ RAM_START;	// byte array to access RAM
								// this array estabishes a pointer to the XDATA SRAM.

#define	BCMD_STORE	0x00		// store d to buffer
#define	BCMD_CLEAR	0x10		// clear buffer ptr and status
#define	BCMD_QERY	0x11		// return status

U16	csum = 0;					// crc reg, srec
U16	csum2 = 0;					// crc reg, data

U16	csumz = 0;					// static holding registers
U16	csum2z = 0;

U8	s0_mem;						// s0 memory for S19 records
U32	offset_0;					// S0 offset

//-----------------------------------------------------------------------------
// Local Fn Declarations
//-----------------------------------------------------------------------------

char process_sline(U8 dmode, char* obuf, U32* offset);
char get_sline(char* sptr);
char process_bcmd(U8 d, U8 cmd);
char endofrec(char c);
char abort_char(char c);
char valid_hex(char c);
U8 get_byte(U8 p);
//U8 asc_hex(char c);
//void put_byte(U8 d);
void putc_crc(char d);

//-----------------------------------------------------------------------------
// process_srx() processes rx srecord cmds & state machine
//	dmode specifies verify (PD_VRFY) or write (PD_STOR) data mode
//-----------------------------------------------------------------------------
char process_srx(U8 dmode, char* obuf, U32* offset){

	char	srx_status = SRS_NULL;		// status response
	char	c;							// temps
//	char	d;
	char	slbuf[100];					// sline buff
	U8		linecnt = 0;				// gas gauge counter
#define	MAXGAS	8

	s0_mem = 0;									// default to 0 bank
	offset_0 = 0;
	sr_err = 0;
	csum = 0;
	csum2 = 0;
	process_data(0, 0, PD_INIT);				// init data status (U32 addr, U8 d, U8 dmode)
	do{
		bchar = '\0';
		if(!xmode){
			while(!gotmsgn());					// wait for sline...
			putcharQ(XOFF);						// re-enable remote source (XON)
			xoffsent = TRUE;
			getss(slbuf);
		}
		slbuf[99] = '\0';						// failsafe
		c = get_sline(slbuf);					// get a data record line from the input source
		if(!abort_char(c)){
			c = process_sline(dmode, obuf, offset); // process the data
			if(!xmode){
				if(c == 0x80){
					putsQ("sline chkserr");
				}
				if(++linecnt == MAXGAS){
					putcharQ('.');
				}
				if(xoffsent){
					putcharQ(XON);				// re-enable remote source (XON)
					xoffsent = FALSE;
				}
			}
		}
	}while(!endofrec(c) && (bchar != ESC));
	if(endofrec(c)) srx_status = c;
	csumz = csum;								// store to static locs
	csum2z = csum2;
	return srx_status;
}

//-----------------------------------------------------------------------------
// disp_crc() displays CRC data (allows xmodem to clear before sending response to terminal)
//-----------------------------------------------------------------------------
void	disp_crc(char* obuf){

	sprintf(obuf,"%04x\n", csum2z);
	putssQ("\nsload payload CRC: $");
	putssQ(obuf);
	sprintf(obuf,"%04x\n", csumz);
	putssQ("   sload file CRC: $");
	putssQ(obuf);
	return;
}

//-----------------------------------------------------------------------------
// process_sline() processes S-record line (raw ASCII) in srbuf[]
//	dmode sets data mode (PD_STOR stores to SRAM, PD_VRFY compares against SRAM)
//	<offset> is command-line offset param
//
// will process Moto S-records or Intel hex records.
// Intel HEX record Fields:
//	":nnaaaattdd..ddcc"
//	':' = start of record.
//	nn = number of dd..dd chr pairs
//	aaaa = 16 bit addr pointer
//	tt = record type ('00' = data rec, '1' = terminate)
//	dd..dd = data byte pairs
//	ii = 2's complement of checksum of "nn..dd"
//
// Moto S-record control flags & regs
// S-record fields:
//	"Stnna..add...ddcc"
//	'S' = start of record.
//	t = record type ('0' = offset rec, '1' = data 16b addr, '2' = data 24b addr, '8' or '9' = terminate)
//	nn = number of chr pairs between & including "aa..cc"
//	a..a = 16 or 24 bit addr pointer
//	dd..dd = data byte pairs
//	cc = 1's complement of checksum of "nn..dd"
//
//	All 'nn', 'a..a', 'd', and 't' chrs are printable ASCII representations of
//	hex byte nybbles.  EOL may be <cr> and/or <lf>.  All other characters outside the defined
//	fields are ignored.
//	Valid "S0" formats:
//	"S0-oooooo"		sets new offset value (24b hex, with 32b 2's complement applied)
//	"S0+oooooo"		sets new offset value (24b hex, added-to in-bound address)
//	"S0b"			"b" is valid hex digit, sets bank for bank-selected DUTs
//	"S0<spc>..."	A comment line, ignored by the record processor
//-----------------------------------------------------------------------------
char process_sline(U8 dmode, char* obuf, U32* offset){
#define SR_TYPE 1				// Srec type pointer
#define	SR_LEN	2				// Srec length pointer
#define SR_ADDR 4				// Srec target ADDR pointer
#define SR_DATA1 8				// start of Srec data pointer
#define SR_DATA2 10				// start of Srec data pointer

#define IR_TYPE 7				// Irec type pointer
#define	IR_LEN	1				// Irec length pointer
#define IR_ADDR 3				// Irec target ADDR pointer
#define IR_DATA 9				// start of Irec data pointer
#define CHKSERR	0x80			// line checksum error

	char	status = 0;
	char	c;
	char	typ = 0;
//	char*	optr = obuf;		// holding reg for start of obuf
	U8		t;					// temp
	U8		len;				// s rec length
	U8		chksp;				// ptr to chksum
	U32		addr;				// addr ptr
	U8		i;					// looping temp/gp pointer

	if((toupper(srbuf[0]) == SRSTART) && (srbuf[SR_TYPE] == '0')){
		status = 0;													// any buffer is OK if S0
	}else{
		for(i=1; i<srptr; i++){
			status |= valid_hex(srbuf[i]);							// see if buffer is all valid hex
		}
	}
	if(status == 0){
		if(srbuf[0] == SRSTART){
			typ = srbuf[SR_TYPE];									// extract S type
		}else{
			typ = get_byte(IR_TYPE);								// extract I type
		}
		switch(typ){
			case '0':												// embeded pgmr command record (SREC)
				c = srbuf[SR_LEN];
				if((c == '-') || (c == '+')){						// process embedded offset
					offset_0 = ((U32)get_byte(3)) << 8;
					offset_0 |= ((U32)get_byte(5));
					offset_0 <<= 8;
					offset_0 |= ((U32)get_byte(7));
					if(c == '-') offset_0 = ~offset_0 + 1L;			// apply 2's complement to subtract
				}else{
					i = asc_hex(c);									// get high-order address nybble
					if(i != 0xff){									// if valid, update S0 mem (implied else: ignore if non-hex digit)
						s0_mem = i;
					}
				}
				break;

			case '1':												// S1 data record
			case '2':												// S2 data record
				t = 0;
				len = get_byte(SR_LEN);								// get record length
				chksp = (len * 2) + SR_LEN;							// calc pointer to checksum
				for(i = SR_LEN; i < chksp; i += 2){					// calc srec chksum
					t += get_byte(i);
				}
				t = ~t;
				if(t != get_byte(chksp)) status = CHKSERR;			// if checksum invalid, set chkserr
				addr = ((U32)get_byte(SR_ADDR)) << 8;
				addr |= ((U32)get_byte(SR_ADDR+2));
				if(typ == '1'){
					addr <<= 8;
					addr |= ((U32)get_byte(SR_ADDR+4));
					addr = ((U32)(s0_mem) <<16);					// form new address with s0_mem for high-bits
				}
				if(typ == '2'){
					addr <<= 8;
					addr |= ((U32)get_byte(SR_ADDR+4));
				}
				addr = addr + *offset + offset_0;					// update address with offset adjust
				if(typ != '0'){
/*					if(dmode == PD_QEMBED){
						i = SR_DATA;								// init data pointer
						do{
							c = get_byte(i);						// get byte from S0 line
							i += 2;
							if(c == '\0') c = ' ';					// convert nulls to spaces
							if(c != '\n') *obuf++ = c;				// put in buffer (except newline)
						}while((c != '\n') && (i < chksp));
						*obuf = '\0';
						if(!xmode) putsQ(optr);					// send bcmd line to display
					}else{
						process_bcmd(0, BCMD_CLEAR);
						for(i = SR_DATA; i < chksp; i += 2){
							process_bcmd(get_byte(i), BCMD_STORE); // copy data into command buff
						}
//						if(process_bcmd(0, BCMD_QERY)) exec_bcmd(bcmdbuf, obuf, &offset);
//						else process_bcmd(0, BCMD_CLEAR);
					}*/
//				}else{
					switch(dmode){
					default:
						break;

					case PD_STOR:
						sram_write_start(addr);					// move data to mem
						break;

					case PD_VRFY:								// verify data against mem
						sram_read_start(addr);
						break;
					}
					if(typ == '1'){
						i = SR_DATA1;
					}else{
						i = SR_DATA2;
					}
					for(; i < chksp; i += 2){
						process_data(addr++, get_byte(i), dmode);	// move/vfy data to mem
					}
					sram_close();
				}
				break;

			case 0x00:						// I data record
				t = 0;
				len = get_byte(IR_LEN);								// get record length
				chksp = (len * 2) + 9;								// calc pointer to checksum
				for(i = IR_DATA; i < chksp; i += 2){				// calc irec chksum
					t += get_byte(i);
				}
				t = (~t) + 1;
				if(t != get_byte(chksp)) status = 0x80;				// if checksum invalid, set chkserr
				addr = (((U16)get_byte(IR_ADDR)) << 8) & 0xff00;
				addr |= ((U16)get_byte(IR_ADDR+2)) & 0xff;
				addr -= RAM_START;
				for(i = IR_DATA; i < chksp; i += 2){
					process_data(addr++, get_byte(i), dmode);		// move/vfy data to mem
				}
				break;

			case 0x01:						// Irecord end
			case '9':						// Srecord end
			case '8':						// Srecord end
				status = myEOF;
				break;

			default:						// un-recognized records
				break;
		}
	}
	return status;
}

//-----------------------------------------------------------------------------
// get_sline() gets an srecord or irecord line into the srecord buffer.
//	If an abort char (CAN, EOT, ESC, or EOF) is encountered, processing stops
//	and the Fn returns the abort character.  Else, returns 0
//-----------------------------------------------------------------------------
char get_sline(char* sptr){

	char	status = 0;
	char	c = 0;

	do{											// look for srec start
		while(!c){
			c = gotchr();						// wait for any chr
		}
		if(xmode){
			switch(c){
				case XMOD_ABORT:				// if xmodem, look for abort conditions
				case XMOD_ERR:
				case XMOD_DONE:
					return EOT;
//					break;
			}
		}
		c = toupper(getchr());					// convert input to upcase
	}while((c != SRSTART) && (c != IRSTART) && !abort_char(c)); //repeat until a valid start is found, or abort
	srptr = 0;									// init s-rec pointer to start
	while(!endofrec(c)){						// until end of record,
		if((c >= ' ') && (c <= 127)){			// first pass uses previous getchr() call
			csum = calcrc(c, csum, XPOLY);		// srec character CRC
			srbuf[srptr++] = toupper(c);		// if printable ascii, put in buffer
		}
		c = getchr();
	}
	if(!xmode && handshake){
		putcharQ(XOFF);							// turn off remote source if not xmodem
		xoffsent = TRUE;
	}
	srbuf[srptr] = '\0';						// null terminate
	if(abort_char(c)) status = c;
	return status;



/*
	char	c = 0;

	do{											// look for srec start
		c = *sptr++;							// get chr
//		c = toupper(c);							// convert input to upcase
	}while((c != SRSTART2) && (c != SRSTART) && (c != IRSTART) && !abort_char(c)); //repeat until a valid start is found, or abort
	srptr = 0;									// init s-rec pointer to start
	while(!endofrec(c)){						// until end of record,
		if((c >= ' ') && (c <= 127)){			// first pass uses previous getchr() call
			csum = calcrc(c, csum, XPOLY);	// srec character CRC
			srbuf[srptr++] = toupper(c);		// if printable ascii, put in buffer
		}
		c = *sptr++;
	}
	srbuf[srptr] = '\0';						// null terminate
	return c;*/
}

//-----------------------------------------------------------------------------
// process_data() takes data and performs store or compare based on data mode
//	(dmode) parameter.
//-----------------------------------------------------------------------------
U32 process_data(U32 addr, U8 d, U8 dmode){

	static U8	status;
	static U32	faddr;
	U32			rtn;

	rtn = (U32)status;
	switch(dmode){
		default:
			status |= 0xf0;							// system fault
			rtn = (U32)status;
			break;

		case PD_INIT:
			status = PD_OK;
			faddr = 0;
			rtn = (U32)status;
			break;
		
		case PD_STOR:
			csum2 = calcrc(d, csum2, XPOLY);		// calc data CRC
			sram_write(addr, d);					// move data to mem
			break;

		case PD_VRFY:								// verify data against mem
			csum2 = calcrc(d, csum2, XPOLY);		// calc data CRC
			if(sram_read(addr) != d){
				status |= PD_VERR;
				faddr = addr;
				rtn = (U32)status;
			}
			break;

		case PD_QEMBED:								// queries...
		case PD_QERY:								// just send status
			break;

		case PD_QERYH:								// just send faddr
			rtn = faddr;
			break;
	}
	return rtn;
}

//-----------------------------------------------------------------------------
// process_bcmd() stores data to embedded command buffer.  Allows pgmr cmds to
//	be embedded in the object data as "S0" records.
//	returns TRUE if no errors.  If FALSE, cmd buffer was overflowed (do not use)
//	must add '\0' to end of bcmdbuf after record EOF
//-----------------------------------------------------------------------------
char process_bcmd(U8 d, U8 cmd){

	static	char	status;

	switch(cmd){
		case BCMD_STORE:						// store data to buffer, update status
			if(bcmdptr < BCMD_BUFLEN) bcmdbuf[bcmdptr++] = d;
			else status = FALSE;
			break;

		case BCMD_CLEAR:						// init pointer and status (no store)
			status = TRUE;
			bcmdptr = 0;
			bcmdbuf[bcmdptr] = '\0';
			break;

		default:
		case BCMD_QERY:							// NOP, just return status
			break;
	}
	return status;
}

//-----------------------------------------------------------------------------
// endofrec() tests for an abort char: CAN, EOT, ESC, or EOF or EOL
//	returns TRUE if abort chr detected
//-----------------------------------------------------------------------------
char endofrec(char c){

	char	tf;

	switch(c){
		case EOT:
		case ESC:
		case myEOF:
		case CAN:
		case '\r':
		case '\n':
			tf = TRUE;
			break;
		
		default:
			tf = FALSE;
			break;
	}
	return tf;
}

//-----------------------------------------------------------------------------
// abort_char() tests for an abort char: CAN, EOT, ESC, or EOF
//	returns TRUE if abort chr detected
//-----------------------------------------------------------------------------
char abort_char(char c){

	char	tf;

	switch(c){
//		case '\0':
		case EOT:
		case ESC:
		case myEOF:
		case CAN:
			tf = TRUE;
			break;
		
		default:
			tf = FALSE;
			break;
	}
	return tf;
}

//-----------------------------------------------------------------------------
// get_byte(p) gets converts 2-byte ascii hex at srbuf[p] and returns
//-----------------------------------------------------------------------------
U8 get_byte(U8 p){

	U8	b;			// byte value
	
	b = asc_hex(srbuf[p++]) << 4;
	b |= asc_hex(srbuf[p]);
	return b;
}

//-----------------------------------------------------------------------------
// asc_hex() converts ascii hex to binary nybble and returns
//-----------------------------------------------------------------------------
/*
U8 asc_hex(char c){

	U8	b;			// byte value
	
	b = (U8)c - '0';
	if(b > 9) b -= 'A' - '9' - 1;
	return b;
}*/

//-----------------------------------------------------------------------------
// valid_hex() tests for a valid hex chr (returns 0x00 if valid, 0x80 if not valid)
//	a valid hex is any ascii from '0' to '9' or 'A' to 'F' (assumes upcase input)
//-----------------------------------------------------------------------------
char valid_hex(char c){

	if(c < '0') return 0x80;
	if(c > 'F') return 0x80;
	if((c > '9') && (c < 'A')) return 0x80;
	return 0x00;
}

//-----------------------------------------------------------------------------
// process_stx() sends srecord lines to serial port.  Data from addrstart to
//	addrstop.  addrstop is the last byte to be sent
//-----------------------------------------------------------------------------
void process_stx(U32 addrstart, U32 addrstop, U8 type, U8 source){
#define	DEF_SLEN 32

	U32	addr = addrstart;	// running addr reg
	U32	temp;				// temp
	U8	len;				// srec data length
	U8	lastline = FALSE;	// last line flag
	char sbuf[10];

	s0_mem = 0xff;									// init S0 trigger
	csum = 0;										// init CRCs
	csum2 = 0;
	set_dev(0xff, 0);								// prine bank change in case it is a bank'd part
	while((!lastline) && (bchar != ESC)){
		temp = addrstop - addr;						// calc # bytes left to send
		if(temp <= DEF_SLEN){						// if at or less than deflen, do last line
			len = (U8)(temp & 0xff);				// set last line length
			lastline = TRUE;						// set exit flag
		}else{
			len = DEF_SLEN;							// not last, use default length
		}
		if(type == 2){
			addr = put_sline(source, addr, len, 2);	// send line to serial port
		}else{
			addr = put_sline(source, addr, len, 1);	// send line to serial port
		}
	}
	if(bchar != ESC){ 								// EOF record
		if(type == 2){
			put_sline(source, 0, 0, 8);
		}else{
			put_sline(source, 0, 0, 9);
		}
	}
	sprintf(sbuf,"%04x\n", csum2);
	putssQ("payload CRC: $");
	putssQ(sbuf);
	sprintf(sbuf,"%04x\n", csum);
	putssQ("   file CRC: $");
	putssQ(sbuf);
}

//-----------------------------------------------------------------------------
// put_sline() writes an srecord to the serial port
//	returns next SRAM addr to be read
//	source = 0 for SRAM, 1 for DUT
//	addr = start addr
//	len = record length
//	rectype = record type ("1", "2", "8", or "9")
//-----------------------------------------------------------------------------
U32 put_sline(U8 source, U32 addr, U8 len, U8 rectype){

	U8	chks;				// chks temp
	U8	i;					// loop temp
	U8	d;					// data temp
	U8	addr_24;

	if(rectype == 1){								// look for a change in the 24b address field
		addr_24 = (U8)(addr>>16);
		if(addr_24 != s0_mem){						// update 24b addr mem & send S0 record with upper addr byte
			s0_mem = addr_24 ;
			putc_crc('S');
			putc_crc('0');
			putc_crc(hex_asc(s0_mem));				// encodes A[19:16] as "S0n" where "n" = hex nybble
			putcharQ('\n');
		}
	}
	putc_crc('S');									// start of line
	putc_crc(hex_asc(rectype));						// type
	if((rectype == 2) || (rectype == 8)){
		chks = len + 4;
		put_byte(len+4);							// length for 24b addr
	}else{
		chks = len + 3;
		put_byte(len+3);							// length for 16b addr
	}
	if((rectype == 2) || (rectype == 8)){
		d = (U8)(addr >> 16);						// addr24
		chks += d;
		put_byte(d);
	}
	d = (U8)(addr >> 8);							// addr16
	chks += d;
	put_byte(d);
	d = (U8)(addr & 0x00ff);						// addr8
	chks += d;
	put_byte(d);
	for(i = 0; i < len; i++){						// data
		if(source == DUT_SRC){
			d = dataio(addr, 0, RD);
		}else{
			d = sram_read(addr);
		}
		csum2 = calcrc(d, csum2, XPOLY);			// calc payload CRC
		chks += d;
		put_byte(d);
		addr++;
	}
	put_byte(~chks);								// s-rec checksum
	putcharQ('\n');									// EOL
//	putcharQ('\r');
	if(bchar == ESC){
		bchar = '\0';									// clear global escape flag
		addr = 0;
	}
	wait(10);
	return addr;
}

//-----------------------------------------------------------------------------
// putc_crc(p) wraps a crc around putchar traffic
//-----------------------------------------------------------------------------
void putc_crc(char d){

	csum = calcrc(d, csum, XPOLY);
	putcharQ(d);
	return;
}

//-----------------------------------------------------------------------------
// ram_pattern_pass() fills sram ($8000-ffff) with a test pattern, then verifies
//	return TRUE if pass, else FALSE
//	This is a system test function to validate the external SRAM
//-----------------------------------------------------------------------------
char ram_pattern_pass(void){

	U16	addr = 0x0000;	// addr pointer
	U16	pattern = 0xfff0;
	U16	d;
	char v = TRUE;
	
	do{
		dut_xdata[addr++] = (U8)(pattern >> 8) & 0xff;
		dut_xdata[addr++] = (U8)(pattern--);
	}while(addr != RAM_LEN);
	addr = 0x0000;	// addr pointer
	pattern = 0xfff0;
	do{
		d = (U16)dut_xdata[addr++] << 8;
		d |= (U16)dut_xdata[addr++] & 0xff;
		if(d != pattern--){
			v = FALSE;
		}
	}while(addr != RAM_LEN);
	return v;
}

//-----------------------------------------------------------------------------
// put_byte(p) gets converts U8 to 2-byte ascii hex and sends to serial port
//-----------------------------------------------------------------------------
void put_byte(U8 d){
	
	putc_crc(hex_asc(d >> 4));
	putc_crc(hex_asc(d));
}

//-----------------------------------------------------------------------------
// hex_asc(p) converts binary nybble to ascii hex and returns
//-----------------------------------------------------------------------------
char hex_asc(U8 c){

	char b;

	b = (char)(c & 0x0f) + '0';			// add '0' to convert decimal nyb to ascii
	if(b > '9') b += 'A' - '9' - 1;		// if hex, add ("A' - '9' - 1) to get ascii
	return b;
}
/*
//-----------------------------------------------------------------------------
// toupper does upcase task
//-----------------------------------------------------------------------------
char	toupper(char c){
	char	i=c;

	if((c>='a') && (c<='z')){
		i = c - 'a'-'A';
	}
	return i;
}*/
