/********************************************************************
 ************ COPYRIGHT (c) 2024 by KE0FF, Taylor, TX   *************
 *
 *  File name: spi.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  ssi driver for RDU LCD controller IC
 *
 *******************************************************************/

#include <ctype.h>
#include <math.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions
#include "version.h"
#include "spi.h"
#include "serial.h"
#include "busio.h"

// ******************************************************************
// defines

// ******************************************************************
// declarations

// BBSPI regs
#ifdef BBSPI
			U8	spidr;
			U8	spimsk;
#endif
// SPI input buffer
volatile	U32	ssitimer;				// ssi timer
volatile	U8	cs_reg;

void wait_cs(void);
void wait_d(U8 count);
void sram_modes(U8 cs);


// ******************************************************************
// ***** START OF CODE ***** //

//////////////////
// init_ssi0 initializes SSI0 as an 8-bit slave
//
void init_ssi0(void)
{
	volatile U8	i;

#ifdef BBSPI
	spidr = 0;
	spimsk = 0x80;
	// config SCLK rising edge ISR, CSS falling edge flag
	GPIO_PORTA_IM_R = 0;
	GPIO_PORTA_IEV_R = SCLK;								// rising edge for SCLK (falling edge for CSS)
//	GPIO_PORTA_IBE_R &= ~(SCLK|CSS);						// one edge
//	GPIO_PORTA_IS_R &= ~(SCLK|CSS);							// edge ints
	GPIO_PORTA_ICR_R = 0xff;								// clear int flags
	GPIO_PORTA_IM_R = SCLK;									// only interrupt on SCLK
	ssitimer = 0;
	NVIC_EN0_R = NVIC_EN0_GPIOA;							// enable GPIOA intr in the NVIC_EN regs
	kick_ssito();
#endif

#ifndef BBSPI
	GPIO_PORTA_DATA_R |= CSRAM_N;							// disable SRAM CS
	SYSCTL_RCGCSSI_R |= SYSCTL_RCGCSSI_R0;					// activate SSI0
	GPIO_PORTA_AFSEL_R |= SCLK|MOSI|MISO;					// enable alt funct on PA2/4/5
	GPIO_PORTA_PCTL_R |= GPIO_PCTL_PA2_SSI0CLK | GPIO_PCTL_PA4_SSI0RX | GPIO_PCTL_PA5_SSI0TX;
	GPIO_PORTA_AMSEL_R &= ~(SCLK|MISO|MOSI);				// set ssi pins = digital
	SSI0_CR1_R = 0;											// disable SSI, master mode
	// Set bit rate & bit width:
	// CPSDVR = 248, SCR = 41 for 50MHz SYSCLK gives 4800.3 baud
	// BR = SYSCLK/(CPSDVSR * (1 + SCR))
	// SCR = (SYSCLK/(BR * CPSDVSR)) - 1
	// see SSICLK_calc.xls for minimum error values for CPSDVSR and SCR
	SSI0_CPSR_R = CPSDVSR;
	// SCR = [15:8], SPH[7] = 1, SPO[6] = 1, Freescale, DSS = 8 (8-bit data)
	SSI0_CR0_R = (SCRVAL << 8) | SSI_CR0_DSS_8 | SSI_CR0_FRF_MOTO;		// bit rate, clock ph/pol, #bits
	SSI0_CC_R = 0;														// SYSCLK is the clk reference for SSI1
//	SSI0_IM_R = SSI_IM_RXIM | SSI_IM_RTIM;					// enable ISR
	SSI0_CR1_R &= ~SSI_CR1_MS;								// SSI = master
	SSI0_CR1_R |= SSI_CR1_SSE;								// enable SSI
//	while(SSI0_MIS_R | (SSI0_SR_R & SSI_SR_RNE)){			// flush data buffer
//		i = SSI0_DR_R;
//	}
	ssitimer = 0;
//	NVIC_EN0_R = NVIC_EN0_SSI0;								// enable SSI0 isr
#endif

	sram_modes(0);
	sram_modes(2);
	return;
}

//////////////////
// sram_read_start() starts a read operation (seq. mode) from the IS62256
//
void sram_read_start(U32 addr){
	U8	i;
	U8	aa;
	volatile U8	j;

	if(addr >= CS_ADDRHI) cs_reg = CSRAM2_N;
	else cs_reg = CSRAM_N;
	while(SSI0_SR_R & SSI_SR_BSY);
	GPIO_PORTA_DATA_R &= ~cs_reg;							// enable SRAM CS
	wait_cs();
	SSI0_DR_R = SRAM_READ;
	aa = (U8)(addr >> 16);
	SSI0_DR_R = aa;											// 24b address
	aa = (U8)(addr >> 8);
	SSI0_DR_R = aa;
	aa = (U8)addr;
	SSI0_DR_R = aa;
	wait_d(8);
	for(i=0; i<4; i++) j = SSI0_DR_R;						// clear RX FIFO
	return;
}

//////////////////
// sram_write_start() starts a write operation (seq. mode) from the IS62256
//
void sram_write_start(U32 addr){
	U8	i;
	volatile U8	j;

	if(addr >= CS_ADDRHI) cs_reg = CSRAM2_N;
	else cs_reg = CSRAM_N;
	while(SSI0_SR_R & SSI_SR_BSY);
	GPIO_PORTA_DATA_R &= ~cs_reg;								// enable SRAM CS
	wait_cs();
	SSI0_DR_R = SRAM_WRITE;
	SSI0_DR_R = (U8)(addr >> 16);							// 24b address
	SSI0_DR_R = (U8)(addr >> 8);
	SSI0_DR_R = (U8)addr;
	wait_d(16);
	while(SSI0_SR_R & SSI_SR_BSY);
	for(i=0; i<4; i++) j = SSI0_DR_R;						// clear RX FIFO
	return;
}

//////////////////
// sram_modes() starts a write operation (seq. mode) from the IS62256
//
void sram_modes(U8 cs){
	volatile U8	i;

	while(SSI0_SR_R & SSI_SR_BSY);

	if(cs) GPIO_PORTA_DATA_R &= ~CSRAM2_N;					// enable SRAM CS
	else GPIO_PORTA_DATA_R &= ~CSRAM_N;
	wait_cs();
	SSI0_DR_R = SRAM_MODE;
	SSI0_DR_R = SRAM_SEQ;									// 24b address
	GPIO_PORTA_DATA_R |= CSRAM_N | CSRAM2_N;				// close SRAM CS
//	wait_cs();
	wait_d(5);
	i = SSI0_DR_R;											// clear RX FIFO
	i = SSI0_DR_R;
	return;
}

//////////////////
// sram_close() ends a session with the IS62256
//
void sram_close(void){

	wait_cs();
	while(SSI0_SR_R & SSI_SR_BSY);
	GPIO_PORTA_DATA_R |= CSRAM_N | CSRAM2_N;				// disable SRAM CS
	wait_cs();
	return;
}

//////////////////
// wait_cs() adds setup/hold time to CS edge (15us)
//
void wait_cs(void){
	wait_lat(15);

/*	volatile U32	i;

	for(i=0; i<100; i++);									// 500 ~~ 75us*/
	return;
}

//////////////////
// wait_d() delays for bytes to send (delay = d * 54uS)
//
void wait_d(U8 count){
	volatile U8		j;

	for(j=0; j<count; j++){
		wait_lat(54);
	}
	return;
}

//////////////////
// sram_read() sreads data (seq. mode) from the IS62256
//
U8 sram_read(U32 addr){

	if((addr >= CS_ADDRHI) && (cs_reg == CSRAM_N)){
		sram_close();
		sram_read_start(addr);								// switch to next bank
	}
	SSI0_DR_R = 0;											// dummy write
	wait_d(1);
	// wait for byte ready
	while(!(SSI0_SR_R & SSI_SR_RNE));
	return SSI0_DR_R;										// read data
}

//////////////////
// sram_write() sends data (seq. mode) to the IS62256
//
void sram_write(U32 addr, U8 data){
	volatile U8	i;

	// wait if fifo full
	while(!(SSI0_SR_R & SSI_SR_TNF));
	if((addr >= CS_ADDRHI) && (cs_reg == CSRAM_N)){
		sram_close();
		sram_write_start(addr);								// switch to next bank
	}
	SSI0_DR_R = data;										// write output data
	wait_d(1);
	i = SSI0_DR_R;											// clear FIFO
	return;
}

//-----------------------------------------------------------------------------
// is_ssito() returns true if ssitimer == 0
//-----------------------------------------------------------------------------
U8 is_ssito(void){

	if(ssitimer == 0){
		return 1;
	}
	return 0;
}

//-----------------------------------------------------------------------------
// kick_ssito() resets ssitimer
//-----------------------------------------------------------------------------
void kick_ssito(void){

	ssitimer = SSITO_TIME;
	return;
}

//-----------------------------------------------------------------------------
// Timer1B_ISR() drives SPI TO timer
//-----------------------------------------------------------------------------
//
// Called when timer 1B overflows (NORM mode):
//	Timer1_B runs as 16 bit reload timer set to 10ms interrupt rate
//	Provides a time-out timer resource to the SSI driver
//
//-----------------------------------------------------------------------------

void Timer1B_ISR(void){

//	GPIO_PORTF_DATA_R ^= sparePF3;
	// set flag to trigger bit
	if(TIMER1_MIS_R & TIMER_MIS_TBTOMIS){
		if(ssitimer){										// update ssi timer
			ssitimer--;
		}
	}
	// clear ISR flags
	TIMER1_ICR_R = TIMER1_MIS_R & TIMERB_MIS_MASK;
//	GPIO_PORTF_DATA_R ^= sparePF3;
	return;
}

