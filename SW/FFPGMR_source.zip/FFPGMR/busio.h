/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.h
 *
 *  Module:    Control, FFPGMR, MK-II
 *
 *  Summary:   defines and global declarations for busio.c
 *
 *******************************************************************/

//#ifndef	INLC_BUSIO
extern	U8	reg_ahh;
extern	U8	reg_ah3;
//#endif

#define	INLC_BUSIO

#define	DEVRST	0xff
#define	RD	0
#define	WR	1
#define	DLYQ	80
#define	CDLY	16

// voltage set defines
#define	VCC_SHFT	3
#define	VCC_424		0
#define	VCC_500		(1<<VCC_SHFT)
#define	VCC_600		(2<<VCC_SHFT)
#define	VCC_625		(3<<VCC_SHFT)
#define	VCC_650		(4<<VCC_SHFT)
#define	VCC_MASK	(VCC_SEL0|VCC_SEL1|VCC_SEL2)

#define	VPP_SHFT	6
#define	VPP_050		0
#define	VPP_120		(1<<VPP_SHFT)
#define	VPP_122		(2<<VPP_SHFT)
#define	VPP_127		(3<<VPP_SHFT)
#define	VPP_MASK	(VPP_SEL0|VPP_SEL1)

#define	OEVPP_BIT	0x80		// semaphore mask for WEE -- if set, this semaphone signals that VPP is turned on/off with the PGM cycle


// us time delay defines
//	all of the following represent time delays in us
#define	LAT_SETUP		2
#define	LAT_HOLD		2
#define	BUS_DLY			1
#define	BUSG_DLY		2		// 27C512
#define	DATA_HOLD		1
#define	PGM_HOLD		10		// FLASH param
#define	VFY_HOLD		6		// FLASH param
#define	WRITE_HOLD		1
#define	READ_HOLD		1
#define	DLY_6US			6
#define	DLY_10US		10
#define	DLY_200US		200
#define	DLY_01MS		1000
#define	DLY_10MS		10000


//void	wrport_ahh(U8 set, U8 clear);
//void	wrport_ah3(U8 set, U8 clear);
U8		read_ahh(void);
U8		read_ah3(void);
void	set_vcc(U8 voltmask);
void	set_vpp(U8 voltmask);

void	put_addr(U32 addr);
U8		dataio(U32 addr, U8 data, U8 dir);
U8		datapv(U32 addr, U8 data, U8 gvpp);
void	dutpwr(U8 on);
void	vcc(U8 on);
void	vpp(U8 on);
void	vppf(U8 on);
void	skt(U8 id);
void	set_dev(U8 dev);
U8		fast_read(void);
void	fast_write(U8 d);
void	ffast_write(U8 d);
U8		ffast_read(void);
U8		fast_pgm_vfy(U8 d);
U8		fast_pgm_vfy_040(U32 addr, U8 d);
U8		fast_era_040(void);
U8		fast_pgm_vfy_020(U8 d);
U8		fast_era_020(void);
U8		byte_flash(U32 addr, U8 data);
void	set_addr(void);
U8		ds1216e_bit(U8 wrbit, U8 write);
U8		ds1216c_bit(U8 wrbit, U8 write);
//void	wait_lat(U16 numus);
void	vpp_oe(U8 set);
void	vppoe_wr(U16 dly);
void	set_we(U8 bitmask);
void	set_we_dly(U16 dly);

////////////////////////////////////////////////////////////
// inlines

//=============================================================================
// wait_lat() GPIO settling/pacing delay defined as an inline-function
//	numus is the number of us to delay (1 to 65535 us)
//=============================================================================
extern inline void	wait_lat(U32 numus){

	TIMER2_TAILR_R = ONEUSL * numus;
	TIMER2_ICR_R = TIMER2_RIS_R;					// clear all T2 flags
	TIMER2_CTL_R |= (TIMER_CTL_TAEN);				// enable timer
	while(!TIMER2_RIS_R);
	TIMER2_CTL_R &= ~(TIMER_CTL_TAEN);				// disable timer
}

//=============================================================================
// wrport_ahh() & wrport_ah3() sets/clears port bits an updates local port register
//	"set" identifies bits to be set in the port if 1
//	"clear" identifies bits to clear if zero
//=============================================================================
extern inline void wrport_ahh(U8 set, U8 clear){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ahh &= ~clear;							// update local register
	reg_ahh |= set;
	GPIO_PORTB_DATA_R = reg_ahh;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTC_DATA_R |= LAT_AHH;				// pulse addr high latch
	wait_lat(LAT_HOLD);									// hold time
	GPIO_PORTC_DATA_R &= ~LAT_AHH;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}

extern inline void wrport_ah3(U8 set, U8 clear){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ah3 &= ~clear;							// update local register
	reg_ah3 |= set;
	GPIO_PORTB_DATA_R = reg_ah3;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTA_DATA_R |= LAT_AH3;				// pulse addr high latch
	wait_lat(LAT_HOLD);							// hold time
	GPIO_PORTA_DATA_R &= ~LAT_AH3;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}

extern inline void stor_port_ah3(U8 set){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ah3 = set;
	GPIO_PORTB_DATA_R = set;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTA_DATA_R |= LAT_AH3;				// pulse addr high latch
	wait_lat(LAT_HOLD);							// hold time
	GPIO_PORTA_DATA_R &= ~LAT_AH3;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}
