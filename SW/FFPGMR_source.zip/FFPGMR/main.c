/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  This is the main code file for the FFPGMR, MK-II application.
 *
 *******************************************************************/

/********************************************************************
 *  Project scope rev notes:
 *  !! The TI datasheet lies !! UART: configuring 2 stop bits requires 2 stop bits for RX also
 *
 *  Summary
 *  This project produces a FLASH/EEPROM programmer with a path towards EPROM programming.  Bank-switched EPROMS
 *  	(27C513 & 27C011) are currently supported for read operations only.  A serial SRAM is provided on SSI0
 *  	to allow for temporary storage of read/write data.  Port B is the main data path for ADDR and DATA I/O.
 *  	Address bits A16+ are provided by MCU GPIO as are the various VPP, VCC, and bus control signals.
 *
 *	While the initial device targets were 28F101 and 28C64 for read/write operations, and 27C011 for read operations only,
 *	the HW and SW has been upgraded to support EPROM, FLASH, or EEPROM devices up to 4Mb (512K x 8) in 28 or 32 pin DIP
 *	packages (PLCC with adapter).
 *
 *	Command-line interface supports Xmodem upload of s-record data (S19 and S28 records supported). 4Mb of SRAM holds
 *	the target data. Blank-check, PGM, Erase, VFY, and MFR/DEV auto-select form the core command set.  Additionally, Utility
 *	commands are provided to read SRAM and DUT data, verify SREC data against SRAM, and also fill constant or pattern data
 *	into the SRAM space.
 *
 *	An abort switch allows the DUT socket to be placed into "safe-mode" quickly.  Aborts any command in progress and turns
 *	off power to the DUT socket.
 *
 *    Version 0.9:
 *    04/18/26 jmh	 Finally got EPROM algorithms to work (again).  Tested on 27010 and 27011.  Need to work on OE/VPP EPROMS
 *    					(pgm_ep1 & pgm_ep2).  Several issues were in play.  Needed to do an SRAM close Fn call after programming
 *    					to re-synch SPI interface to SRAMs.  Also broke out EPROMs into 3 sub-types: 0) /WR/PGM controlled,
 *    					1) /CS controlled, and 2) /CS controlled with VPP toggling (1 & 2 still need to be coded).  Need also
 *    					to look at algorithms and see if more sub-types might be needed.  Need better documentation for all
 *    					this!!!  Mea Culpa.
 *    				 "vfy" now has separate fork for EPROMs vs. other memory types.  A VCC option allows the vfy to be executed
 *    				 	at a specific VCC (default is at max/min).
 *    04/16/26 jmh	 Modified "dvt" command to test GAL_PGMR fetures.  allows control signals used by the PGMR to be
 *    					manipulated. Manipulations all tested. GAL Vedit select works.  Moved SDOUT read to the BUSY input
 *    					to avoid adding additional decode logic.
 *    04/15/26 jmh	 Tested GAL_PGMR AUTOSELECT (works).  "gal16" is now device id for the GAL_PGMR module.  "pal10" is the
 *    					"de-program" code to read out a combinatorial, 20-pin PAL (different adapter, no autoselect).
 *    				 Checked device ordering and updated enum comments.
 *    04/11/26 jmh	 Re-Added 10L8 PAL read function. Increased "memory" size to $200 (A8 is now pull-up/pull-dn for
 *    					GAL16/PAL10 parts). This function will be retained to allow "reading" PALs for independent
 *    					verification in the future.
 *    				 Made 1216e/c commands use lower case.
 *    03/10/26 jmh	 {UN-deprecated} Added 10L8 PAL read support (no pgm yet)
 *    03/09/26 jmh	 Started adding hooks for GAL programming adapter support.  Autoselect code 0xbeef assigned as GAL adapter
 *    				 	ID (it violates parity so it will not be a valid memory device code).  This code will now be passed
 *    				 	back to the calling Fn to allow the GAL adapter to be identified by the autoselect mechanism.
 *
 *    Version 0.8:
 *    12/31/25 jmh	 Fixed STK11C88 A14 -- SRAM address 14 aligns with EPROM/FLASH address 15.  Affects 32K+ JEDEC SRAMS.
 *    					Requires that SET_VPPA15 be "OFF" in the device config meta-data.
 *    				 Added <-w> "word" mode to FILL command (big-endian).  Allows 16b values to be filled into SRAM.
 *    				 Copied in the PortF-5 CSDUT SW to align with new hardware configuration.
 *    				 DEPRECATED: all references to SW1 (PF4 is now CSDUT_N).
 *
 *	  Version 0.71:
 *	  05-31-25 jmh	 Added write support for DS1216E and included detailed help for the "clk" command.
 *	  				 Increased ARG_MAX to 10.
 *	  				 Added 27011 device (MFR/DEV 0x8985) same as 27C011.
 *	  				 Reinstated listing of devices in "DEV ?" help.
 *
 *	  Version 0.6:
 *	  01-10-24 jmh	 Fixed bug in S1 record upload.
 *	  				 Modified upl help to improve clarity of syntax
 *
 *	  Version 0.5:
 *	  09-09-24 jmh	 28C64 working (again???). Not sure what was wrong overall.  PGM is very slow (6x too slow) but not sure why.
 *	  					erase wasn't activating WE_N, is now working.
 *	  				 Added STK11C68/88 devices and sto/rcl commands.
 *	  				 Added chks command.  Calcs chks/crc on a range of SRAM, and stores the result at a specified address. Allows
 *	  				 	big or lil' endian.  chk may also be used to manually store data words to SRAM.
 *	  09-08-24 jmh	 Re-organized EPROM algorithm for OE/VPP devices to turn off VPP for read rather than turning on for PGM.
 *	  					increases settling time for VPP restoration and allows PGM to be successful.
 *	  				 Added cmd_fn step to strip "0x" prefixes and replace with "$" to allow either method of specifying HEX values.
 *	  				 Removed unused floaters from cmd_fn code.
 *	  				 Added/edited help text.
 *	  08-28-24 jmh	 Expanded DUT-OFF/Abort switch to include SW1 (PF4).  Either SW1 or SW2 will trigger the abort.  Found that PortF
 *	  					PUR was not being set.  Added code to init the PortF PUR.
 *	  08-26-24 jmh	 Added DUT-OFF/Abort switch (PF0).  Captured in timer ISR, activating the switch triggers the DUT to power off
 *	  					and an ESC trap issued to the CLI bchar register.  Uses a simple state machine to trap SW2 FE and RE.
 *	  						ABORT idles in state 0. At SW2 (PF0) FE, Timer3A sends a signal to serial.c to set bchar = ESC,
 *	  							simulating an ESC keypress.  dutpwr(0) is called to turn off power to the DUT.  The debounce
 *	  							timer is set to 50ms and the abort logic enters state 1.
 *	  						Process_IO() sends console message and sets the state to 2
 *	  						State 2 waits for SW2 RE. At SW2 RE, the debounce timer is set to 50ms to prevent a false FE trap,
 *	  							and the state is set to 0.  SW2 is rearmed when the debounce timer expires.
 *	  08-24-24 jmh	 Still a lot of churn over mfr command.  Finally have a reasonably stable system.  A number of scattered bugs
 *	  					was causing problems.  27C020 still has a sporadic failure to read the codes, but this has not yet been quantified.
 *	  				 Bank-switched EPROMs are now reliably recognized and program correctly.
 *	  				 FLASH device testing: 28F256, 28F512, 28F101, 28F020A, and 29F040 are all working.
 *	  				 EPROM devices: 27C64, 27C256, 27C512, 27C010 are all working.
 *	  08-18-24 jmh	 Debug of 27C010: Was not programming correctly.  Config matrix was to blame, A14/WE was set incorrectly.
 *	  					Managing the matrix settings for the devices is proving to be difficult but no solution is presenting itself.
 *	  				 "mfr" command was leading A9 connected to Vppf. Fixed and turn Vppf off at end of sig/dev read.
 *	  				 Split 27C010 device to separate Intel devices that use 100us tpw.  New device is "27C010i".
 *	  				 BLAnk check: added high/low VCC check cycles.  Added "is_eprom" flag to only perform high/low VCC option
 *	  				 	when device is an EPROM.
 *	  				 Added VCC parameter option to the DUMP command
 *	  08-11-24 jmh	 Updated help screen copy to fix errors/omissions and add parameter defaults.
 *	  				 Updated IPL message, added (c) notice.
 *	  				 Updated/added cmd_fn() comments.
 *	  08-10-24 jmh	 Fleshed out "mt" command to add walking 1's & 0's fills and also added gas gauge
 *	  				 "mfr" command augmented.  Different devices have different restrictions on address lines which makes them
 *	  				 	incompatible with a "one-and-done" iID read.  Added parity test to MFR id.  If parity fails, reconfigure
 *	  				 	address lines and re-read MFR/DEV codes.
 *	  				 Produced a very efficient parity calc, is_odd_parity(), that runs 5x faster (for 8b) than a for-loop bit counter.
 *	  				 Debug of datapv() with o'scope to verify PGM waveforms.  !! Need to do a final confirmation !!
 *	  08-04-24 jmh	 EPROM:
 *	  				 A "wiggle" in the VPP signal was due to a mis-application of gvpp in datapv().  Added OEVPP_BIT semaphore to
 *	  					distinguish between /CS and /WE controlled PGM cycles (for now, only the 27C51x devices are /CS controlled)
 *	  					VPP_OE controls VPP when the OEVPP_BIT semaphore is active.
 *	  07-18-24 jmh   Unit testing of banked EPROMs (27C011 and 27C513).  Scoping of signals shows that they are correct.
 *	  					!! Need to do a read/pgm test !!
 *	  07-15-24 jmh   Re-integrated/debugged xmodem code.  Deprecated "sload" and replaced with "upl" which handles ASCII and xmodem
 *	  					transfers. Note: Xmodem is about 80 seconds faster than an ASCII xfr for a 1Mb S-record file.
 *	  				 Updated srec.c (see that file for rev notes).
 *	  				 Added numeric negation feature for params in cmd_fn.c
 *	  07-13-24 jmh	 For OE/VPP switch, replaced NPN with an analog switch (SPDT) and a resistor to allow edge rate control.
 *	  					now have about 55ns of rise/fall-time for VPP on the OE connection.
 *	  				 Have plans to add a comparator to monitor VBOOST.  Renamed VPPON (Port E) to VBOOSTOK_N and config'd as input.
 *	  				 Device meta-data: created a database of device params (port configs, address limits, timings, voltages, etc...)
 *	  				 	that can be accessed using the devid as an index ("cmd_fn.c").
 *	  				 "mfr" command can now capture MFR/DEV data from DUT and set the device information in the system.  Manual
 *	  				 	device selection is still an option (required for the 28C64, and DS1216x parts).
 *	  				 Investigated supporting serial (SPI) FLASH/EEPROM parts using a 28DIP to SOIC ZIF adapter.  Features the following
 *	  				 	pinmap: /WE (PE0) = SCLK; /CE (PE1) = /CS; /OE (PE2) = MOSI; and D0 = MISO.  To access, Port B would be
 *	  				 	configured for read continuously, and the Port E signals would directly access the SPI DUT.  The ZIF
 *	  				 	interposer would have to include 3.3V regulation and voltage translation circuits.
 *
 *	  06-23-24 jmh   RevA power supply mods in progress...
 *	  				 !!! The overall function of the programmer is now considered BROKEN until released from HW/SW DVT !!!
 *	  				 Hardware DVT/Debug in progress.  USB 5V is not capable of sustaining the OFF/ON I-transient that is produced
 *	  				 	by the high di/dt of the bypass capacitors (on the order of 60uF).  Connected pin-11 (previously unused) of
 *	  				 	U4 (HC245) as a pre-charge signal connected to +5V_SW via a 1.62K resistor.  By enabling LAT_OE about 20ms
 *	  				 	before turning on +5V_SW, the transient is reduced to the point that the USB hosts do not cut power due to
 *	  				 	an overload on +VUSB.
 *	  				 MFR ID query is now working.  Query of various FLASH and EPROM parts (28 and 32 pin varieties) has been
 *	  				 	demonstrated.
 *	  				 Created master pin-map spreadsheet for all the parts to be supported.  Need to work out the various pin
 *	  				 	switch settings and produce a framework for easily manipulating the data in real-time.
 *	  				 Added PRIMASK support for master interrupt enable/disable.  Originally used TivaWare calls, but switched to
 *	  				 	in-line assembly to eliminate the external lib references and the annoyances that come with them.
 *	  				 	PRIMASK is a single bit inside a processor register that is only accessible via specialized ASM instructions.
 *	  				 	TivaWare abstracts this, but this requires the correct TW package to be installed and correctly referenced
 *	  				 	which introduces portability issues.  For this application, in-line ASM is preferred as those issues are
 *	  				 	not applicable.
 *
 *	  				 	In-line syntax:
 *
 *							asm(
 *								" CPSID I\n"	; master interrupt disable
 *								" ISB\n"
 *							);
 *								;
 *								; ...interceding code...
 *								;
 *							asm(
 *								" CPSIE I\n"	; master interrupt enable
 *								" ISB\n"
 *							);
 *
 *					VPP_MON (PD1/AIN6) now monitors VPP (VPPF is not monitored) and VCC_MON (PD0/AIN7) monitors VCCDUT.  Both use a
 *						49.9K/10.0K voltage divider to scale the raw input to the ADC range.
 *
 *	========================================================================
 *	  circa May, 2024: Basic FLASH/EEPROM/EEPROM functionality established.
 *    04-15-24 jmh:  !!!Still can't get flash PGM cycle to work!!!
 *    				 Added S19 support to sdump, using a 3rd param to set the type ("1" for S19, or "2" for S28).  S19 records
 *    				 	use the S0n line to convey A[19:16].  sload now also groks the S0n lines.
 *    				 Added calc and display of SREC and payload CRC to sload
 *    04-13-24 jmh:  Basic framework for pgmr is in place.  Can now send SREC and hex dumps of SRAM or DUT
 *    				 CRC sums are wrapped around most memory accesses and dumps
 *    				 28F101, 27C256, and 28C64 devices seem to be working.
 *    				 Adopted 230.4 Kbaud UART rate and set pacing delay to 1/15000Hz.  XFER time for a 2Mb hex dump
 *    				 	is about 1 minute.  A little longer for an SREC xfer.
 *    				 Auto-baud logic was removed by previous project.  It remains disabled as this application is not well suited
 *    				 	to slow data rates.
 *    				 SREC download working.
 *    				 27C011 read to file complete (need an emulator to complete DVT once 28F101 is programmed)
 *    				 28C64 device programmed, CRC passes
 *    				 28F101 PGM algorithms coded.  Erase & blank-check are tested.  !!!need to DVT the pgm cmd
 *
 *    				 -- todoos:
 *    				 	invert VCCON control (HW and SW) to remove power-on/reset glitch (may need to think this through a bit...)
 *
 *    04-11-24 jmh:  creation date
 *    				 <VERSION 0.0>
 *
 *******************************************************************/

/**************************************************************************************************************************************************************
 * GAL PGM ADAPTER Notes (JHaas, 3/10/26)
 *
 * The GAL PGM Adapter is a module that connects to the DUT connector utilizing a 27C64 pinout.  It features an autoselect circuit to provide identifying
 * 	information to the PGMR during an auto-select cycle.  A[12:0] signals are used to drive the GAL signals and D0 is used to read the GAL serial output.
 * 	/WE and /OE are driven together as a safety interlock (not usually done for memory devices) to enable EDIT voltage to be driven to the DUT.  An onboard
 * 	boost regulator creates the EDIT voltage (12V for read, 14, 14.5, 15.75, or 16V for VPP).  Address signals are used to drive the voltage selects.
 *
 * The JED file is loaded into programmer SRAM verbatim (using the existing upload cmds) and the TivaPGMR SW interprets the stored file during verify/pgm
 *  operations.  Read GAL dumps directly to the console for text capture.  GREAD, GPGM, and GVFY are the proposed console commands to drive the GAL
 *  program/verify operations.  GAL programming background comes from files located on the internet (see "...ACC\RC96\V52 Firmware\PAL Data\").
 *
 **************************************************************************************************************************************************************/
//-----------------------------------------------------------------------------
// main.c
//  FFPGMR, MK-II. Reads 27C011 EPROM, programs 28F101 FLASH & 28C64 EEPROM
//  UART0 is used for CLI I/O.
//
//  CLI is a simple command port (via UART0 @PA[1:0]) with the following core commands:
//		? - help
//		VERS - interrogate SW version
//		See "cmd_fn.c" for CLI details
//
//	Uses GPIO to drive EPROM/FLASH/EEPROM DUT
//	PortB is the common bus which drives address latches and a data bus buffer (uses HCT logic to level translate from 3.3V to 5V)
//		Port E provides most of the bus support signals (such as /we, /cs, etc...).  PC4 is A16.  Latch and latch OE signals are also on PortC.
//		PortD has socket modification & power control signals.
//	SRAM (SSI0) holds object data for programming into DUT.  Read operations dump directly to the UART port leaving the SRAM unaffected.
//
//  Peripheral Resource Map (* = ISR):
//	*	Timer3A			--			app timer
//		SSI0			PA2/4/5:	SRAM SPI (2Mb device)
//		GPIOA			PA3:		/CS for SRAM
//	*	UART0 			PA[1:0]:	CLI (RX/TX) user serial port
//		M1PWM (4)		PF1:		LEDR PWM to drive TIVA RGB LED
//		M1PWM (5)		PF2:		LEDB PWM to drive TIVA RGB LED
//		M1PWM (6)		PF3:		LEDG PWM to drive TIVA RGB LED
//		ADC0			PD0:		VPP_MON
//		ADC0			PD1:		VPPF_MON
//
//
//  I/O Resource Map:
//      See "init.h"
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
// compile defines

#define MAIN_C
#include <stdint.h>
#include "inc/tm4c123gh6pm.h"
#include <stdio.h>
#include <string.h>
#include "init.h"
#include "typedef.h"
#include "version.h"
#include "serial.h"
#include "cmd_fn.h"
#include "busio.h"
#include "tiva_init.h"

//#include "radio.h"

#include "spi.h"

//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

//  see init.h for main #defines
#define	MAX_REBUF	4		// max # of rebufs
#define	MAX_BARS	7		// max # of led bars
#define	GETS_INIT	0xff	// gets_tab() static initializer signal
#define DAC_LDAC 20			// dac spi defines
#define DAC_PWRUP 21
#define DAC_CLR 22


//-----------------------------------------------------------------------------
// Local Variables
//-----------------------------------------------------------------------------

// Processor I/O assignments
//bitbands
#define DUT_ON  (*(volatile uint32_t *)(0x40058000 + (0x04 * 4)))
#define DUT_OFF (*(volatile uint32_t *)(0x40058000 + (0x08 * 4)))
#define DUT_SCK (*(volatile uint32_t *)(0x40058000 + (0x10 * 4)))
#define DUT_D   (*(volatile uint32_t *)(0x40058000 + (0x20 * 4)))
#define DUT_Q   (*(volatile uint32_t *)(0x40058000 + (0x40 * 4)))
#define DUT_CS  (*(volatile uint32_t *)(0x40058000 + (0x80 * 4)))

//=============================================================================
//=============================================================================
// Global variables (extern conditionals are in init.h)
//-----------------------------------------------------------------------------
char	bchar;							// break character trap register - traps ESC ascii chars entered at terminal
char	swcmd;							// software command flag
S8		handshake;						// xon/xoff enable
S8		xoffsent;						// xoff sent
//U16	app_timer1ms;					// app timer
U16		xm_timer;						// xmodem timer
//U16	ccmd_timer;						// ccmd timer
U8		xmode;							// xmodem active flag
//=============================================================================
//=============================================================================

//-----------------------------------------------------------------------------
// Local variables in this file
//-----------------------------------------------------------------------------
char	got_cmd;						// first valid cmd flag (freezes baud rate)
U32		abaud;							// 0 = 115.2kb (the default)
U8		iplt2;							// timer2 ipl flag
U16		waittimer;						// gp wait timer
U16		waittimer2;						// gp wait timer
U16		ipl_timer;						// ipl timeout timer
U8		cmdtimer;						// cmd_ln GP timer
U16		blinktimer;						// blink regs
U8		blinkfl;
U8		abortmr;						// ESC/Abort swith debounce timer
#define	ABORT_DLY	50					// 50 ms of debounce
U8		aborted;						// abort button pressed state

U32		free_32;						// free-running ms timer
S8		err_led_stat;					// err led status
U8		idx;
U16		ipl;							// initial power on state
char	btbuf[100];						// temp buffer

U8		led_5_on;
U8		led_6_on;
//U8		led_2_level;					// led level regs (0-100%)
//U8		led_3_level;
//U8		led_4_level;
U8		led_5_level;
U8		led_6_level;
//U16		pwm2_reg;						// led pwm regs
//U16		pwm3_reg;
//U16		pwm4_reg;
U16		pwm5_reg;
U16		pwm6_reg;
U8		pwm_master;						// led master level
U8		sw_state;
U8		sw_change;
//char	dbbuf[30];	// debug buffer
//U8		dbug8;
U8		hib_access;						// HIB intrpt lock-out flag

//-----------------------------------------------------------------------------
// Local Prototypes
//-----------------------------------------------------------------------------

void Timer_Init(void);
void Timer_SUBR(void);
char *gets_tab(char *buf, char *save_buf[3], int n);

//*****************************************************************************
// main()
//  The main function runs a forever loop in which the main application operates.
//	Prior to the loop, Main performs system initialization, boot status
//	announcement, and main polling loop.  The loop also calls CLI capture/parse fns.
//	The CLI maintains and processes re-do buffers (4 total) that are accessed by the
//	TAB key.  Allows the last 4 valid command lines to be recalled and executed
//	(after TAB'ing to desired recall command, press ENTER to execute, or ESC to
//	clear command line).
//	Autobaud rate reset allows user to select alternate baudarates after reset:
//		115,200 baud is default.  A CR entered after reset at 57600, 38400,
//		19200, or 9600 baud will reset the system baud rate and prompt for user
//		acceptance.  Once accepted, the baud rate is frozen.  If rejected, baud rate
//		returns to 115200.  The first valid command at the default rate will also
//		freeze the baud rate.  Once frozen, the baud rate can not be changed until
//		system is reset.
//*****************************************************************************
int main(void){
	volatile uint32_t ui32Loop;
//	uint32_t i;
//    uint8_t	tempi;			// tempi
    char	buf[CLI_BUFLEN];	// command line buffer
    char	rebuf0[RE_BUFLEN];	// re-do buffer#1
    char	rebuf1[RE_BUFLEN];	// re-do buffer#2
    char	rebuf2[RE_BUFLEN];	// re-do buffer#3
    char	rebuf3[RE_BUFLEN];	// re-do buffer#4
    U8		argn;				// number of args
    char*	cmd_string;			// CLI processing ptr
    char*	args[ARG_MAX];		// ptr array into CLI args
    char*	rebufN[4];			// pointer array to re-do buffers
    U32		offset;				// srecord offset register
    U16		cur_baud;			// current baud rate
    U8		fault_found;		// fault detected flag

    fault_found = FALSE;								// only trap one fault-restart
	got_cmd = FALSE;
	offset = 0;
	cur_baud = 0;
    iplt2 = 1;											// init timer1
    ipl = proc_init();									// initialize the processor I/O
 	while(iplt2);										// wait for timer to finish intialization
	dispSWvers(); 										// display reset banner
	aborted = ABORT0;
	abortmr = 0;
    do{													// outer-loop (do forever, allows soft-restart)
        rebufN[0] = rebuf0;								// init CLI re-buf pointers
    	rebufN[1] = rebuf1;
    	rebufN[2] = rebuf2;
    	rebufN[3] = rebuf3;
    	rebuf0[0] = '\0';								// clear cmd re-do buffers
    	rebuf1[0] = '\0';
    	rebuf2[0] = '\0';
    	rebuf3[0] = '\0';
    	wait(10);										// a bit more delay..
    	while(gotchrQ()) getchrQ();						// clear serial input in case there was some POR garbage
    	gets_tab(buf, rebufN, GETS_INIT);				// initialize gets_tab()
        set_led(0xff, 0x00);							// init LED levels
        set_pwm(0, 99);									// master = 100%
        set_led(5, 1);									// enable LEDs at 10% until the OS takes over
        set_pwm(5, 10);
        set_led(6, 1);
        set_pwm(6, 10);
    	process_IO(PROC_INIT);							// init process_io
    	// GPIO init
    	//...
    	// main loop
        do{
    		putchar0(XON);
    		buf[0] = '\0';
    		putssQ("pgmr>");										// prompt
    		cmd_string = gets_tab(buf, rebufN, RE_BUFLEN); 		// get cmd line & save to re-do buf
    		if(!got_cmd){										// if no valid commands since reset, look for baud rate change
    			if(cur_baud != abaud){							// abaud is signal from gets_tab() that indicates a baud rate change
    				if(set_baud(abaud)){						// try to set new baud rate
    					putsQ("");								// move to new line
    					dispSWvers();							// display reset banner & prompt to AKN new baud rate
    					while(gotchrQ()) getchrQ();				// clear out don't care characters
    					putssQ("press <Enter> to accept baud rate change: ");
    					while(!gotchrQ());						// wait for user input
    					putsQ("");								// move to new line
    					if(getchrQ() == '\r'){					// if input = CR
    						cur_baud = abaud;					// update current baud = new baud
    						got_cmd = TRUE;						// freeze baud rate
    					}else{
    						set_baud(0);						// input was not a CR, return to default baud rate
    						cur_baud = abaud = 0;
    					}
    				}else{
    					abaud = cur_baud;						// new baud rate not valid, ignore & keep old rate
    				}
    			}else{
    				got_cmd = TRUE;								// freeze baud rate (@115.2kb)
    			}
    		}
    		argn = parse_args(cmd_string,args);					// parse cmd line
    		if(x_cmdfn(argn, args, &offset)) got_cmd = TRUE;	// process cmd line, set got_cmd if cmd valid
    		if((NVIC_FAULT_STAT_R) && !fault_found){			// test for initial fault
    	        putsQ("nvic FLT\n");							// fault message
    			swcmd = SW_ESC;									// abort to restart
    			fault_found = TRUE;
    		}
        }while(swcmd != SW_ESC);
    }while(1);
}

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// gets_tab puts serial input into buffer, UART0.
//-----------------------------------------------------------------------------
// Main loop for command line input.
// waits for a chr and puts into buf.  If 1st chr = \t, copy re-do buf into
//  cmdbuf and cycle to next re-do buf.  if more than n chrs input, nul term buf,
//	disp "line too long", and return.  if \n or \r, copy buf to save_buf & return
//  returns buf (pointer).
//	if n == 0xff, initialize statics and exit.
//
//	11/08/13: Modified to support 4 (MAX_REBUF) rolling cmd save buffers
//	11/15/13: Modified to support auto-baud detect on CR input
//		For the following, each bit chr shown is one bit time at 115200 baud (8.68056us).
//			s = start bit (0), p = stop bit (1), x = incorrect stop, i = idle (1), bits are ordered  lsb -> msb:
//	 the ascii code for CR =  10110000
//			At 230.4kb, CR = s10110000p = 0x0D
//
//		   At 115.2 kb, CR = 00110011110000000011 (1/2 230.4kb)
//			@230.4, this is: s01100111ps00000001i = 0xE6, 0x80
//
//			At 57.6 kb, CR = 000111000111111000000000000111 (1/3 230.4kb)
//			@230.4, this is: s00111000p11111s00000000xxxiii = 0x1c, 0x00
//
//			At 38.4 kb, CR = 000000111111000000111111111111000000000000000000000000111111 (1/6 230.4kb)
//			@230.4, this is: s00000111piis00000111piiiiiiiis00000000xxxxxxxxxxxxxxxiiiiii = 0xE0, 0xE0, 0x00
//
//			At 19.2 Kb, CR = 000000000000111111111111000000000000111111111111111111111111000000000000000000000000000000000000000000000000111111111111 (1/12 230.4kb)
//			@230.4, this is: s00000000xxxiiiiiiiiiiiis00000000xxxiiiiiiiiiiiiiiiiiiiiiiiis00000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxiiiiiiiiiiii = 0x00, 0x00, 0x00
//
//			At 9600 Kb, CR = 000000000000000000000000111111111111111111111111000000000000000000000000111111111111111111111111111111111111111111111111000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000111111111111111111111111 (1/24 230.4kb)
//			@230.4, this is: s00000000xxxiiiiiiiiiiiis00000000xxxiiiiiiiiiiiiiiiiiiiiiiiis00000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxiiiiiiiiiiii = 0x00, 0x00, 0x00
//
//		Thus, @ 115.2 kb, a CR = 0xE6 followed by 0x80
//			  @ 57.6 kb, a CR = 0x1C followed by 0x00
//			  @ 38.4 kb, a CR = 0xE0 followed by 0xE0 (plus a 0x00)
//			  @ 19.2 b, a  CR = 0x00 followed by 0x00 (plus a 0x00)
//				9600 b is not viable for detection.
//
//		NOTE: gets_tab is only used for command line input and thus should not
//		see non-ascii data under normal circumstances.

char *gets_tab(char *buf, char *save_buf[], int n){
	char	*cp;
	char	*sp;
	char	c;
volatile	char	q = 0;
	int		i = 0;
	U8		j;
	U8		se = 0;						// status enable reflection.  If enabled, suppress echo
	static	U8   rebuf_num;

//	if((rebuf_num >= MAX_REBUF) || (n == GETS_INIT)){ // n == 0xff is static initializer signal
	if(n == GETS_INIT){ // n == 0xff is static initializer signal
		rebuf_num = 0;									// init recall buffer pointer
		return buf;										// skip rest of Fn
	}
    cp = buf;
    sp = save_buf[rebuf_num];
    do{
    	do{
    		// run the process loops and capture UART chars
    		process_IO(0);
    		c = getchQ();
    	}while(!c && !q);
    	if(!q){
            switch(c){
                case '\t':
    				if(i != 0){								// if tab, cycle through saved cmd buffers
    					do{
    						i--;							// update count/point
    						cp--;
    						if((*cp >= ' ') && (*cp <= '~')){
    							if(!se){
        							putchar0('\b');		// erase last chr if it was printable
        							putchar0(' ');
        							putchar0('\b');
        							kickuart0();
    							}
    						}
    					}while(i != 0);
    					cp = buf;							// just in case we got out of synch
    				}
    				//copy saved string up to first nul, \n, or \r
    				j = rebuf_num;
    				do{
    					if(--rebuf_num == 0xff){
    						rebuf_num = MAX_REBUF - 1;
    					}
    					if(*save_buf[rebuf_num]) j = rebuf_num;
    				}while(j != rebuf_num);
    				sp = save_buf[rebuf_num];
    				while((*sp != '\0') && (*sp != '\r') && (*sp != '\n')){
    					putdchQ(*sp);
    					*cp++ = *sp++;
    					i++;
    				}
    				kickuart0();
                    break;

                case '\b':
                case 0x7f:
                    if(i != 0){								// if bs & not start of line,
                        i--;								// update count/point
                        cp--;
                        if((*cp >= ' ') && (*cp <= '~')){
							if(!se){
    							putchar0('\b');			// erase last chr if it was printable
    							putchar0(' ');
    							putchar0('\b');
    							kickuart0();
							}
                        }
                    }
                    break;

                case '\r':									// if cr, nul term buf & exit
                case '\n':									// if nl, nul term buf & exit
                    i++;
                    *cp++ = c;
                    putchar_bQ('\n');						// no cntl chrs here
                    break;

                case ESC:									// if esc, nul buf & exit
                    cp = buf;
                    c = '\r';								// set escape condition
    				i = 0;
    				putchar_bQ('\n');						// no cntl chrs here
                    break;

                case BT_LN:									// if bluetooth cmd, do nothing
                    break;

                default:
                    i++;
                    *cp++ = c;								// put chr in buf
                    if(!se){
                        putdchQ(c);							// no cntl chrs here
                    }
                    break;
            }
    	}
    } while((c != '\r') && (c != '\n') && (i < CLI_BUFLEN) && (c != BT_LN));		// loop until c/r or l/f or buffer full
    if(c != BT_LN){
    	if(i >= CLI_BUFLEN){
    		putsQ("#! buffer overflow !$");
    		*buf = '\0';								// abort line
    	}else{
    		if(!se){
        		putsQ("");								// echo end of line to screen
    		}
    		*cp = '\0';									// terminate command line
    		if((*buf >= ' ') && (*buf <= '~')){			// if new buf not empty (ie, 1st chr = printable),
    			strncpy(save_buf[rebuf_num], buf, n);	// copy new buf to save
    			if(++rebuf_num >= MAX_REBUF) rebuf_num = 0;
    		}
    	}
    }
    return buf;
}

//-----------------------------------------------------------------------------
// process_IO() processes system I/O
//-----------------------------------------------------------------------------
void process_IO(U8 flag){

	// perform periodic process updates					// ! SOUT init must execute before SIN init !
	process_CMD(flag);									// process CMD_FN state (primarily, the MFmic key-entry state machine)
	if(aborted == ABORT1){
		putssQ("!! DUT Off/Abort !!\npgmr>");
		aborted = ABORT2;
	}
	if(aborted == ABORT2){
		if(!(~GPIO_PORTF_DATA_R & (SW2))){				// if abort released...
			abortmr = ABORT_DLY;
			aborted = ABORT0;
		}
	}
	return;
}

//-----------------------------------------------------------------------------
// set_pwm() sets the specified PWM to the percent value
//	pwmnum specifies the LED number.  LED 0 is the master setting.  This only sets the master,
//		it does not update any of the LED pwm registers.
//	percent is the percent level, 0 - 100.  If percent > 100, the value is unchanged
//		and the PWM settings are calculated based on stored led and master values
//-----------------------------------------------------------------------------
void set_pwm(U8 pwmnum, U8 percent){
	U32	kk;				// temp U32

	if(percent <= 100){
		switch(pwmnum){						// store level % value
		case 0:								// set master value
			pwm_master = percent;
			break;

/*		case 2:
			led_2_level = percent;
			break;

		case 3:
			led_3_level = percent;
			break;

		case 4:
			led_4_level = percent;
			break;*/

		case 5:
			led_5_level = percent;
			break;

		case 6:
			led_6_level = percent;
			break;
		}
	}
	switch(pwmnum){
/*	case 2:								// LED2
		// calc PWM value in U32 to avoid overflow
		kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_2_level * (U32)pwm_master / 10000L) - 1L;
		// store PWM value
		pwm2_reg = (U16)kk;
		// update pwm if led is on
		if(led_2_on) PWM1_1_CMPB_R = pwm2_reg;
		break;

	case 3:								// LED3
		kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_3_level * (U32)pwm_master / 10000L) - 1L;
		pwm3_reg = (U16)kk;
		if(led_3_on) PWM1_2_CMPA_R = kk;
		break;

	case 4:								// LED4
		kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_4_level * (U32)pwm_master / 10000L) - 1L;
		pwm4_reg = (U16)kk;
		if(led_4_on) PWM1_2_CMPB_R = kk;
		break;*/

	case 5:								// LED5
		kk = PWM_ZERO - (((U32)(PWM_ZERO - PWM_MAX) * (U32)led_5_level * (U32)pwm_master) / 10000L) - 1L;
		pwm5_reg = (U16)kk;
		if(led_5_on) PWM1_3_CMPA_R = kk;
		break;

	case 6:								// LED6
		kk = PWM_ZERO - ((PWM_ZERO - PWM_MAX) * (U32)led_6_level * (U32)pwm_master / 10000L) - 1L;
		pwm6_reg = (U16)kk;
		if(led_6_on) PWM1_3_CMPB_R = kk;
		break;
	}
}

//-----------------------------------------------------------------------------
// set_led() turns on/off the LED outputs
// if lednum == 0xff, do a POR init of the registers
// if lednum == 0x00, value = master %, reset all PWM values
//	else, value = 1/0 for on/off.  save to reg and update pwm reg to set on or off
//-----------------------------------------------------------------------------
void set_led(U8 lednum, U8 value){

	if(lednum == 0xff){
/*		led_2_on = 0;						// init registers all off
		led_3_on = 0;
		led_4_on = 0;*/
		led_5_on = 0;
		led_6_on = 0;
/*		led_2_level = 24;					// led level regs (0-100%)
		led_3_level = 16;
		led_4_level = 50;*/
		led_5_level = 22;
		led_6_level = 99;
		pwm_master = 100;					// led master level
		// led pwm regs
/*		pwm2_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 24L / 100L) - 1L);
		pwm3_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 16L / 100L) - 1L);
		pwm4_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 50L / 100L) - 1L);*/
		pwm5_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 22L / 100L) - 1L);
		pwm6_reg = (U16)(PWM_ZERO - ((PWM_ZERO - PWM_MAX) * 99L / 100L) - 1L);
	}else{
		// process led settings
		if(value < 2){
			switch(lednum){
/*			case 2:
				led_2_on = value;
				if(led_2_on) PWM1_1_CMPB_R = pwm2_reg;
				else PWM1_1_CMPB_R = PWM_ZERO - 1;
				break;

			case 3:
				led_3_on = value;
				if(led_3_on) PWM1_2_CMPA_R = pwm3_reg;
				else PWM1_2_CMPA_R = PWM_ZERO - 1;
				break;

			case 4:
				led_4_on = value;
				if(led_4_on) PWM1_2_CMPB_R = pwm4_reg;
				else PWM1_2_CMPB_R = PWM_ZERO - 1;
				break;*/

			case 5:
				led_5_on = value;
				if(!led_5_on) PWM1_3_CMPA_R = PWM_ZERO - 1;
				break;

			case 6:
				led_6_on = value;
				if(led_6_on) PWM1_3_CMPB_R = pwm6_reg;
				else PWM1_3_CMPB_R = PWM_ZERO - 1;
				break;
			}
		}
	}
}

//-----------------------------------------------------------------------------
// wrwhib_ram() writes a word to the HIBRAM array
//-----------------------------------------------------------------------------
void wrwhib_ram(U32 data, volatile U8 addr){
	volatile uint32_t* pii; // Vu32 pointer

	pii = &HIB_DATA_R;
	pii += addr;
	hib_access = HIB_APPL;						// lock out intr access
	while(!(HIB_CTL_R & HIB_CTL_WRC));			// pause until HIBRAM is ready
	*pii = data;								// write new data
	hib_access = HIB_INTR;						// enable intr access
}

//-----------------------------------------------------------------------------
// wrhib_ram() writes a databyte to the HIBRAM array using a byte address
//-----------------------------------------------------------------------------
void wrhib_ram(uint8_t data, U8 addr){
				U8			i;						// temp
	volatile	uint32_t*	pii;					// Vu32 pointer
				uint32_t	dd = (uint32_t)data;	// temp data
				uint32_t	ee;						// temp data
				uint32_t	maskdd = 0x000000ff;	// mask

	while(!(HIB_CTL_R & HIB_CTL_WRC));			// pause until HIBRAM is ready
	pii = &HIB_DATA_R;							// get base pointer (assumed to be word aligned)
	pii += (addr >> 2);							// point to desired word addr
	ee = *pii;									// get existing data
	i = addr & 0x03;							// get byte addr
	while(i){									// align byte and mask
		dd <<= 8;
		maskdd <<= 8;
		i--;
	}
	ee &= ~maskdd;								// mask existing data
	ee |= dd;									// combine new daata
	hib_access = HIB_APPL;						// lock out intr access
//	dd = HIB_CTL_R;								// do a dummy read
	*pii = ee;									// write new data
	hib_access = HIB_INTR;						// enable intr access
}

//-----------------------------------------------------------------------------
// rdwhib_ram() reads a word from the HIBRAM array using a word address
//-----------------------------------------------------------------------------
uint32_t rdwhib_ram(U8 addr){
	volatile 	uint32_t* pii;		// Vu32 pointer
				uint32_t	ee;		// temp data

	while(!(HIB_CTL_R & HIB_CTL_WRC));			// pause until HIBRAM is ready
	pii = &HIB_DATA_R;							// get base pointer
	pii += (addr);								// point to desired word addr
	ee = *pii;									// get existing data
	return ee;
}

//-----------------------------------------------------------------------------
// rdhib_ram() reads a databyte from the HIBRAM array using a byte address
//-----------------------------------------------------------------------------
uint8_t rdhib_ram(U8 addr){
				U8	i;				// temp
	volatile 	uint32_t* pii;		// Vu32 pointer
				uint32_t	ee;		// temp data

	while(!(HIB_CTL_R & HIB_CTL_WRC));			// pause until HIBRAM is ready
	pii = &HIB_DATA_R;							// get base pointer
	pii += (addr >> 2);							// point to desired word addr
	ee = *pii;									// get existing data
	i = addr & 0x03;							// get byte addr
	while(i){									// align byte to uint8_t
		ee >>= 8;
		i--;
	}
	ee &= 0xff;
	return (uint8_t)ee;
}

//-----------------------------------------------------------------------------
// waitpio() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//	loops through process_IO during wait period.
//-----------------------------------------------------------------------------
void waitpio(U16 waitms){
//	U32	i;

//	i = 545 * (U32)waitms;
    waittimer = waitms;
//    for(;i!=0;i--);		// patch
    while(waittimer != 0) process_IO(0);
    return;
}

//-----------------------------------------------------------------------------
// wait() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
//-----------------------------------------------------------------------------
void wait(U16 waitms){
//	U32	i;

//	i = 545L * (U32)waitms;
    waittimer2 = waitms;
//    for(;i!=0;i--);		// patch
    while(waittimer2 != 0);
    return;
}

//-----------------------------------------------------------------------------
// set_wait() uses a dedicated ms timer to establish a defined delay (+/- 1LSB latency)
// is_wait() returns status of wait timer
//-----------------------------------------------------------------------------
void set_wait(U16 waitms){

    waittimer2 = waitms;
    return;
}

U8 is_wait(void){
	U8	i;	// rtrn

    if(waittimer2) i = 1;
    else i = 0;
    return i;
}

//-----------------------------------------------------------------------------
// wait2() does quick delay pace =  (5.6us * waitms)
//		Emperical measurements with SYSCLK = 50 MHz give the following
//			timing value: waitms = 2 gives a time delay of about 11.2 us
//			(about 560ns per for() cycle) {+/- interrupt variations}
//-----------------------------------------------------------------------------
void wait2(U16 waitms)
{
	U32	i;

	i = 20 * (U32)waitms;
    waittimer = waitms;
    for(;i!=0;i--);		// patch
//    while(waittimer != 0);
    return;
}

//-----------------------------------------------------------------------------
// wait_busy0() waits for (delay timer == 0) or (LCD BUSY == 0)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_busy0(U16 delay){
	U8 loopfl = TRUE;

    waittimer = delay;
    while(loopfl){
    	if(!waittimer) loopfl = FALSE;
//    	if(!(GPIO_PORTE_DATA_R & BUSY_N)) loopfl = FALSE;
//    	if(GPIO_PORTE_RIS_R & (BUSY_N)) loopfl = FALSE;
    }
//	GPIO_PORTE_ICR_R = (BUSY_N);						// clear edge flag
    return !waittimer;
}

//-----------------------------------------------------------------------------
// wait_busy1() waits for (delay timer == 0) or (LCD BUSY == 0)
//	then wait for BUSY_N == 1
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_busy1(U16 delay){
	U8 loopfl = TRUE;

	wait_busy0(delay);
	waittimer = delay;
    while(loopfl){
    	if(!waittimer) loopfl = FALSE;
//    	if(GPIO_PORTE_DATA_R & BUSY_N) loopfl = FALSE;
    }
    return !waittimer;
}

//-----------------------------------------------------------------------------
// wait_reg0() waits for (delay timer == 0) or (regptr* & clrmask == 0)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_reg0(volatile uint32_t *regptr, uint32_t clrmask, U16 delay){
	U8 timout = FALSE;

    waittimer = delay;
    while((waittimer) && ((*regptr & clrmask) != 0));
    if(waittimer == 0) timout = TRUE;
    return timout;
}

//-----------------------------------------------------------------------------
// wait_reg1() waits for (delay timer == 0) or (regptr* & setmask == setmask)
//	if delay expires, return TRUE, else return FALSE
//-----------------------------------------------------------------------------
U8 wait_reg1(volatile uint32_t *regptr, uint32_t setmask, U16 delay){
	U8 timout = FALSE;

    waittimer = delay;
    while((waittimer) && ((*regptr & setmask) != setmask));
    if(waittimer == 0) timout = TRUE;
    return timout;
}

//-----------------------------------------------------------------------------
// getipl() returns current ipl flags value
//-----------------------------------------------------------------------------
U16 getipl(void){

	return ipl;
}

//-----------------------------------------------------------------------------
// warm_reset() triggers primary while-loop in main() to re-start.
//-----------------------------------------------------------------------------
void warm_reset(void){
	swcmd = SW_ESC;				// trigger restart
}

//-----------------------------------------------------------------------------
// free_run() returns value of free-running timer
//-----------------------------------------------------------------------------
U32 free_run(void){
	return free_32;				// return timer value
}

//-----------------------------------------------------------------------------
// get_free() returns value of free_32
//-----------------------------------------------------------------------------
U32 get_free(void){

	return free_32;
}

//-----------------------------------------------------------------------------
// is_blink() returns true if blink timer lsb is true
//-----------------------------------------------------------------------------
U8 is_blink(void){

	if(blinkfl){
		blinkfl = 0;
		return 1;
	}
	return 0;
}

//-----------------------------------------------------------------------------
// Timer3A_ISR
// Called when timer3 A overflows (NORM mode):
//	intended to update app timers @ 1ms per lsb
//	also drives RGB "I'm alive" LED.  The LED transitions through the color
//	wheel in a way that can be modified by the #defines below. RATE, PERIOD,
//	and START values may be adjusted to taylor the color transitions,
//	transition rate, and cycle period.
//-----------------------------------------------------------------------------
void Timer3A_ISR(void){
static	U32	prescale;		// prescales the ms rate to the slow timer rates
volatile U32	i;			// temp

//	GPIO_PORTB_DATA_R |= LOCK;		// toggle debug pin -- 2.25 us ISR exec time at 1.0003ms rate
	if(iplt2){											// if flag is set, perform ipl initialization
		iplt2 = 0;
		free_32 = 0;
		waittimer = 0;									// gp wait timer
		prescale = 0;									// init resp led regs
		blinktimer = BLINK_TIME;
		blinkfl = 0;
	}
	// process app timers
	free_32++;											// update large free-running timer
	if(waittimer != 0){									// update wait timer
		waittimer--;
	}
	if(waittimer2 != 0){								// update wait2 timer
		waittimer2--;
	}
	if(--blinktimer == 0){								// update blink timer
		blinkfl = 1;
		blinktimer = BLINK_TIME;
	}
	if(xm_timer != 0){									// xmodem timer
		xm_timer--;
	}
	// process 10ms timers
	if(++prescale >= PRESCALE_TRIGGER){
		prescale = 0;
		if (ipl_timer != 0){							// update ipl timer
			ipl_timer--;
		}
	}
	if(!abortmr){
		if(~GPIO_PORTF_DATA_R & (SW2)){					// if abort pressed...
			if(aborted == ABORT0){						// and only in state 0
				forcesc0();								// force a serial ESC
				dutpwr(0);								// turn off DUT
				abortmr = ABORT_DLY;					// set delay
				aborted = ABORT1;						// advance stateq
			}
		}
	}else{
		abortmr -= 1;
	}

//	GPIO_PORTB_DATA_R &= ~LOCK;		// toggle debug pin
	TIMER3_ICR_R = TIMERA_MIS_MASK;						// clear all A-intr
	i = TIMER3_ICR_R;									// dumb read, clears flag to prevent re-trig of the ISR
	return;
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------

