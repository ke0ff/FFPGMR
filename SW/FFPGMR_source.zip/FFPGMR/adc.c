/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: adc.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  Tiva adc support functions
 *
 *******************************************************************/

#include <stdint.h>
#include <ctype.h>
#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#include "init.h"						// App-specific SFR Definitions
#include "adc.h"
#include "busio.h"

//=============================================================================
// local registers

U32	vpp_reg;							// l

//=============================================================================
// local Fn declarations


//*****************************************************************************
// adc_init()
//  initializes the processor ADC peripheral
//	returns bitmapped initialize result status as U16
//
//*****************************************************************************
U16 adc_init(void)
{
	volatile uint32_t	ui32Loop;

    // ADC init
	SYSCTL_RCGCADC_R |= SYSCTL_RCGCADC_R0 | SYSCTL_RCGCADC_R1;			// enable ADC clock
	ui32Loop = SYSCTL_RCGCADC_R;
	GPIO_PORTD_AFSEL_R |= (VPP_MON|VPPF_MON);
	GPIO_PORTD_PCTL_R &= 0xFFFFFF00;

	GPIO_PORTD_AMSEL_R |= (VPP_MON|VPPF_MON);
	ADC0_CC_R = ADC_CC_CS_PIOSC;					// use PIOSC
	ADC0_PC_R = 0x0001;								// 125KHz samp rate
	// ADC sequencer init
	ADC0_SSPRI_R = 0x0123;							// Sequencer 2 is highest priority
	ADC0_ACTSS_R &= ~0x0004;						// disable sample sequencer 2
	ADC0_EMUX_R &= ~0x0F00;							// seq2 is software trigger
	ADC0_SSMUX2_R = 0x6666;							// set channels, PD1 = ain6
	ADC0_SSCTL2_R = 0xE800;							// TS0 is 4th sample, IE0 enabled for 4th samp
	ADC0_IM_R &= ~0x0004;							// disable SS2 interrupts
	ADC0_ACTSS_R |= 0x0004;							// enable sample sequencer 2

	ADC1_CC_R = ADC_CC_CS_PIOSC;					// use PIOSC
	ADC1_PC_R = 0x0001;								// 125KHz samp rate
	// ADC sequencer init
	ADC1_SSPRI_R = 0x0123;							// Sequencer 2 is highest priority
	ADC1_ACTSS_R &= ~0x0004;						// disable sample sequencer 2
	ADC1_EMUX_R &= ~0x0F00;							// seq2 is software trigger
	ADC1_SSMUX2_R = 0x7777;							// set channels, PD1 = ain6
	ADC1_SSCTL2_R = 0xE800;							// TS0 is 4th sample, IE0 enabled for 4th samp
	ADC1_IM_R &= ~0x0004;							// disable SS2 interrupts
	ADC1_ACTSS_R |= 0x0004;							// enable sample sequencer 2
	vpp_reg = 0;

	return 0;
}

//*****************************************************************************
// check_vpp()
//  gets VPP reading and checks against current setting.  Returns TRUE if
//		VPP is in correct limits, else FALSE
//
//*****************************************************************************
U8 check_vpp(void)
{
	U32	aa;				// temps
	U8	rtn = FALSE;	// pre-clear return
	U8	set;

	aa = get_vpp();
	set = (read_ahh() & VPP_MASK) >> VPP_SHFT;
	switch(set){
	default:
	case 0:
		if((aa > P0_LIMLO) && (aa < P0_LIMHI)) rtn = TRUE;
		break;

	case 1:
		if((aa > P1_LIMLO) && (aa < P1_LIMHI)) rtn = TRUE;
		break;

	case 2:
		if((aa > P2_LIMLO) && (aa < P2_LIMHI)) rtn = TRUE;
		break;

	case 3:
		if((aa > P3_LIMLO) && (aa < P3_LIMHI)) rtn = TRUE;
		break;
	}
	return rtn;
}

//*****************************************************************************
// check_vcc()
//  gets VCC reading and checks against current setting.  Returns TRUE if
//		VCC is in correct limits, else FALSE
//
//*****************************************************************************
U8 check_vcc(void)
{
	U32	aa;				// temps
	U8	rtn = FALSE;	// pre-clear return
	U8	set;

	aa = get_vcc();
	set = (read_ahh() & VCC_MASK) >> VCC_SHFT;
	switch(set){
	default:
	case 0:
		if((aa > C0_LIMLO) && (aa < C0_LIMHI)) rtn = TRUE;
		break;

	case 1:
		if((aa > C1_LIMLO) && (aa < C1_LIMHI)) rtn = TRUE;
		break;

	case 2:
		if((aa > C2_LIMLO) && (aa < C2_LIMHI)) rtn = TRUE;
		break;

	case 3:
		if((aa > C3_LIMLO) && (aa < C3_LIMHI)) rtn = TRUE;
		break;

	case 4:
		if((aa > C4_LIMLO) && (aa < C4_LIMHI)) rtn = TRUE;
		break;
	}
	return rtn;
}

//*****************************************************************************
// adc_in()
//  starts SS2 and waits for it to finish.  Returns ADC results as U16 placed
//	at pointer.  In the array, even offsets are status, odd offsets are data.
//	offset 1 = ain6, offset 3 = ain6, offset 5 = ain7, offset 7 = TJ
//	float voltage = rawADC * Vref / maxADC ; Vref = 3.3V, maxADC = 0x1000
//	Vtj = 2.7 - ((TJ + 55) / 75)
//	Vtj = rawADC * 3.3 / 4096
//	TJ = (-75 * ((rawADC * 3.3 / 4096) - 2.7)) - 55
//
//*****************************************************************************
U8 adc_in(U16* p, U8 muxn)
{
	U8	i;

	if(muxn == 2){
		ADC0_PSSI_R = 0x0004;						// initiate SS2
		while((ADC0_RIS_R & 0x04) == 0);			// wait for conversion done
		for(i=0; i<4; i++){
			*p++ = ADC0_SSFSTAT2_R & 0xffff;		// get fifo status
			*p++ = ADC0_SSFIFO2_R & 0x0fff;			// read result
		}
		ADC0_ISC_R = 0x04;							// acknowledge completion
	}else{
		ADC1_PSSI_R = 0x0004;						// initiate SS1
		while((ADC1_RIS_R & 0x04) == 0);			// wait for conversion done
		for(i=0; i<4; i++){
			*p++ = ADC1_SSFSTAT2_R & 0xffff;		// get fifo status
			*p++ = ADC1_SSFIFO2_R & 0x0fff;			// read result
		}
		ADC1_ISC_R = 0x04;							// acknowledge completion
	}
	return i;
}

//*****************************************************************************
// adc_ave()
//  averages IB_MAX ADC samples and returns the result.
//	starts SS2 and waits for it to finish.
//
//*****************************************************************************
U32 adc_ave(U16* p, U8 muxn)
{
	U32	aa;		// temps
	U8	i;

	for(i=0, aa=0; i<IB_MAX; i++){
		adc_in(p, muxn);
		aa += (U32)*(p+3);
	}
	return aa / IB_MAX;
}

//*****************************************************************************
// get_vpp()
//  averages ADC and returns VPP in eng units (mV)
//
//*****************************************************************************
U32 get_vpp(void)
{
	U32	aa;		// temps
	U16	ip[IB_MAX];

	aa = adc_ave(ip, 2);
	aa = (aa * (U32)VDDA * (U32)ADCK2)/40960L;		// (mV)
	vpp_reg = aa;
	return aa;
}

//*****************************************************************************
// get_vcc()
//  averages ADC and returns VCC in eng units (mV)
//
//*****************************************************************************
U32 get_vcc(void)
{
	U32	aa;		// temps
	U16	ip[IB_MAX];

	aa = adc_ave(ip, 1);
	aa = (aa * (U32)VDDA * (U32)ADCK)/40960L;		// (mV)
	if(vpp_reg > PC_LIM) aa -= PCORRECT;
	return aa;
}

