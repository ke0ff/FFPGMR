/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  BUS I/O Fns
 *
 *******************************************************************/

//=============================================================================
//	Fns in this file deal with device I/O manipulations.
//	The interface consists of four (4) latches and one bi-directional buffer connected
//	to PortB of the Tiva MCU. The latches form a port expander to produce 32 GP outputs
//	from the 8b port.  THe bi-directional buffer is for data I/O with the DUT.  Each latch
//	a latch enable and all /OE pins are connected to a common OE from the MCU. To power-down
//	the DUT, all outputs are written to zero, and the /OE signal is set high.  The port map
//	is as follows:
//	LAT_AL		PC5		Latches A[7:0]
//	LAT_AH		PC6		Latches A[15:0]
//	LAT_AHH		PC4		Latches A[18:16] and VCC/VPP voltage controls
//	LAT_AH3		PA7		Latches socket steering controls, plus two spares
//
//	The bi-dir buffer /OE is controlled by /CS_33 (PE1) and DIR is controlled by RD_33 (PE3).
//	The latches are all HCT devices operating at Vcc=5V and thus act as voltage
//	translators between the Tiva and DUT.  The buffer is specifically chosen to have a voltage
//	translation feature and operates at 3.3V for the Tiva port, and 5V for the DUT port.
//
//	DUT Initial Program Load (IPL) and Power-Down (PD) states
//	For IPL/PD, All regulators need to be set to minimum voltage (all voltage selects = 0
//	except /VPPFON = 1), all DUT address and control sigs = 0, all socket-select signals = 0
//	except SKTF_020. Turn off the 5V DUT supply (VCCON_33, PD6), then set /LAT_OE (PC7) high.
//
//	To apply power to the DUT, First set the DUT selection signals to match the selected DUT,
//	then perform the IPL/PD steps in reverse order.
//
//	Port Expansion
//	To write an expansion port, Set port B = out, write the data to port B, then toggle the LAT_XX
//	signal for the desired port.  wait_lat(n) establishes a precision microsecond delay (n sets the
//	number of microseconds).  The delay is n us plus approximately 900 ns and uses Timer2A in
//	1-shot mode.  Config is based on SYSCLK #define (in init.h) which sets a single-point of
//	specification for all timer period configurations.
//=============================================================================

// generally required includes
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "typedef.h"
//#include <hw_types.h>
//#include <interrupt.h>

// application-specific includes
#include "inc/tm4c123gh6pm.h"
#include "init.h"						// App-specific SFR Definitions
#include "tiva_init.h"
#include "busio.h"
#include "cmd_fn.h"

//==========================================================================
// BUS I/O Fns

// Local variables/Fn defines
U8	bank_dev;							// if 0, device is a standard memory with all address lines available on pins
										// else, this register defines the address mask for A[23:16] which is transferred to
										// the device internal latch.
U8	bank_shft;							// # of right shifts to addr to align address to bank port
U8	lastbank;							// bank change reg... reduces execution time by only setting device bank if it changes
U32	lastaddr;
U8	reg_ahh;
U8	reg_ah3;

#define VPP_DLY	200
#define VCC_DLY	300


//==========================================================================


//=============================================================================
// wrport_ahh() & wrport_ah3() sets/clears port bits an updates local port register
//	"set" identifies bits to be set in the port if 1
//	"clear" identifies bits to clear if zero
//=============================================================================
void	wrport_ahh(U8 set, U8 clear){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ahh &= clear;							// update local register
	reg_ahh |= set;
	GPIO_PORTB_DATA_R = reg_ahh;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTC_DATA_R |= LAT_AHH;				// pulse addr high latch
	wait_lat(LAT_HOLD);									// hold time
	GPIO_PORTC_DATA_R &= ~LAT_AHH;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}

void	wrport_ah3(U8 set, U8 clear){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ah3 &= clear;							// update local register
	reg_ah3 |= set;
	GPIO_PORTB_DATA_R = reg_ah3;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTA_DATA_R |= LAT_AH3;				// pulse addr high latch
	wait_lat(LAT_HOLD);							// hold time
	GPIO_PORTA_DATA_R &= ~LAT_AH3;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}

//=============================================================================
// set_vcc() set_vpp() sets the VCC/VPP voltage control bits
//=============================================================================
void	set_vcc(U8 voltmask){

	wrport_ahh(voltmask, VCC_MASK);
	return;
}

void	set_vpp(U8 voltmask){

	wrport_ahh(voltmask, VPP_MASK);
	return;
}

//=============================================================================
// put_addr() drives address to target
//=============================================================================
void	set_dev(U8 dev, U8 shft){

	if(dev == DEVRST){
		set_addr();
	}else{
		bank_dev = dev;					// set bank mask (always non-zero for banked devices)
		bank_shft = shft;				// set # of right-shifts to align with bank mask
	}
	return;
}

void	set_addr(void){

	lastaddr = 0xfe000000L;
	lastbank = 0xff;
	return;
}

//=============================================================================
// wait_lat() GPIO settling/pacing delay
//	dlyus is the number of us to delay (1 to 65535 us)
//=============================================================================
void	wait_lat(U16 numus){

//	IntMasterDisable();		// move these to the outer edges of the critical timing loop
	TIMER2_TAILR_R = (U32)ONEUS * (U32)numus;
	TIMER2_ICR_R = TIMER2_RIS_R;					// clear all T2 flags
	TIMER2_CTL_R |= (TIMER_CTL_TAEN);				// enable timer
	while(!TIMER2_RIS_R);
	TIMER2_CTL_R &= ~(TIMER_CTL_TAEN);				// disable timer
//	IntMasterEnable();
	return;
}

//=============================================================================
// put_addr() drives address to target
//=============================================================================
void	put_addr(U32 addr){
	volatile U8	bank;
	volatile U8	i;

	if(lastaddr != addr){
		lastaddr = addr;
		GPIO_PORTB_DIR_R = 0xff;					// portb = output
		if(bank_dev){								// if a banked device, write the internal bank register of the DUT
			// set internal bank register
			bank = (U8)(addr >> bank_shft) & bank_dev;
			if(lastbank != bank){
				lastbank = bank;
				GPIO_PORTB_DATA_R = bank;					// present bank bits to data port
				GPIO_PORTE_DATA_R |= WE_N|OE_N;				// make sure these signals are inactive
				GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable DUT bus
				wait_lat(BUS_DLY);
				GPIO_PORTE_DATA_R &= ~(WE_N);				// write data
				wait_lat(BUS_DLY);
				GPIO_PORTE_DATA_R |= WE_N;					// clear we
				wait_lat(BUS_DLY);
				GPIO_PORTE_DATA_R |= CS_N;					// clear bus
				wait_lat(BUS_DLY);
			}
		}
		GPIO_PORTB_DATA_R = (U8)addr;				// low addr byte
		GPIO_PORTC_DATA_R |= LAT_AL;				// pulse addr low latch
		wait_lat(LAT_HOLD);
		GPIO_PORTC_DATA_R &= ~LAT_AL;
		wait_lat(BUS_DLY);
		GPIO_PORTB_DATA_R = (U8)(addr>>8);			// mid addr byte
		GPIO_PORTC_DATA_R |= LAT_AH;				// pulse addr high latch
		wait_lat(LAT_HOLD);
		GPIO_PORTC_DATA_R &= ~LAT_AH;
		wait_lat(BUS_DLY);
		i = (U8)(addr>>16) & MASK18;				// high addr byte
		GPIO_PORTB_DATA_R = (reg_ahh & ~MASK18) | i;
		GPIO_PORTC_DATA_R |= LAT_AHH;				// pulse addr high latch
		wait_lat(LAT_HOLD);
		GPIO_PORTC_DATA_R &= ~LAT_AHH;
/*
		if(!bank_dev){								// if not a banked device...
			if(addr & 0x10000L){					// set/clear A16
				GPIO_PORTC_DATA_R |= A16;
			}else{
				GPIO_PORTC_DATA_R &= ~A16;
			}
		}*/
		wait_lat(BUS_DLY);
	}
	return;
}

//=============================================================================
// dataio() does a bus read/wr
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	dataio(U32 addr, U8 data, U8 dir){
	volatile U8	d=data;

	put_addr(addr);									// set address
	if(dir == WR){
		// write/pgm
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|OE_N;		// failsafe the control lines for write
		GPIO_PORTB_DIR_R = 0xff;
		GPIO_PORTB_DATA_R = d;						// drive data port with data
		GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// select DUT
		wait_lat(BUS_DLY);
		GPIO_PORTE_DATA_R &= ~(WE_N);				// set write
		wait_lat(BUS_DLY);
		GPIO_PORTE_DATA_R |= WE_N;					// terminate write
		wait_lat(BUS_DLY);
		GPIO_PORTE_DATA_R |= WEDAT_N|CS_N|OE_N;		// end cycle
	}else{
		// read
		GPIO_PORTB_DIR_R = 0;						// set port for read
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N;			// config control lines for read
		GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);
		wait_lat(BUS_DLY);
		d = GPIO_PORTB_DATA_R;						// read data
		GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	}
	return d;
}

//=============================================================================
// fast_read() does a DUT read using the last address setup
//	assumes PortB & /WE are already configured for read
//=============================================================================
U8	fast_read(void){
	volatile U8	d;

	// read
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);			// enable read
	wait_lat(BUS_DLY);
	d = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	wait_lat(BUS_DLY);
	return d;
}

//=============================================================================
// fast_write() does a DUT write using the last address setup
//=============================================================================
void	fast_write(U8 d){

	// write
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTB_DATA_R = d;						// data for write
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~(WE_N);				// enable write
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= CS_N|WEDAT_N;			// end cycle
	wait_lat(BUS_DLY);
	return;
}

//=============================================================================
// fast_pgm_vfy() does a FLASH pgm vfy cycle. Returns data read
//=============================================================================
U8	fast_pgm_vfy(U8 d){
	volatile U8	e;

	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	// PGM cmd
	GPIO_PORTB_DATA_R = PGM_101;
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~(WE_N);				// cycle write
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	wait_lat(BUS_DLY);
	// CS hi/low
	GPIO_PORTE_DATA_R |= CS_N;
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~CS_N;

	// PGM data
	GPIO_PORTB_DATA_R = d;						// data
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~(WE_N);				// cycle write
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= CS_N;
	wait_lat(BUS_DLY);
	// CS hi/low
	GPIO_PORTE_DATA_R &= ~CS_N;

	// PGMV cmd
	GPIO_PORTB_DATA_R = PGMV_101;
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~(WE_N);				// cycle write
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= WE_N;					// end cycle
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= CS_N;
	wait_lat(BUS_DLY);

	// read data
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= WEDAT_N;				// end cycle
	GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);			// enable read
	wait_lat(BUS_DLY);
	e = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~WEDAT_N;
	return e;
}

//=============================================================================
// ds1216e_bit() does a single-bit r/w to/fr the DS1216E smartwatch
//=============================================================================
U8	ds1216e_bit(U8 wrbit, U8 write){
	volatile U8	i=0;
#define	DSRD_ADDR	0x04
#define	DSDATA_1	0x01

	if(write){									// perform write
		if(wrbit){
			put_addr(DSDATA_1);					// set address for a "1"
		}else{
			put_addr(0);						// set address for a "0"
		}
		fast_read();							// access chip to write
	}else{
		put_addr(DSRD_ADDR);					// set read address
		i = fast_read() & 0x01;					// get data
	}
	return i;
}

//=============================================================================
// ds1216c_bit() does a single-bit r/w to/fr the DS1216C smartwatch
//=============================================================================
U8	ds1216c_bit(U8 wrbit, U8 write){
	volatile U8	i=0;

	if(write){									// perform write
		if(wrbit){
			fast_write(1);						// set address for a "1"
		}else{
			fast_write(0);						// set address for a "0"
		}
	}else{
		i = fast_read() & 0x01;					// get data
	}
	return i;
}

//=============================================================================
// byte_flash() does a flash write
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	byte_flash(U32 addr, U8 data){
	volatile U8	d=data;
	volatile U8	e;

//	put_addr(addr);									// set address
	// write/pgm
	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	// PGM cmd
	dataio(addr, PGM_101, WR);

	// PGM data
	dataio(addr, data, WR);
	wait_lat(DLY_10US);

	// PGMV cmd
	dataio(addr, PGMV_101, WR);
	wait_lat(DLY_10US);

	// read data
	e = dataio(addr, 0, RD);
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~WEDAT_N;
	return e;
}

//=============================================================================
// dutpwr() turns on/off DUT power
//	1 = 0, 0 = off
//=============================================================================
void	dutpwr(U8 on){

	if(on){
		GPIO_PORTD_DIR_R &= ~(BZY);
		GPIO_PORTD_DATA_R |= VCCON;
		GPIO_PORTC_DATA_R &= ~LAT_OE_N;
	}else{
		GPIO_PORTE_DATA_R |= WE_N|WEDAT_N|CS_N|OE_N|VPPFON_N|VPPON_N;
		GPIO_PORTD_DIR_R |= (BZY);
		GPIO_PORTD_DATA_R &= ~(VCCON|SKT28|SKTEE|BZY);
		GPIO_PORTC_DATA_R |= LAT_OE_N;
	}
//	wait(200);
	return;
}

//=============================================================================
// vcc() turns on/off VCC power
//	set = 0-4:
//	0: 4.24V;  1: 5.00V;  2: 6.00V;  3: 6.25V;  4: 6.50V
//=============================================================================
void	vcc(U8 set){

	set_vcc(set);
	wait(VCC_DLY);
	return;
}

//=============================================================================
// vpp() turns on/off VPP power
//	set = 0-3:
//	0: 5V.00;  1: 12.00V;  2: 12.25V;  3: 12.75V
//=============================================================================
void	vpp(U8 set){

	set_vpp(set);
	wait(VPP_DLY);
	return;
}

//=============================================================================
// vppf() turns on/off VPPF power
//	1 = 0, 0 = off
//=============================================================================
void	vppf(U8 on){

	if(on){
		GPIO_PORTE_DATA_R &= ~VPPFON_N;
	}else{
		GPIO_PORTE_DATA_R |= VPPFON_N;
	}
	wait(500);
	return;
}

//=============================================================================
// skt() sets the socket config
//	28 = 28 pin, 0xee = eeprom, 0xe0 = no ee, 32 = 32 pin
//=============================================================================
void	skt(U8 id){

	switch(id){
	case 28:
		GPIO_PORTD_DATA_R |= SKT28;
		break;

	case 32:
		GPIO_PORTD_DATA_R &= ~SKT28;
		break;

	case 0xee:
		GPIO_PORTD_DATA_R |= SKTEE;
		GPIO_PORTD_DIR_R &= ~(BZY);
		break;

	case 0xe0:
		GPIO_PORTD_DATA_R &= ~SKTEE;
		break;

	default:
		break;
	}
	return;
}

// {eof}
