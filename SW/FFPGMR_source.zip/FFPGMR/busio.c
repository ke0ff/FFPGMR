/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: busio.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  BUS I/O Fns
 *
 *******************************************************************/

//=============================================================================
//	Fns in this file deal with device I/O manipulations.
//	The interface consists of four (4) latches and one bi-directional buffer connected
//	to PortB of the Tiva MCU. The latches form a port expander to produce 32 GP outputs
//	from the 8b port.  THe bi-directional buffer is for data I/O with the DUT.  Each latch
//	a latch enable and all /OE pins are connected to a common OE from the MCU. To power-down
//	the DUT, all outputs are written to zero, and the /OE signal is set high.  The port map
//	is as follows:
//	LAT_AL		PC5		Latches A[7:0]
//	LAT_AH		PC6		Latches A[15:0]
//	LAT_AHH		PC4		Latches A[18:16] and VCC/VPP voltage controls
//	LAT_AH3		PA7		Latches socket steering controls, plus two spares
//
//	The bi-dir buffer /OE is controlled by /CS_33 (PE1) and DIR is controlled by RD_33 (PE3).
//	The latches are all HCT devices operating at Vcc=5V and thus act as voltage
//	translators between the Tiva and DUT.  The buffer is specifically chosen to have a voltage
//	translation feature and operates at 3.3V for the Tiva port, and 5V for the DUT port.
//
//	DUT Initial Program Load (IPL) and Power-Down (PD) states
//	For IPL/PD, All regulators need to be set to minimum voltage (all voltage selects = 0
//	except /VPPFON = 1), all DUT address and control sigs = 0, all socket-select signals = 0
//	except SKTF_020. Turn off the 5V DUT supply (VCCON_33, PD6), then set /LAT_OE (PC7) high.
//
//	To apply power to the DUT, First set the DUT selection signals to match the selected DUT,
//	then perform the IPL/PD steps in reverse order.
//
//	Port Expansion
//	To write an expansion port, Set port B = out, write the data to port B, then toggle the LAT_XX
//	signal for the desired port.  wait_lat(n) establishes a precision microsecond delay (n sets the
//	number of microseconds).  The delay is n us plus approximately 900 ns and uses Timer2A in
//	1-shot mode.  Config is based on SYSCLK #define (in init.h) which sets a single-point of
//	specification for all timer period configurations.
//=============================================================================

// generally required includes
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "typedef.h"
//#include <hw_types.h>
//#include <interrupt.h>

// application-specific includes
#include "inc/tm4c123gh6pm.h"
#include "init.h"						// App-specific SFR Definitions
#include "tiva_init.h"
#include "busio.h"
#include "cmd_fn.h"

//==========================================================================
// BUS I/O Fns

// Local variables/Fn defines
U8	bank_shft;							// if 0, device is a standard memory with all address lines available on pins
										// else, this register defines the # of right shifts to addr to align address
										// to bank port
U8	lastbank;							// bank change reg... reduces execution time by only setting device bank if it changes
U32	lastaddr;
U8	reg_ahh;
U8	reg_ah3;
U8	we_bit;								// register for /WE bit mask
U16	we_dly;								// register for WE delay

#define VPP_DLY	200
#define VCC_DLY	300


//==========================================================================


//=============================================================================
// wrport_ahh() & wrport_ah3() sets/clears port bits an updates local port register
//	"set" identifies bits to be set in the port if 1
//	"clear" identifies bits to clear if zero
//=============================================================================
/* void wrport_ahh(U8 set, U8 clear){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ahh &= ~clear;							// update local register
	reg_ahh |= set;
	GPIO_PORTB_DATA_R = reg_ahh;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTC_DATA_R |= LAT_AHH;				// pulse addr high latch
	wait_lat(LAT_HOLD);							// hold time
	GPIO_PORTC_DATA_R &= ~LAT_AHH;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}

void wrport_ah3(U8 set, U8 clear){

	GPIO_PORTB_DIR_R = 0xff;
	reg_ah3 &= ~clear;							// update local register
	reg_ah3 |= set;
	GPIO_PORTB_DATA_R = reg_ah3;				// set port data to write
	wait_lat(LAT_SETUP);						// setup time
	GPIO_PORTA_DATA_R |= LAT_AH3;				// pulse addr high latch
	wait_lat(LAT_HOLD);							// hold time
	GPIO_PORTA_DATA_R &= ~LAT_AH3;
	GPIO_PORTB_DIR_R = PORTB_DIRV;
	return;
}*/


U8	read_ahh(void){

	return reg_ahh;
}

U8	read_ah3(void){

	return reg_ah3;
}

//=============================================================================
// set_vcc() set_vpp() sets the VCC/VPP voltage control bits
//=============================================================================
void	set_vcc(U8 voltmask){

	wrport_ahh(voltmask, VCC_MASK);
	return;
}

void	set_vpp(U8 voltmask){

	wrport_ahh(voltmask, VPP_MASK);
	return;
}

//=============================================================================
// put_addr() drives address to target
//=============================================================================
void	set_dev(U8 dev){

	if(dev == DEVRST){
		set_addr();
	}else{
		bank_shft = is_banked(dev);		// set bank mask (always non-zero for banked devices)
	}
	return;
}

void	set_addr(void){

	lastaddr = 0xfe000000L;
	lastbank = 0xff;
	return;
}

void	set_we(U8 bitmask){

	we_bit = bitmask & ~OEVPP_BIT;
	return;
}

void	set_we_dly(U16 dly){

	we_dly = dly;
	return;
}

//=============================================================================
// wait_lat() GPIO settling/pacing delay
//	dlyus is the number of us to delay (1 to 65535 us)
//=============================================================================
/*void	wait_lat(U16 numus){

//	IntMasterDisable();		// move these to the outer edges of the critical timing loop
	TIMER2_TAILR_R = (U32)ONEUS * (U32)numus;
	TIMER2_ICR_R = TIMER2_RIS_R;					// clear all T2 flags
	TIMER2_CTL_R |= (TIMER_CTL_TAEN);				// enable timer
	while(!TIMER2_RIS_R);
	TIMER2_CTL_R &= ~(TIMER_CTL_TAEN);				// disable timer
//	IntMasterEnable();
	return;
}*/

//=============================================================================
// put_addr() drives address[18:0] to target
//=============================================================================
void	put_addr(U32 addr){
	volatile U8	bank;
	volatile U8	i = 0 ;
	volatile U8	ah3_save;

	if(lastaddr != addr){
		lastaddr = addr;
		GPIO_PORTB_DIR_R = 0xff;						// portb = output
		GPIO_PORTB_DATA_R = (U8)addr;					// low addr byte
		GPIO_PORTC_DATA_R |= LAT_AL;					// pulse addr low latch
		wait_lat(LAT_HOLD);
		GPIO_PORTC_DATA_R &= ~LAT_AL;
		wait_lat(BUS_DLY);
		if(bank_shft){									// if a banked device...
			GPIO_PORTB_DATA_R = (U8)(addr>>8) | 0x80;	// mid addr byte + set A15/VPP ensures VPP is 5V when turned off for bank set
			i = A18;									// A18/VPP ensures VPP is 5V when turned off for bank set, for high addr bits down-source a few lines
		}else{
			GPIO_PORTB_DATA_R = (U8)(addr>>8);			// else mid addr byte used as-is
		}
		GPIO_PORTC_DATA_R |= LAT_AH;					// pulse addr high latch
		wait_lat(LAT_HOLD);
		GPIO_PORTC_DATA_R &= ~LAT_AH;
		wait_lat(LAT_HOLD);
		i |= (U8)(addr>>16) & MASK18;					// high addr byte
		reg_ahh = (reg_ahh & ~MASK18) | i;
		GPIO_PORTB_DATA_R = reg_ahh;
		GPIO_PORTC_DATA_R |= LAT_AHH;					// pulse addr high latch
		wait_lat(LAT_HOLD);
		GPIO_PORTC_DATA_R &= ~LAT_AHH;
		if(bank_shft){									// if a banked device, write the internal bank register of the DUT
			// set internal bank register
			bank = (U8)(addr >> bank_shft);
			if(lastbank != bank){
				ah3_save = reg_ah3;
				lastbank = bank;
				wrport_ahh(A18, 0);					// ??
				GPIO_PORTE_DATA_R |= we_bit|OE_N;		// make sure these signals are inactive
				wait_lat(10);							// let oe settle
				wrport_ah3(0, vpp_bit());				// vpp off to switch banks
				wait_lat(100);							// let vpp settle
				GPIO_PORTB_DIR_R = 0xff;				// portb = output
				GPIO_PORTB_DATA_R = bank;				// present bank bits to data port
				GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);	// enable DUT bus
				wait_lat(BUS_DLY);
				GPIO_PORTE_DATA_R &= ~(WE_N);			// write data (use actual /WE bit, not /PGM)
				wait_lat(BUS_DLY);
				GPIO_PORTE_DATA_R |= WE_N;				// clear we
				GPIO_PORTE_DATA_R |= CS_N;				// clear bus
				wait_lat(BUS_DLY);
				// vpp restore
				stor_port_ah3(ah3_save);
				wait_lat(1000);							// let vpp settle
			}
		}
		wait_lat(BUS_DLY);
	}
	return;
}

//=============================================================================
// dataio() does a bus read/wr
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	dataio(U32 addr, U8 data, U8 dir){
	volatile U8	d=data;

	put_addr(addr);									// set address
	if(dir == WR){
		// write/pgm
		GPIO_PORTE_DATA_R |= we_bit|WEDAT_N|OE_N;	// failsafe the control lines for write
		GPIO_PORTB_DIR_R = 0xff;
		GPIO_PORTB_DATA_R = d;						// drive data port with data
		GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// select DUT to WR
		wait_lat(BUS_DLY);
		GPIO_PORTE_DATA_R &= ~(we_bit);				// set write
		wait_lat(we_dly);
		GPIO_PORTE_DATA_R |= we_bit;				// terminate write
		wait_lat(BUS_DLY);
		GPIO_PORTE_DATA_R |= WEDAT_N|CS_N|OE_N;		// end cycle
	}else{
		// read
		GPIO_PORTB_DIR_R = 0;						// set port for read
		GPIO_PORTE_DATA_R |= we_bit|WEDAT_N;		// config control lines for read
		GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);
		wait_lat(BUS_DLY);
		d = GPIO_PORTB_DATA_R;						// read data
		GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	}
	wait_lat(BUS_DLY);
	return d;
}

//====
//=============================================================================
// datapv() does a bus pgm/vfy cycle
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	gvpp = flag that is the "WE" mask if other than WE_N (for the 27C51x devices that share OE and VPP)
//			if hi-bit is set, WE/PGM requires VPP to be turned off for VFY (/CS controlled PGM cycle)
//			else, PGM cycle is controlled by /WE
//	Returns data read or written
//=============================================================================
U8	datapv(U32 addr, U8 data, U8 gvpp){
	volatile U8	d=data;

	if(gvpp & OEVPP_BIT){
		// perform write/pgm cycle using /CS
		GPIO_PORTE_DATA_R |= WE_N|CS_N; 			// failsafe the control lines for write
		GPIO_PORTE_DATA_R &= ~OE_N; 				// OE is always low for this branch
		GPIO_PORTB_DIR_R = 0xff;
		GPIO_PORTB_DATA_R = d;						// drive data port with data
		wrport_ah3(VPP_OE, 0);						// PGM on
		wait_lat(4*BUSG_DLY);
		GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// select DUT
		wait_lat(BUSG_DLY);

		// disable master ISR						// /PGM pulse needs to be as accurate as possible, so disable all ISRs for this operation
		asm(
			" CPSID I\n"
			" ISB\n"
		);
		GPIO_PORTE_DATA_R &= ~(we_bit);				// set write
		wait_lat(we_dly);
		GPIO_PORTE_DATA_R |= we_bit;				// terminate write
		// enable master ISR
		asm(
			" CPSIE I\n"
			" ISB\n"
		);

		wait_lat(BUSG_DLY);
		wrport_ah3(0, VPP_OE);						// PGM off
//		GPIO_PORTE_DATA_R |= WEDAT_N|CS_N|OE_N;		// end cycle
		// read
		GPIO_PORTB_DIR_R = 0;						// set port for read
		GPIO_PORTE_DATA_R |= WEDAT_N;				// config control lines for read
		GPIO_PORTE_DATA_R &= ~(CS_N);
		wait_lat(BUS_DLY);
		d = GPIO_PORTB_DATA_R;						// read data
		GPIO_PORTE_DATA_R |= CS_N;					// end cycle
		wait_lat(BUS_DLY);
	}else{
		// perform write/pgm cycle using /WE
		GPIO_PORTE_DATA_R |= we_bit|WEDAT_N|OE_N;	// failsafe the control lines for write
		GPIO_PORTB_DIR_R = 0xff;
		GPIO_PORTB_DATA_R = d;						// drive data port with data
		GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// select DUT
		wait_lat(BUS_DLY);

		// disable master ISR						// /PGM pulse needs to be as accurate as possible, so disable all ISRs for this operation
		asm(
			" CPSID I\n"
			" ISB\n"
		);
		GPIO_PORTE_DATA_R &= ~(we_bit);				// set write
		wait_lat(we_dly);
		GPIO_PORTE_DATA_R |= we_bit;				// terminate write
		// enable master ISR
		asm(
			" CPSIE I\n"
			" ISB\n"
		);

		wait_lat(BUS_DLY);
	//		GPIO_PORTE_DATA_R |= WEDAT_N|CS_N|OE_N;		// end cycle
		// read
		GPIO_PORTB_DIR_R = 0;						// set port for read
		GPIO_PORTE_DATA_R |= WEDAT_N;				// config control lines for read
		GPIO_PORTE_DATA_R &= ~(OE_N|CS_N);
		wait_lat(BUS_DLY);
		d = GPIO_PORTB_DATA_R;						// read data
		GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
		wait_lat(BUS_DLY);
	}
	return d;
}

//=========================================================================
// fast_read() does a DUT read using the last address setup
//	assumes PortB & /WE are already configured for read
//=============================================================================
U8	fast_read(void){
	volatile U8	d;

	// read
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= (WEDAT_N|WE_N);		// enable read
	GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);			// enable read
	wait_lat(READ_HOLD);
//	wait_lat(50);
	d = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	wait_lat(BUS_DLY);
	return d;
}

//=============================================================================
// fast_write() does a DUT write using the last address setup
//=============================================================================
void	fast_write(U8 d){

	// write
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTB_DATA_R = d;						// data for write
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	wait_lat(DATA_HOLD);
	GPIO_PORTE_DATA_R &= ~(we_bit);				// enable write
	wait_lat(WRITE_HOLD);
	GPIO_PORTE_DATA_R |= we_bit|CS_N;				// end cycle
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R |= WEDAT_N;
	return;
}

//=============================================================================
// fast_pgm_vfy() does a FLASH pgm vfy cycle. Returns data read
//=============================================================================
U8	fast_pgm_vfy(U8 d){
	volatile U8	e;

	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;					// data write direction
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable drive to write
	// PGM cmd
	GPIO_PORTB_DATA_R = PGM_101;				// set pgm cmd
	GPIO_PORTE_DATA_R &= ~(we_bit);				// cycle write
	wait_lat(DATA_HOLD);
	GPIO_PORTE_DATA_R |= we_bit|CS_N;			// end cycle
	wait_lat(WRITE_HOLD);

	// PGM data
	GPIO_PORTB_DATA_R = d;						// data
	GPIO_PORTE_DATA_R &= ~(we_bit|CS_N);		// cycle we
	wait_lat(DATA_HOLD);
	GPIO_PORTE_DATA_R |= we_bit|CS_N;
	wait_lat(PGM_HOLD);							// do pgm hold

	// PGMV cmd
	GPIO_PORTB_DATA_R = PGMV_101;				// set pgm cmd
	GPIO_PORTE_DATA_R &= ~(we_bit|CS_N);		// cycle we
	wait_lat(DATA_HOLD);
	GPIO_PORTE_DATA_R |= we_bit|CS_N;
	wait_lat(VFY_HOLD);							// do vfy hold

	// read data
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= WEDAT_N;				// set for read
	GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);			// enable read
	wait_lat(READ_HOLD);
	e = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~WEDAT_N;				// release port
	wait_lat(BUS_DLY);
	return e;
}

//=============================================================================
// ffast_write() does a DUT write using the last address setup
//=============================================================================
void	ffast_write(U8 d){

	// write
	GPIO_PORTB_DATA_R = d;						// data for write
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	wait_lat(DATA_HOLD);
	GPIO_PORTE_DATA_R &= ~(we_bit);				// enable write
	wait_lat(WRITE_HOLD);
	GPIO_PORTE_DATA_R |= we_bit|CS_N;				// end cycle
	wait_lat(BUS_DLY);
	return;
}

//=========================================================================
// fast_read() does a DUT read using the last address setup
//	assumes PortB & /WE are already configured for read
//=============================================================================
U8	ffast_read(void){
	volatile U8	d;

	// read
	GPIO_PORTE_DATA_R &= ~(CS_N|OE_N);			// enable read
	wait_lat(READ_HOLD);
//	wait_lat(50);
	d = GPIO_PORTB_DATA_R;						// read data
	GPIO_PORTE_DATA_R |= CS_N|OE_N;				// end cycle
	wait_lat(BUS_DLY);
	return d;
}

//=============================================================================
// fast_pgm_vfy_040() does a FLASH pgm vfy cycle for the 29F040. Returns data read
//=============================================================================
U8	fast_pgm_vfy_040(U32 addr, U8 d){
	volatile U8	e;
	volatile U8	f;

#define	PGM_KEY1A	0x5555L
#define	PGM_KEY1D	0xAA
#define	PGM_KEY2A	0x2AAAL
#define	PGM_KEY2D	0x55
#define	PGM_KEY3A	0x5555L
//cmd is data for key3
#define	PGM_KEY4A	0x5555L
#define	PGM_KEY4D	0xAA
#define	PGM_KEY5A	0x2AAAL
#define	PGM_KEY5D	0x55
#define	PGM_KEY6A	0x5555L
#define	PGM_KEY6_CHIP	0x10
// sector addr is used for key6
#define	PGM_KEY6_SECT	0x30

	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;					// data write direction
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable drive to write
	// PGM cmd
	put_addr(PGM_KEY1A);						// set key1
	ffast_write(PGM_KEY1D);
	put_addr(PGM_KEY2A);						// set key2
	ffast_write(PGM_KEY2D);
	put_addr(PGM_KEY3A);						// set key3 - pgm
	ffast_write(PGM_040);

	// PGM data
	put_addr(addr);								// data addr, write data
	ffast_write(d);

	// PGMV loop
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= (WEDAT_N|WE_N);		// enable read
	f = 0;										// init fail trap
	do{											// look for read=pgm data and trap bit5 (fail error)
		e = ffast_read();
		if(d!=e){
			if(e & 0x20){
				f += 1;							// need two bit5 fail errors in a row to validate error
			}
		}
	}while((d != e) && (f < 2));
	if(f>=2) e = ~d;							// error return
	return e;
}

//=============================================================================
// fast_era_040() does a FLASH chip erase cycle for the 29F040.
//	Returns 0xff if successful
//=============================================================================
U8	fast_era_040(void){
	volatile U8	e;
	volatile U8	f;
	U8	spin = 0;

#define	SPINLIM	64

	// init spinner
	put_spin(0xff);
	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;					// data write direction
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable drive to write
	// ERA cmd
	put_addr(PGM_KEY1A);						// set key1
	ffast_write(PGM_KEY1D);
	put_addr(PGM_KEY2A);						// set key2
	ffast_write(PGM_KEY2D);
	put_addr(PGM_KEY3A);						// set key3 - pgm
	ffast_write(ERA_040);
	put_addr(PGM_KEY4A);						// set key4
	ffast_write(PGM_KEY4D);
	put_addr(PGM_KEY5A);						// set key5
	ffast_write(PGM_KEY5D);
	put_addr(PGM_KEY6A);						// set key6
	ffast_write(PGM_KEY6_CHIP);

	// ERAV loop
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= (WEDAT_N|WE_N);		// enable read
	f = 0;										// init fail trap
	do{											// look for read=pgm data and trap bit5 (fail error)
		if(++spin == SPINLIM){					// do console status spinny-thingy
			put_spin(1);
			wait(10);
			spin = 0;
		}
		e = ffast_read();
		if(e!=0xff){
			if(e & 0x20){
				f += 1;							// need two bit5 fail errors in a row to validate error
			}
		}
	}while((e != 0xff) && (f < 2));
	if(f>=2) e = 0;								// error return
	return e;
}

//=============================================================================
// fast_pgm_vfy_020() does a FLASH pgm vfy cycle for the 28F020A. Returns data read
//=============================================================================
U8	fast_pgm_vfy_020(U8 d){
	volatile U8	e;
	volatile U8	f;

	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;					// data write direction
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable drive to write
	// PGM cmd
	fast_write(PGM_020);
	// PGM data
	fast_write(d);

	// PGMV loop
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= (WEDAT_N|WE_N);		// enable read
	f = 0;										// init fail trap
	do{											// look for read=pgm data and trap bit5 (fail error)
		e = fast_read();
		if(d!=e){
			if(e & 0x20){
				f += 1;							// need two bit5 fail errors in a row to validate error
			}
		}
	}while((d != e) && (f < 2));
	if(f>=2) e = ~d;							// error return
	else e = fast_read();
	return e;
}

//=============================================================================
// fast_era_020() does a FLASH chip erase cycle for the 28F020A.
//	Returns 0xff if successful
//=============================================================================
U8	fast_era_020(void){
	volatile U8	e;
	volatile U8	f;
	U8	spin = 0;

#define	SPINLIM	64

	// init spinner
	put_spin(0xff);
	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;					// data write direction
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable drive to write
	// ERA cmd
	fast_write(ERA_020);
	fast_write(ERA_020);

	// ERAV loop
	GPIO_PORTB_DIR_R = 0;
	GPIO_PORTE_DATA_R |= (WEDAT_N|WE_N);		// enable read
	f = 0;										// init fail trap
	do{											// look for read=pgm data and trap bit5 (fail error)
		if(++spin == SPINLIM){					// do console status spinny-thingy
			put_spin(1);
			wait(10);
			spin = 0;
		}
		e = fast_read();
		if(e!=0xff){
			if(e & 0x20){
				f += 1;							// need two bit5 fail errors in a row to validate error
			}
		}
	}while((e != 0xff) && (f < 2));
	if(f>=2) e = 0;								// error return
	return e;
}

//=============================================================================
// vppoe_wr() does a write cycle with OE = VPP for EEPROM chip erase
//	dly is the width of the write pulse in us
//=============================================================================
void	vppoe_wr(U16 dly){

	// write
	GPIO_PORTE_DATA_R |= OE_N | CS_N;			// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTB_DATA_R = 0xff;					// data for write
	vpp(VPP_120);
	wrport_ah3(VPP_OE, VPP_OE);
	GPIO_PORTE_DATA_R &= ~CS_N;					// enable erase
	wait_lat(dly);
	GPIO_PORTE_DATA_R |= CS_N;					// end erase cycle
	vpp(VPP_050);
	wrport_ah3(0, VPP_OE);
	return;
}

//=============================================================================
// ds1216e_bit() does a single-bit r/w to/fr the DS1216E smartwatch
//=============================================================================
U8	ds1216e_bit(U8 wrbit, U8 write){
	volatile U8	i=0;
#define	DSRD_ADDR	0x04
#define	DSDATA_1	0x01

	if(write){									// perform write
		if(wrbit){
			put_addr(DSDATA_1);					// set address for a "1"
		}else{
			put_addr(0);						// set address for a "0"
		}
		fast_read();							// access chip to write
	}else{
		put_addr(DSRD_ADDR);					// set read address
		i = fast_read() & 0x01;					// get data
	}
	return i;
}

//=============================================================================
// ds1216c_bit() does a single-bit r/w to/fr the DS1216C smartwatch
//=============================================================================
U8	ds1216c_bit(U8 wrbit, U8 write){
	volatile U8	i=0;

	if(write){									// perform write
		if(wrbit){
			fast_write(1);						// set address for a "1"
		}else{
			fast_write(0);						// set address for a "0"
		}
	}else{
		i = fast_read() & 0x01;					// get data
	}
	return i;
}

//=============================================================================
// byte_flash() does a flash write
//	addr = 32bit addr
//	data = 8 bit data (don't care for read)
//	dir = 1 for write, 0 for read
//	Returns data read or written
//=============================================================================
U8	byte_flash(U32 addr, U8 data){
	volatile U8	d=data;
	volatile U8	e;

//	put_addr(addr);									// set address
	// write/pgm
	// write prep
	GPIO_PORTE_DATA_R |= OE_N;					// failsafe
	GPIO_PORTB_DIR_R = 0xff;
	GPIO_PORTE_DATA_R &= ~(CS_N|WEDAT_N);		// enable write
	// PGM cmd
	dataio(addr, PGM_101, WR);

	// PGM data
	dataio(addr, data, WR);
	wait_lat(DLY_10US);

	// PGMV cmd
	dataio(addr, PGMV_101, WR);
	wait_lat(DLY_10US);

	// read data
	e = dataio(addr, 0, RD);
	wait_lat(BUS_DLY);
	GPIO_PORTE_DATA_R &= ~WEDAT_N;
	return e;
}

//=============================================================================
// dutpwr() turns on/off DUT power
//	1 = 0, 0 = off
//=============================================================================
void	dutpwr(U8 on){

	if(on){
		GPIO_PORTD_DIR_R &= ~(BZY);
		// enable latch OE to begin +5V_SW pre-charge (20ms)
		GPIO_PORTC_DATA_R &= ~LAT_OE_N;
		wait(20);
		// Turn on +5V_SW
		GPIO_PORTD_DATA_R |= VCCON;
	}else{
		GPIO_PORTE_DATA_R |= we_bit|WEDAT_N|CS_N|OE_N|VPPFON_N;
		GPIO_PORTD_DIR_R |= (BZY);
		GPIO_PORTD_DATA_R &= ~(VCCON|SKT28|SKTEE|BZY);
		GPIO_PORTC_DATA_R |= LAT_OE_N;
	}
//	wait(200);
	return;
}

//=============================================================================
// vcc() turns on/off VCC power
//	set = 0-4:
//	0: 4.24V;  1: 5.00V;  2: 6.00V;  3: 6.25V;  4: 6.50V
//	Param map: VCC_424, VCC_500, VCC_600, VCC_625, VCC_650
//=============================================================================
void	vcc(U8 set){

	set_vcc(set);
	wait(VCC_DLY);
	return;
}

//=============================================================================
// vpp() turns on/off VPP power
//	set = 0-3:
//	Param map: VPP_050, VPP_120, VPP_122, VPP_127
//=============================================================================
void	vpp(U8 set){

	set_vpp(set);
	wait(VPP_DLY);
	return;
}

//=============================================================================
// vpp_oe() turns VPP/OE on/off
//	set = 1/0:
//=============================================================================
void	vpp_oe(U8 set){

	if(set) wrport_ah3(EPROM_512, EPROM_512);
	else wrport_ah3(0, EPROM_512);
	wait_lat(3);
	return;
}

//=============================================================================
// vppf() turns on/off VPPF power
//	1 = 0, 0 = off
//=============================================================================
void	vppf(U8 on){

	if(on){
		GPIO_PORTE_DATA_R &= ~VPPFON_N;
	}else{
		GPIO_PORTE_DATA_R |= VPPFON_N;
	}
	wait(200);
	return;
}

//=============================================================================
// skt() sets the socket config
//	low-nyb is skt size, 8 (28) or 2 (32)
//	hi-nyb is EEPROM (0xex) or not (0x0x)e
//	if id is invalid, no action is taken
//	Valid id = 0x08, 0x02, 0xE0, 0xEE, 0xE2, 0xE8
//=============================================================================
void	skt(U8 id){

	switch(id & 0x0f){
	case SET_WE_A14:
		GPIO_PORTD_DATA_R |= SKT28;
		break;

	case 0:
	case CLR_WE_A14:
	GPIO_PORTD_DATA_R &= ~SKT28;
		break;

	default:
		break;
	}
	switch(id & 0xf0){
	case 0:
	case CLR_VPPA15:
		GPIO_PORTD_DATA_R &= ~SKTEE;
		break;

	case SET_VPPA15:
		GPIO_PORTD_DATA_R |= SKTEE;
		GPIO_PORTD_DIR_R &= ~(BZY);
		break;

	default:
		break;
	}
	return;
}

// {eof}
