/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: cmd_fn.h
 *
 *  Module:    Control
 *
 *  Summary:
 *  CLI Command Interpreter header
 *  
 *******************************************************************/

//=============================================================================
// Global defines

#define	LINELEN	16					// #bytes per line for mem dumps
#define	XPOLY	0x1021				// polynomial seed for CRC
#define	DUT_SRC		1
#define	SRAM_SRC	0
#define	ADDR_24		1

// pgm_status defines
#define	PGM_ERR		0x80
#define	ERA_ERR		0x40
#define	VFY_ERR		0x20
#define	VFY2_ERR	0x10
#define	ESC_ERR		0x01
#define	DBG_ERR		0x08

// Device type defines
#define	IS_EPROM0	0x01		// /WE pgm type
#define	IS_EPROM1	0x41		// /CE pgm type
#define	IS_EPROM2	0x81		// /CE w/ VPP togg type
#define	IS_EEPROM	0x02
#define	IS_FLASH	0x03
#define	IS_SRAM		0x04
#define	IS_SPIRAM	0x05
#define	IS_SPIEPROM	0x06
#define	IS_SPIEEPROM 0x07
#define	IS_SPIEFLASH 0x08
#define	IS_SMRTWTCH 0x09
#define	IS_PAL		0x0A


// DS1216x defines
#define	SMWA_C	0x0c
#define	SMWA_E	0x0e

// 28F101 defines
#define	PGM_101		0x40
#define	PGMV_101	0xc0
#define	RST_101		0xff
#define	ERAV_101	0xa0
#define	ERA_101		0x20
#define	RD_101		0x00
#define	DEV_101		0x90
#define	PULS_101	25				// pgm pulse count

// 28F020A defines
#define	PGM_020		0x50
#define	VFY_020		0xC0
#define	ERA_020		0x30

// 29F040 defines
#define	PGM_040		0xA0
#define	ERA_040		0x80

#define NO_DEVICE 0xff				// invalid device selector
#define ARG_MAX (9 + 1)				// 1 + max # of supported args (not including cmd)
#define	BOOT_RESP_VOID	0
#define BOOT_RESP_TO	1
#define	BOOT_RESP_ER	2
#define	BOOT_RESP_OK	4
#define	BOOT_RESP_EPERR	5
#define	BOOT_RESP_RAERR	6

#define	HM_BUFF_END		20			// HM-1xx MFmic buffer length
// MFmic HM-key state machine defines
#define	HMST_IDLE		1			// initial state
#define	HMST_PRESS		2			// pressed state: "h" or "r/R" to exit
#define	HMST_HOLD		3			// hold state: "r/R" to exit
#define	HMST_REL		4			// release debounce

#define	STAT_IPL		0xff
#define	STAT_ENAB		0xfe
#define	STAT_DISAB		0xfd
#define	STAT_BUF_LEN	22			// max length of status buffer
#define	SEND_STAT_PTT	0x80		// PTT flag signal
//=============================================================================
// public command fn declarations

int x_cmdfn(U8 nargs, char* args[], U32* offset);
void str_toupper(char* string);
int parse_args(char* cmd_string, char* args[]);
int whitespace(char c);
int quotespace(char c, char qu_c);
void bcmd_resp_init(void);
char dev_sel(U8 devid);
char process_CMD(U8 flag);
void exec_bcmd(char* bcmdbuf_ptr, char* obuf, U32* offset);
U8 gas_gage(U16 len);
void string_addr_init(void);
U8 asc_hex(S8 c);
float temp_float(U16 k);
U8 got_hm_asc(void);
U8 hm_asc(void);
//void cmd_fn_init(void);
char process_CMD(U8 flag);
U8 set_shift(U8 tf);
void pttsub_togg(U8 bflags);
void send_stat(U8 focus, U8 type, char* sptr);
U16 scheck(char* sptr, U8 len);
void upd_lcd(U8 bid);
U8 stat_enab(void);
void cntxt_stat(U8 focus);
U16 calcrc(U8 c, U16 oldcrc, U16 poly);
U16	read_sigdev(U8 verb);
U8 is_banked(U8 dev_id);
U8 vpp_bit(void);
void put_spin(U8 init);
U8  is_32ksram(void);
