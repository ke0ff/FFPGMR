/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: version.h
 *
 *  Module:    Control
 *
 *  Summary:   This header contains the software version number
 *             as a character string.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    06-23-24 jmh:  0.3 advanced EPROM pwr DVT/debug
 *    04-15-24 jmh:  0.2 bench release
 *    04-13-24 jmh:  0.1 First bench release
 *    04-10-24 jmh:  0.0 creation date
 *
 *******************************************************************/

#ifdef VERSOURCE
const S8    version_number[] = {"0.4"};
const S8    date_code[]      = {"04-Jul-2024"};
#endif

//-----------------------------------------------------------------------------
// Public Fn Declarations
//-----------------------------------------------------------------------------
void dispSWvers(void);
//void ccmdSWvers(char* sbuf);
U16 nvram_sn(void);

#define VERSION_INCLUDED
