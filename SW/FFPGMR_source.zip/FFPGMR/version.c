/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the serial I/O module for the FF-PGMR11
 *             protocol converter.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    07-30-14 jmh:  creation date
 *
 *******************************************************************/

#include "inc/tm4c123gh6pm.h"
#include "typedef.h"
#define VERSOURCE
#include "version.h"
#include "stdio.h"
#include "serial.h"
#include "init.h"

//------------------------------------------------------------------------------
// Define Statements
//------------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Local Variable Declarations
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Local Fn Declarations
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// dispSWvers() displays SW version
//-----------------------------------------------------------------------------
void dispSWvers(void){
	char buf[30];
	
	putsQ("\n\nKE0FF EPROM/FLASH/EEPROM Programmer, MK-II");
    sprintf(buf,"Vers: %s, Date: %s",version_number,date_code);
    putsQ(buf);
   	sprintf(buf,"IPL: $%04x ($01CF)",getipl());
   	putsQ(buf);
	putsQ("(c) 2026 by Joseph Haas (KE0FF), all rights reserved.\n");
}

//-----------------------------------------------------------------------------
// ccmdSWvers() returns SW version for ccmds
//-----------------------------------------------------------------------------
//void ccmdSWvers(char* sbuf){

//    sprintf(sbuf,"DU/LCD,IPL:%04x,Vers:%s,%s",getipl(),version_number,date_code);
//}

//-----------------------------------------------------------------------------
// nvram_sn() returns NVRAM sernum
//	this number is used to validate NVRAM revision.  If this number differs
//	from that stored on the NVRAM, the system must execute nvram_fix() to update
//	or re-init the SRAM contents.
//-----------------------------------------------------------------------------
U16 nvram_sn(void){

    return 0x0001;
}
