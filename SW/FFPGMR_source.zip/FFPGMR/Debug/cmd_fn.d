# FIXED

cmd_fn.obj: ../cmd_fn.c
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/string.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/math.h
cmd_fn.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_defs.h
cmd_fn.obj: ../typedef.h
cmd_fn.obj: ../inc/tm4c123gh6pm.h
cmd_fn.obj: ../init.h
cmd_fn.obj: ../typedef.h
cmd_fn.obj: ../cmd_fn.h
cmd_fn.obj: ../serial.h
cmd_fn.obj: ../version.h
cmd_fn.obj: ../tiva_init.h
cmd_fn.obj: ../typedef.h
cmd_fn.obj: ../spi.h
cmd_fn.obj: ../typedef.h
cmd_fn.obj: ../busio.h
cmd_fn.obj: ../adc.h
cmd_fn.obj: ../typedef.h
cmd_fn.obj: ../srec.h

../cmd_fn.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/string.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/math.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_defs.h: 
../typedef.h: 
../inc/tm4c123gh6pm.h: 
../init.h: 
../typedef.h: 
../cmd_fn.h: 
../serial.h: 
../version.h: 
../tiva_init.h: 
../typedef.h: 
../spi.h: 
../typedef.h: 
../busio.h: 
../adc.h: 
../typedef.h: 
../srec.h: 
