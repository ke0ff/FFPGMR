# FIXED

version.obj: ../version.c
version.obj: ../inc/tm4c123gh6pm.h
version.obj: ../typedef.h
version.obj: ../version.h
version.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h
version.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
version.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h
version.obj: ../serial.h
version.obj: ../init.h
version.obj: ../typedef.h
version.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h

../version.c: 
../inc/tm4c123gh6pm.h: 
../typedef.h: 
../version.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h: 
../serial.h: 
../init.h: 
../typedef.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
