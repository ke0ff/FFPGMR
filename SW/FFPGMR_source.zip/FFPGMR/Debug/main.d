# FIXED

main.obj: ../main.c
main.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
main.obj: ../inc/tm4c123gh6pm.h
main.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h
main.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
main.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h
main.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/string.h
main.obj: ../init.h
main.obj: ../typedef.h
main.obj: ../typedef.h
main.obj: ../version.h
main.obj: ../serial.h
main.obj: ../cmd_fn.h
main.obj: ../busio.h
main.obj: ../tiva_init.h
main.obj: ../typedef.h
main.obj: ../spi.h
main.obj: ../typedef.h

../main.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
../inc/tm4c123gh6pm.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/string.h: 
../init.h: 
../typedef.h: 
../typedef.h: 
../version.h: 
../serial.h: 
../cmd_fn.h: 
../busio.h: 
../tiva_init.h: 
../typedef.h: 
../spi.h: 
../typedef.h: 
