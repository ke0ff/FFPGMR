# FIXED

spi.obj: ../spi.c
spi.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h
spi.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
spi.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h
spi.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/math.h
spi.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_defs.h
spi.obj: ../inc/tm4c123gh6pm.h
spi.obj: ../typedef.h
spi.obj: ../init.h
spi.obj: ../typedef.h
spi.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
spi.obj: ../version.h
spi.obj: ../spi.h
spi.obj: ../typedef.h
spi.obj: ../serial.h
spi.obj: ../busio.h

../spi.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/math.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_defs.h: 
../inc/tm4c123gh6pm.h: 
../typedef.h: 
../init.h: 
../typedef.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
../version.h: 
../spi.h: 
../typedef.h: 
../serial.h: 
../busio.h: 
