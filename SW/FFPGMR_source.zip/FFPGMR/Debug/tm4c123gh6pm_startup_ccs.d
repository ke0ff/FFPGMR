# FIXED

tm4c123gh6pm_startup_ccs.obj: ../tm4c123gh6pm_startup_ccs.c
tm4c123gh6pm_startup_ccs.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
tm4c123gh6pm_startup_ccs.obj: ../typedef.h
tm4c123gh6pm_startup_ccs.obj: ../init.h
tm4c123gh6pm_startup_ccs.obj: ../typedef.h
tm4c123gh6pm_startup_ccs.obj: ../serial.h
tm4c123gh6pm_startup_ccs.obj: ../spi.h
tm4c123gh6pm_startup_ccs.obj: ../typedef.h
tm4c123gh6pm_startup_ccs.obj: ../inc/tm4c123gh6pm.h

../tm4c123gh6pm_startup_ccs.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
../typedef.h: 
../init.h: 
../typedef.h: 
../serial.h: 
../spi.h: 
../typedef.h: 
../inc/tm4c123gh6pm.h: 
