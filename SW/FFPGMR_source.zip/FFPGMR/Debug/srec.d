# FIXED

srec.obj: ../srec.c
srec.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
srec.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h
srec.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
srec.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h
srec.obj: ../inc/tm4c123gh6pm.h
srec.obj: ../typedef.h
srec.obj: ../init.h
srec.obj: ../typedef.h
srec.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h
srec.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h
srec.obj: ../srec.h
srec.obj: ../init.h
srec.obj: ../typedef.h
srec.obj: ../serial.h
srec.obj: ../cmd_fn.h
srec.obj: ../busio.h
srec.obj: ../spi.h
srec.obj: ../typedef.h

../srec.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h: 
../inc/tm4c123gh6pm.h: 
../typedef.h: 
../init.h: 
../typedef.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h: 
../srec.h: 
../init.h: 
../typedef.h: 
../serial.h: 
../cmd_fn.h: 
../busio.h: 
../spi.h: 
../typedef.h: 
