# FIXED

busio.obj: ../busio.c
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/string.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/math.h
busio.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_defs.h
busio.obj: ../typedef.h
busio.obj: ../inc/tm4c123gh6pm.h
busio.obj: ../init.h
busio.obj: ../typedef.h
busio.obj: ../tiva_init.h
busio.obj: ../typedef.h
busio.obj: ../busio.h
busio.obj: ../cmd_fn.h

../busio.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/string.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/ctype.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_isfuncdcl.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/math.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/_defs.h: 
../typedef.h: 
../inc/tm4c123gh6pm.h: 
../init.h: 
../typedef.h: 
../tiva_init.h: 
../typedef.h: 
../busio.h: 
../cmd_fn.h: 
