################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../tm4c123gh6pm.cmd 

A_SRCS += \
C:/ti/TivaWare_C_Series-1.1/driverlib/ewarm/Exe/driverlib.a 

C_SRCS += \
../PLL.c \
../adc.c \
../busio.c \
../cmd_fn.c \
../main.c \
../serial.c \
../spi.c \
../srec.c \
../tiva_init.c \
../tm4c123gh6pm_startup_ccs.c \
../version.c 

OBJS += \
./PLL.obj \
./adc.obj \
./busio.obj \
./cmd_fn.obj \
./main.obj \
./serial.obj \
./spi.obj \
./srec.obj \
./tiva_init.obj \
./tm4c123gh6pm_startup_ccs.obj \
./version.obj 

C_DEPS += \
./PLL.d \
./adc.d \
./busio.d \
./cmd_fn.d \
./main.d \
./serial.d \
./spi.d \
./srec.d \
./tiva_init.d \
./tm4c123gh6pm_startup_ccs.d \
./version.d 

C_DEPS__QUOTED += \
"PLL.d" \
"adc.d" \
"busio.d" \
"cmd_fn.d" \
"main.d" \
"serial.d" \
"spi.d" \
"srec.d" \
"tiva_init.d" \
"tm4c123gh6pm_startup_ccs.d" \
"version.d" 

OBJS__QUOTED += \
"PLL.obj" \
"adc.obj" \
"busio.obj" \
"cmd_fn.obj" \
"main.obj" \
"serial.obj" \
"spi.obj" \
"srec.obj" \
"tiva_init.obj" \
"tm4c123gh6pm_startup_ccs.obj" \
"version.obj" 

C_SRCS__QUOTED += \
"../PLL.c" \
"../adc.c" \
"../busio.c" \
"../cmd_fn.c" \
"../main.c" \
"../serial.c" \
"../spi.c" \
"../srec.c" \
"../tiva_init.c" \
"../tm4c123gh6pm_startup_ccs.c" \
"../version.c" 

A_SRCS__QUOTED += \
"C:/ti/TivaWare_C_Series-1.1/driverlib/ewarm/Exe/driverlib.a" 


