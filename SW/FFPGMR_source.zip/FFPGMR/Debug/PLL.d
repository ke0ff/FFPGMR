# FIXED

PLL.obj: ../PLL.c
PLL.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
PLL.obj: ../PLL.h
PLL.obj: ../typedef.h
PLL.obj: ../typedef.h
PLL.obj: ../inc/tm4c123gh6pm.h
PLL.obj: ../init.h
PLL.obj: ../typedef.h

../PLL.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
../PLL.h: 
../typedef.h: 
../typedef.h: 
../inc/tm4c123gh6pm.h: 
../init.h: 
../typedef.h: 
