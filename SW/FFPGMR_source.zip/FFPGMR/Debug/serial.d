# FIXED

serial.obj: ../serial.c
serial.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h
serial.obj: ../inc/tm4c123gh6pm.h
serial.obj: ../typedef.h
serial.obj: ../init.h
serial.obj: ../typedef.h
serial.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h
serial.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h
serial.obj: C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h
serial.obj: ../serial.h
serial.obj: ../cmd_fn.h

../serial.c: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdint.h: 
../inc/tm4c123gh6pm.h: 
../typedef.h: 
../init.h: 
../typedef.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdio.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/linkage.h: 
C:/ti/ccsv6/tools/compiler/arm_15.12.3.LTS/include/stdarg.h: 
../serial.h: 
../cmd_fn.h: 
