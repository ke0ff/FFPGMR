/********************************************************************
 ************ COPYRIGHT (c) 2024 by KE0FF, Taylor, TX   *************
 *
 *  File name: spi.h
 *
 *  Module:    Control
 *
 *  Summary:   defines and global declarations for spi.c
 *
 *******************************************************************/

#include "typedef.h"
#include <stdint.h>
#ifndef SPI_H_
#define SPI_H_


//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

//#define	BBSPI			// enable bit-bang SPI

// spi defines
#define	SRAM_READ	0x03				// SRAM read cmd
#define	SRAM_WRITE	0x02				// SRAM write cmd
#define	SRAM_MODE	0x01				// SRAM mode write cmd
#define	SRAM_SEQ	0x40				// SRAM seq mode

#define	SSITO_TIME	1000

// Processor I/O assignments
// ...see init.h

#define	BITRATE		200000L
#define	CPSDVSR		64L
#define	SCRVAL		((SYSCLK/(CPSDVSR * BITRATE))-1)

// 100K baud for SSI3
//#define	LCD_BAUD		25000L				// LCD serial I/O baud rate
//#define	SSI3_BR			LCD_BAUD			// ssi3 clock rate (Hz)
//#define SSI3_CPSDVSR	(16)
//#define	SSI3_SCR		(199)				//((SYSCLK/(SSI3_BR * SSI3_CPSDVSR)) - 1)

// TIMER1B isr mask
#define TIMER_MIS_BMASK	(TIMER_MIS_TBMMIS | TIMER_MIS_CBEMIS | TIMER_MIS_CBMMIS | TIMER_MIS_TBTOMIS)


// BUSY WAIT TIMEOUT
#define	BUSY_WAT	5					// max delay to wait for UART2 TX to clear (ms)


//-----------------------------------------------------------------------------
// Global Fns
//-----------------------------------------------------------------------------

void init_ssi0(void);
void sram_read_start(U32 addr);
void sram_write_start(U32 addr);
void sram_close(void);
U8 sram_read(U32 addr);
void sram_write(U32 addr, U8 data);

U8 is_ssito(void);
void kick_ssito(void);
void Timer1B_ISR(void);

#endif /* SPI_H_ */
