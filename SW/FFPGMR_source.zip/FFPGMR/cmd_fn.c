/********************************************************************
 ************ COPYRIGHT (c) 2024 by ke0ff, Taylor, TX   *************
 *
 *  File name: cmd_fn.c
 *
 *  Module:    Control
 *
 *  Summary:
 *  CLI Command Interpreter
 *  
 *******************************************************************/

// generally required includes
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include "typedef.h"
//#include <hw_types.h>

//#include <interrupt.h>

// application-specific includes
#include "inc/tm4c123gh6pm.h"
#include "init.h"						// App-specific SFR Definitions
#include "cmd_fn.h"						// fn protos, bit defines, rtn codes, etc.
#include "serial.h"
#include "version.h"
#include "tiva_init.h"
#include "spi.h"
#include "busio.h"
#include "adc.h"
#include "srec.h"

//#include "lcd_test.h"

//=============================================================================
// local Fn declarations

#define	cmd_type	char	// define as char for list < 255, else define as int

void get_BCD32(char *sptr, U32 *bcdval);
U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U32 params[ARG_MAX]);
cmd_type cmd_srch(char* string);
char do_cmd_help(char* obuf, U8 cmd_id);
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str);
void parse_ehex(char * sptr);
void disp_error(U8 errnum);
void disp_fail(char* buf, char* s, U16 c, U16 d);
void disp_wait_addr(char* buf);
U16 boot_se(U8* bptr, U16 start, U16 end, U16 ppaddr);
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a);
void disp_error_log(U8* lbuf, U16 len);
void do_help(void);
void disp_esc(char flag);
U8 sto_nvmem(U8 band, U8 memnum, char* sptr);
char* char_srch(char* sptr, char searchr);
U8 str_chks(char* sptr);
U32 dpl_calc(U16 dplcode);
U8 cadd(U16 dplcode, U8 index);
void putOK(U8 tf);
void dump_mem(U32 addrb, U32 addre, U8 dut, char* obuf);
void	dump_str(U8* data);
void	pgm_dut(U32 srt, U32 end, U8 dev_id);
void	pgm_ep(U32 srt, U32 end, U8 dev_id);
void	era_dut(U8 dev_id);
void	era_fla(U32 dotcnt);
void	pgm_fla(U32 end, U32 dotcnt);
U32		blank_dut(U32 srt, U32 end, U8 check, U32 dotcnt, U8 hilo);
void	vfy_dut(U32 srt, U32 end, U8 dev_id);
U32		vfy_fla(U32 srt, U32 end, U32 dotcnt);
void	gasg_srt(void);
void	set_fla(U32 maxad, char* bbuf);
void	smartwatch_unlock(U8 type);
void	smart_write(U8 d, U8 type);
U8	smart_read(U8 type);
void put_dot(char dot, U8 verb);
U8 srch_mfrdev(U16 mfrdev);
void init_dev(U8 dev_id);
void copy_dut(U32 addrb, U32 addre);
U32 walkabt(U32 srt, U32 end, U8 type, U8 width);
U8 is_odd_parity(U8 data);

//===================================================================================================
// Command token syntax defines and instantiations.
//
// This is the define list for the command line tokens used in this CLI.  Each "CMD" define is a quoted string that
//	corresponds to the minimum typed command line token.  The corresponding "ENUM" define sets the value token that
//	is used in the parsing switch.  The "CMD" defines are entered into an array of arrays with a terminating array of 0xff, eg:
//		char* cmd_list[] = { CMD_1, CMD_2, ... , "\xff" };
//	The "ENUM" defines are likewise entered into an "enum" statement, eg:
//		enum cmd_enum{ ENUM_1, ENUM_2, ... , ENUM_LAST }; in the same order as in the cmd_list
//	The primary requirement is for the subscript numbers for the "CMD" and "ENUM" must be in matching order.
//		The list order of the CMD/ENUM defines establishes the search order.  Lower-indexed (left-most) items are
//		searched first.  This means that the least-ambiguous items should be included earlier in the list to prevent
//		situations whereby a command of "BT" is entered, but matches on "B" in the list because it was the first
//		encountered.  So, for this example, "BT" should be the first "B..." token in the list.
//
// cmd_type is adjusted to the number of tokens in the list.  If the command tokens exceeds 255, it must be changed to an "int"
//		type.
//
//=================================================================
// This section is the device list and personality meta data
// The device types are parsed in the main command parser, so the "CMD_" and "ENUM_" defines feed into the parser defines (see below)
// Each of the other parameters for each device are subsequently grouped into look-up arrays so that they can be fetched as needed
//	using the device ID (ENUM_).

#define	MAX_CHR		8		// chr limit is "7" for the device types (!! includes the null-term chr !!)

#define	CMD_00		"nodev"				// #00 null device
#define	ENUM_00		dev00_cmd
#define	MAXADDR_00	0L
#define	SKT_00		0
#define	SKT2_00		0
#define	VCC_00		VCC_500
#define	VPP_00		VPP_050
#define	VPPC_00		0
#define	WEE_00		0
#define	WET_00		1
#define	MAXC_00		0
#define	BANK_00		0
#define	TYPE_00		0
										// #01
#define	CMD_0AZ		"28c64z"			// device name string
#define	ENUM_0AZ	dev28z_cmd			// device identifier
#define	MAXADDR_0AZ	0x000020L			// device size, bytes
#define	SKT_0AZ		(SET_WE_A14|SET_VPPA15) // EE_A15 and WE_A14 selectors (skt())
#define	SKT2_0AZ	(VCC_A17|ID9)		// ah3 latch settings
#define	VCC_0AZ		VCC_500				// programming VCC
#define	VPP_0AZ		VPP_050				// VPP
#define	VPPC_0AZ	0					//ah3 latch VPP control (if 0, no control needed)
										//	This is for devices that share OE and VPP and need VPP to be
										//	disabled for verify operations
#define	WEE_0AZ		WE_N				// WE pin (on Port E) for PGM
#define	WET_0AZ		1					// WE timing PGM (us)
#define	MAXC_0AZ	1					// max# of PGM cycles for byte
#define	BANK_0AZ	0					// #shifts to align high-addr bits to bank# if bank'd device (e.g., 27C513 or 27C011), else 0
#define	TYPE_0AZ	IS_EEPROM			// device type


#define	CAL_PGM		8					// delta pgm timing to account for execution latency in wait_lat.  This value
										//	is a calibration correction determined by measuring the pulse-width of the
										//	/PGM cycle with an oscilloscope.  The "overage" in the timing is placed here.

#define	CMD_0A		"28c64"				// #02
#define	ENUM_0A		dev28_cmd
#define	MAXADDR_0A	0x002000L
#define	SKT_0A		(SET_WE_A14|SET_VPPA15)
#define	SKT2_0A		VCC_A17
#define	VCC_0A		VCC_500
#define	VPP_0A		VPP_050
#define	VPPC_0A		0
#define	WEE_0A		WE_N
#define	WET_0A		1
#define	MAXC_0A		1
#define	BANK_0A		0
#define	TYPE_0A		IS_EEPROM

#define	CMD_0B		"28f101"			// #03
#define	ENUM_0B		devFL1_cmd
#define	MAXADDR_0B  0x020000L
#define	SKT_0B		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B		(VPP_A18|WE_A18)
#define	VCC_0B		VCC_500
#define	VPP_0B		VPP_120
#define	VPPC_0B		0
#define	WEE_0B		WE_N
#define	WET_0B		1
#define	MAXC_0B		1
#define	BANK_0B		0
#define	TYPE_0B		IS_FLASH

#define	CMD_0B3		"28f256"			// #04
#define	ENUM_0B3	devFL3_cmd
#define	MAXADDR_0B3	0x008000L
#define	SKT_0B3		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B3	(VPP_A18|WE_A18)
#define	VCC_0B3		VCC_500
#define	VPP_0B3		VPP_120
#define	VPPC_0B3	0
#define	WEE_0B3		WE_N
#define	WET_0B3		1
#define	MAXC_0B3	1
#define	BANK_0B3	0
#define	TYPE_0B3	IS_FLASH

#define	CMD_0B2		"28f512"			// #05
#define	ENUM_0B2	devFL2_cmd
#define	MAXADDR_0B2	0x010000L
#define	SKT_0B2		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B2	(VPP_A18|WE_A18)
#define	VCC_0B2		VCC_500
#define	VPP_0B2		VPP_120
#define	VPPC_0B2	0
#define	WEE_0B2		WE_N
#define	WET_0B2		1
#define	MAXC_0B2	1
#define	BANK_0B2	0
#define	TYPE_0B2	IS_FLASH

#define	CMD_0B4		"28f010"			// #06
#define	ENUM_0B4	devFL4_cmd
#define	MAXADDR_0B4	0x020000L
#define	SKT_0B4		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B4	(VPP_A18|WE_A18)
#define	VCC_0B4		VCC_500
#define	VPP_0B4		VPP_120
#define	VPPC_0B4	0
#define	WEE_0B4		WE_N
#define	WET_0B4		1
#define	MAXC_0B4	1
#define	BANK_0B4	0
#define	TYPE_0B4	IS_FLASH

#define	CMD_0B5		"28f020"			// #07
#define	ENUM_0B5	devFL5_cmd
#define	MAXADDR_0B5	0x040000L
#define	SKT_0B5		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B5	(VPP_A18|WE_A18)
#define	VCC_0B5		VCC_500
#define	VPP_0B5		VPP_120
#define	VPPC_0B5	0
#define	WEE_0B5		WE_N
#define	WET_0B5		1
#define	MAXC_0B5	1
#define	BANK_0B5	0
#define	TYPE_0B5	IS_FLASH

#define	CMD_0B8		"28f020a"			// #24
#define	ENUM_0B8	devFL8_cmd
#define	MAXADDR_0B8	0x040000L
#define	SKT_0B8		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B8	(VPP_A18|WE_A18)
#define	VCC_0B8		VCC_500
#define	VPP_0B8		VPP_120
#define	VPPC_0B8	0
#define	WEE_0B8		WE_N
#define	WET_0B8		1
#define	MAXC_0B8	1
#define	BANK_0B8	0
#define	TYPE_0B8	IS_FLASH

#define	CMD_0B6		"29f040"			// #08
#define	ENUM_0B6	devFL6_cmd
#define	MAXADDR_0B6	0x080000L
#define	SKT_0B6		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B6	WE_A18
#define	VCC_0B6		VCC_500
#define	VPP_0B6		VPP_050
#define	VPPC_0B6	0
#define	WEE_0B6		WE_N
#define	WET_0B6		1
#define	MAXC_0B6	1
#define	BANK_0B6	0
#define	TYPE_0B6	IS_FLASH

#define	CMD_0B7		"29f010"			// #23
#define	ENUM_0B7	devFL7_cmd
#define	MAXADDR_0B7	0x020000L
#define	SKT_0B7		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0B7	WE_A18
#define	VCC_0B7		VCC_500
#define	VPP_0B7		VPP_050
#define	VPPC_0B7	0
#define	WEE_0B7		WE_N
#define	WET_0B7		1
#define	MAXC_0B7	1
#define	BANK_0B7	0
#define	TYPE_0B7	IS_FLASH

#define	CMD_0C		"27c011"			// #09
#define	ENUM_0C		devEPB1_cmd
#define	MAXADDR_0C	0x020000L
#define	SKT_0C		(SET_WE_A14|SET_VPPA15)			// socket pin 29 = /WE, socket pin 3 = VPP
#define	SKT2_0C		(VCC_A17|VPP_A15EE)				// socket pin 30 = VCC, socket pin 3 = VPP
#define	VCC_0C		VCC_625							// set VCC = 6.25 V
#define	VPP_0C		VPP_127							// set VPP = 12.75 V
#define	VPPC_0C		0
#define	WEE_0C		WE_N							// write = WE_N (port E)
#define	WET_0C		(100 - CAL_PGM)					// PGM pulse width
#define	MAXC_0C		24								// PGM cycle count
#define	BANK_0C		14								// Addr bank size (#LSRs needed to align bank LSb with D0)
#define	TYPE_0C		IS_EPROM
#define	VPPCB_0C	VPP_A15EE						// VPP id for bank switched devices

#define	CMD_0C2		"27c513"			// #10
#define	ENUM_0C2	devEPB2_cmd
#define	MAXADDR_0C2	0x010000L
#define	SKT_0C2		(SET_WE_A14|CLR_VPPA15)
#define	SKT2_0C2	VCC_A17	//(VCC_A17|VPP_OE)
#define	VCC_0C2		VCC_625
#define	VPP_0C2		VPP_127
#define	VPPC_0C2	VPP_OE
#define	WEE_0C2		(CS_N | OEVPP_BIT)
#define	WET_0C2		100					// no CAL here because we don't use the expansion ports
#define	MAXC_0C2	24
#define	BANK_0C2	14
#define	TYPE_0C2	IS_EPROM
#define	VPPCB_0C2	VPP_OE

#define	CMD_0D		"27c010"			// #11
#define	ENUM_0D		devEP1_cmd
#define	MAXADDR_0D	0x020000L
#define	SKT_0D		CLR_VPPA15
#define	SKT2_0D		(VPP_A18|WE_A18)
#define	VCC_0D		VCC_650
#define	VPP_0D		VPP_127
#define	VPPC_0D		0
#define	WEE_0D		WE_N
#define	WET_0D		(50)
#define	MAXC_0D		10
#define	BANK_0D		0
#define	TYPE_0D		IS_EPROM

#define	CMD_0Di		"27c010i"			// #22
#define	ENUM_0Di	devEP1i_cmd
#define	MAXADDR_0Di	0x020000L
#define	SKT_0Di		CLR_VPPA15
#define	SKT2_0Di	(VPP_A18|WE_A18)
#define	VCC_0Di		VCC_625
#define	VPP_0Di		VPP_127
#define	VPPC_0Di	0
#define	WEE_0Di		WE_N
#define	WET_0Di		100 //(50)
#define	MAXC_0Di	25 //10
#define	BANK_0Di	0
#define	TYPE_0Di	IS_EPROM

#define	CMD_0D2		"27c512"			// #12
#define	ENUM_0D2	devEP2_cmd
#define	MAXADDR_0D2	0x010000L
#define	SKT_0D2		(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0D2	VCC_A17 //(VCC_A17|VPP_OE)
#define	VCC_0D2		VCC_625
#define	VPP_0D2		VPP_127
#define	VPPC_0D2	VPP_OE
#define	WEE_0D2		(CS_N | OEVPP_BIT)
#define	WET_0D2		100					// no CAL here because we don't use the expansion ports
#define	MAXC_0D2	25
#define	BANK_0D2	0
#define	TYPE_0D2	IS_EPROM

#define	CMD_0D2S	"27c512s"			// #18
#define	ENUM_0D2S	devEP2S_cmd
#define	MAXADDR_0D2S 0x010000L

#define	SKT_0D2S	(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0D2S	VCC_A17 //(VCC_A17|VPP_OE)
#define	VCC_0D2S	VCC_625
#define	VPP_0D2S	VPP_127
#define	VPPC_0D2S	VPP_OE
#define	WEE_0D2S	CS_N
#define	WET_0D2S	(100 - CAL_PGM)
#define	MAXC_0D2S	25
#define	BANK_0D2S	0
#define	TYPE_0D2S	IS_EPROM

#define	CMD_0D3		"27c256"			// #13
#define	ENUM_0D3	devEP3_cmd
#define	MAXADDR_0D3	0x008000L
#define	SKT_0D3		(CLR_WE_A14|SET_VPPA15)
#define	SKT2_0D3	(VPP_A15EE|VCC_A17)
#define	VCC_0D3		VCC_625
#define	VPP_0D3		VPP_127
#define	VPPC_0D3	0
#define	WEE_0D3		CS_N
#define	WET_0D3		(100 - CAL_PGM)
#define	MAXC_0D3	25
#define	BANK_0D3	0
#define	TYPE_0D3	IS_EPROM

#define	CMD_0D4		"27c020"			// #14
#define	ENUM_0D4	devEP4_cmd
#define	MAXADDR_0D4	0x040000L
#define	SKT_0D4		(CLR_VPPA15)
#define	SKT2_0D4	(VPP_A18|WE_A18)
#define	VCC_0D4		VCC_625
#define	VPP_0D4		VPP_127
#define	VPPC_0D4	0
#define	WEE_0D4		WE_N
#define	WET_0D4		(100 - CAL_PGM)
#define	MAXC_0D4	24
#define	BANK_0D4	0
#define	TYPE_0D4	IS_EPROM

#define	CMD_0D5		"27c040"			// #15
#define	ENUM_0D5	devEP5_cmd
#define	MAXADDR_0D5	0x080000L
#define	SKT_0D5		(SET_WE_A14|SET_VPPA15)
#define	SKT2_0D5	VPP_A18
#define	VCC_0D5		VCC_650
#define	VPP_0D5		VPP_127
#define	VPPC_0D5	0
#define	WEE_0D5		CS_N
#define	WET_0D5		(50 - CAL_PGM)
#define	MAXC_0D5	10
#define	BANK_0D5	0
#define	TYPE_0D5	IS_EPROM

#define	CMD_0E		"1216E"				// #16
#define	ENUM_0E		devEPE_cmd
#define	MAXADDR_0E	0x002000L
#define	SKT_0E		(SET_WE_A14|SET_VPPA15)
#define	SKT2_0E		VCC_A17
#define	VCC_0E		VCC_500
#define	VPP_0E		VPP_050
#define	VPPC_0E		0
#define	WEE_0E		WE_N
#define	WET_0E		1
#define	MAXC_0E		1
#define	BANK_0E		0
#define	TYPE_0E		IS_SMRTWTCH

#define	CMD_0E2		"1216C"				// #17
#define	ENUM_0E2	devEPE2_cmd
#define	MAXADDR_0E2 0x002000L
#define	SKT_0E2		(SET_WE_A14|SET_VPPA15)
#define	SKT2_0E2	VCC_A17
#define	VCC_0E2		VCC_500
#define	VPP_0E2		VPP_050
#define	VPPC_0E2	0
#define	WEE_0E2		WE_N
#define	WET_0E2		1
#define	MAXC_0E2	1
#define	BANK_0E2	0
#define	TYPE_0E2	IS_SMRTWTCH

#define	CMD_0D3S	"27c256s"			// #19
#define	ENUM_0D3S	devEP3S_cmd
#define	MAXADDR_0D3S 0x008000L
#define	SKT_0D3S	(CLR_WE_A14|CLR_VPPA15)
#define	SKT2_0D3S	(VPP_A15EE|VCC_A17)
#define	VCC_0D3S	VCC_625
#define	VPP_0D3S	VPP_127
#define	VPPC_0D3S	0
#define	WEE_0D3S	CS_N
#define	WET_0D3S	(100 - CAL_PGM)
#define	MAXC_0D3S	25
#define	BANK_0D3S	0
#define	TYPE_0D3S	IS_EPROM

#define	CMD_0F		"27c64"				// #20
#define	ENUM_0F		dev2764_cmd
#define	MAXADDR_0F	0x002000L
#define	SKT_0F		(SET_WE_A14|SET_VPPA15)
#define	SKT2_0F		(VPP_A15EE|VCC_A17)
#define	VCC_0F		VCC_600
#define	VPP_0F		VPP_122
#define	VPPC_0F		0
#define	WEE_0F		WE_N
#define	WET_0F		(1000 - CAL_PGM)
#define	MAXC_0F		24
#define	BANK_0F		0
#define	TYPE_0F		IS_EPROM

#define	CMD_0F2		"27c64s"			// #21
#define	ENUM_0F2	dev2764s_cmd
#define	MAXADDR_0F2	0x002000L
#define	SKT_0F2		(SET_WE_A14|SET_VPPA15)
#define	SKT2_0F2	(VPP_A15EE|VCC_A17)
#define	VCC_0F2		VCC_600
#define	VPP_0F2		VPP_127
#define	VPPC_0F2	VPP_OE
#define	WEE_0F2		WE_N
#define	WET_0F2		(100 - CAL_PGM)
#define	MAXC_0F2	10
#define	BANK_0F2	0
#define	TYPE_0F2	IS_EPROM

#define	MAX_DEV		25					// # items in device list (max ID + 1).  Update this if new devices added

//============================================================
//
//	CLI command parser defines

#define	CMD_A0		"ad"			// adc test command ID
#define	ENUM_A0		adc_cmd

#define	CMD_B0		"bla"			// blank test command ID
#define	ENUM_B0		bla_cmd

#define	CMD_B1		"bu"			// bus test command ID
#define	ENUM_B1		bus_cmd

#define	CMD_C0		"clk"			// smartwatch command ID
#define	ENUM_C0		clk_cmd

#define	CMD_C1		"copy"			// smartwatch command ID
#define	ENUM_C1		copy_cmd

#define	CMD_D0		"dev"			// device status
#define	ENUM_D0		dev_cmd

#define	CMD_D1		"dump"			// device status
#define	ENUM_D1		dump_cmd

#define	CMD_D2		"dvt"			// dvt
#define	ENUM_D2		dvt_cmd

#define	CMD_E0		"era"			// erase FLASH device
#define	ENUM_E0		era_cmd

#define	CMD_F0		"fill"			// mem test
#define	ENUM_F0		fill_cmd

#define	CMD_I0		"idump"			// intel hex dump
#define	ENUM_I0		idump_cmd

#define	CMD_M0		"max"			// mem test
#define	ENUM_M0		maxa_cmd

#define	CMD_M1		"mfr"			// mem test
#define	ENUM_M1		mfr_cmd

#define	CMD_M2		"mt"			// mem test
#define	ENUM_M2		mem_cmd

#define	CMD_O0		"off"			// vcc off
#define	ENUM_O0		vccoff_cmd
#define	CMD_O1		"on"			// vcc on
#define	ENUM_O1		vccon_cmd

#define	CMD_P0		"pgm"			// DUT PGM
#define	ENUM_P0		pgm_cmd

#define	CMD_P1		"pt"			// pulse test
#define	ENUM_P1		pt_cmd

#define	CMD_S0		"sdump"			// srec dump
#define	ENUM_S0		sdump_cmd

#define	CMD_S1		"svfy"			// srec dump
#define	ENUM_S1		svfy_cmd

#define	CMD_T0		"te"			// sram test
#define	ENUM_T0		test_cmd

#define	CMD_T1		"tvcc"			// vdd adjust
#define	ENUM_T1		tvcc_cmd

#define	CMD_T2		"tvpp"			// vdd adjust
#define	ENUM_T2		tvpp_cmd

#define	CMD_U0		"upl"			// sram test
#define	ENUM_U0		upl_cmd

#define	CMD_V0		"vfy"			// verify DUT against sram
#define	ENUM_V0		vfy_cmd

#define	CMD_V1		"vppf"			// vppf control cmd
#define	ENUM_V1		vppfon_cmd

#define	CMD_96		"??"			// master help list
#define	ENUM_96		help3
#define	CMD_97		"help"			// Alternate help syntax
#define	ENUM_97		help2
#define	CMD_98		"?"				// help list
#define	ENUM_98		help1
#define	CMD_99		"vers"			// version info
#define	ENUM_99		vers
#define	ENUM_LAST	lastcmd

// === A SIMPLE COMMAND PARSER ARCHITECTURE ===
//
// Command keywords are listed in the same order as the enum list.  The enum is used in the main dispatch switch during command parsing.
//	Keyword order must be manually orchestrated to place shorter keywords after longer keywords for a given alphabetical ordering.  This
//	is opposite from the traditional alphabetical ordering protocols.  The reason is that shorter keywords will match first, rendering
//	subsequent keywords with the same prefix unreachable by the parser.  This limitation only applies to keywords with the same prefix,
//	such as "offset" and "off".  In this example, "offset" must appear in the list before "off".
//
// Keywords may be truncated to a minimum unique prefix such as "vers" for "version".
//
// By defining the keywords and enum labels as #defines (see above), the management of the keywords and enum lists is greatly simplified.
//	A naming convention, such as used here, also helps simplify the task.  Here, the keywords have the root "CMD_" followed by the first
//	character of the keyword text, then an ordinal number as the suffix.  The entire keyword text could also be the suffix.  This same suffix
//	is applied to the enum list items, using the root prefix of "ENUM_".  Thus, the two lists can be easily constructed and verified.  This
//	is important because the two lists must be in lock-step with each other.

// Command keyword ordinal list
char* cmd_list[] = { CMD_00, CMD_0AZ, CMD_0A, CMD_0B, CMD_0B2, CMD_0B3, CMD_0B4, CMD_0B5, CMD_0B6, CMD_0C, CMD_0C2, CMD_0D, CMD_0D2, CMD_0D3, CMD_0D4,
					 CMD_0D5, CMD_0E, CMD_0E2, CMD_0D2S, CMD_0D3S, CMD_0F, CMD_0F2, CMD_0Di, CMD_0B7, CMD_0B8,
					 CMD_A0, CMD_B0, CMD_B1, CMD_C0, CMD_C1, CMD_D0, CMD_D1, CMD_D2, CMD_E0, CMD_F0, CMD_I0,  CMD_M0,  CMD_M1, CMD_M2, CMD_O0,  CMD_O1,
					 CMD_P0, CMD_P1, CMD_S0, CMD_S1, CMD_T0, CMD_T1, CMD_T2, CMD_U0, CMD_V0, CMD_V1,  CMD_96,  CMD_97, CMD_98,  CMD_99, "\xff" };
// Command id enum list
enum       cmd_enum{ ENUM_00, ENUM_0AZ, ENUM_0A, ENUM_0B, ENUM_0B2, ENUM_0B3, ENUM_0B4, ENUM_0B5, ENUM_0B6, ENUM_0C, ENUM_0C2, ENUM_0D, ENUM_0D2, ENUM_0D3,
					 ENUM_0D4, ENUM_0D5, ENUM_0E, ENUM_0E2, ENUM_0D2S, ENUM_0D3S, ENUM_0F, ENUM_0F2, ENUM_0Di, ENUM_0B7, ENUM_0B8,
					 ENUM_A0, ENUM_B0, ENUM_B1, ENUM_C0, ENUM_C1, ENUM_D0, ENUM_D1, ENUM_D2, ENUM_E0, ENUM_F0, ENUM_I0,  ENUM_M0,  ENUM_M1, ENUM_M2,
					 ENUM_O0,  ENUM_O1, ENUM_P0, ENUM_P1, ENUM_S0, ENUM_S1, ENUM_T0, ENUM_T1, ENUM_T2, ENUM_U0, ENUM_V0, ENUM_V1, ENUM_96, ENUM_97,
					 ENUM_98, ENUM_99, ENUM_LAST };

// enum error message ID
enum err_enum{ no_response, no_device, target_timeout };

// === MFR/DEV valid lists ===
// These arrays group all of the MFR/DEV ids (U16 values) into a single "device".  The idea is that the grouped MFR/DEV codes have compatible
//	pinouts and programming algorithms.

// "nodev"
U16	SIGID_00[] =  { 0 };		// empty list is signal to skip DEVID step

// "28c64"
U16	SIGID_0A[] =  { 0 };		// empty list is signal to skip A9 DEVID step

// "27c64" 1ms/25 cyc
U16	SIGID_0F[] =  { 0x0115, 0x8908, 0x8907, 0x150B, 0 };

// "27c64s" 100us/10 cyc
U16	SIGID_0F2[] =  { 0x2902, 0 };

// "28f101"
U16	SIGID_0B[] =  { 0x2007, 0 };

// "28f256"
U16	SIGID_0B3[] = { 0x01A1, 0x012F, 0xADB5, 0x20A8, 0 };

// "28f512"
U16	SIGID_0B2[] = { 0x0125, 0x31B8, 0x89B8, 0x2002, 0 };

// "28f010"
U16	SIGID_0B4[] = { 0x01A7, 0x31B4, 0x89B4, 0 };

// "28f020"
U16	SIGID_0B5[] = { 0x012A, 0x31BD, 0x89BD, 0 };

// "29f040"
U16	SIGID_0B6[] = { 0x04D5, 0x014C, 0x01C8, 0x01A4,
					0x01D5, 0x016E, 0x014F, 0x01AD,
					0x0141, 0x3786, 0xADA4, 0x04A4,
					0x20E2, 0x20AC, 0x20F1, 0x20AD, 0 };

// "28f010"
U16	SIGID_0B7[] = { 0x0120, 0 };

// "29f020a"
U16	SIGID_0B8[] = { 0x0129, 0 };

// "27c011"
U16	SIGID_0C[] =  { 0x8931, 0 };

// "27c513"
U16	SIGID_0C2[] = { 0x89F9, 0 };

// "27c010"
U16	SIGID_0D[] =  { 0x010E, 0x1E05, 0x8F86, 0xC20E,
					0x1C83, 0x1515, 0x2005, 0x9746,
					0x97D6, 0x23C1, 0 };

// "27c010", Intel
U16	SIGID_0Di[] =  { 0x8935, 0x893B, 0 };

// "27c512" 10 cyc
U16	SIGID_0D2[] = { 0x1E0D, 0x8F85, 0x04E3, 0x290D,
					0x0794, 0x1C07, 0x1025, 0x151D,
					0x9785, 0x9885, 0 };

// "27c256" 10 cyc
U16	SIGID_0D3[] = { 0x298C, 0 };								// uChip

// "27c020"
U16 SIGID_0D4[] = { 0x0197, 0x1E86, 0x8934, 0xC220,
					0x1C8A, 0x8F07, 0x2061, 0x9732, 0 };

// "27c040"
U16 SIGID_0D5[] = { 0x019B, 0x1E0B, 0x8F08, 0x893D,
					0x1C0E, 0x10C8, 0x2041, 0x9750,
					0x988C, 0 };

// "28c64Z"
U16	SIGID_0AZ[] =  { 0 };		// empty list is signal to skip DEVID step

// "27c512s" 25 cyc
U16	SIGID_0D2S[] = { 0x203D, 0x0191, 0x89FD, 0xC291, 0 };

// "27c256s" 25 cyc
U16	SIGID_0D3S[] = { 0x1E8C, 0x8F04, 0x07B0, 0x898C,			// Atmel,    NS,   Hitachi,  Intel
					 0xC210, 0x158C, 0x9B04, 0x208D,			// uCronix,  NXP,  ST,       ST
					 0x9704, 0x9845, 0, };						// TI,       Toshiba
// "end of list"
U16 SIGID_END[] = { 0xffff, 0 };

// === Device-specific parameter lists ===

		// list of devices
char	devid_list[MAX_DEV] = { ENUM_00,  ENUM_0AZ, ENUM_0A,   ENUM_0B,
								ENUM_0B2, ENUM_0B3, ENUM_0B4,  ENUM_0B5,
								ENUM_0B6, ENUM_0C,  ENUM_0C2,  ENUM_0D,
								ENUM_0D2, ENUM_0D3, ENUM_0D4,  ENUM_0D5,
								ENUM_0E,  ENUM_0E2, ENUM_0D2S, ENUM_0D3S,
								ENUM_0F,  ENUM_0F2, ENUM_0Di,  ENUM_0B7,
								ENUM_0B8 };

		// text device name list (null-string terminated)
char	dev_list[MAX_DEV+1][MAX_CHR] = { {CMD_00},  {CMD_0AZ}, {CMD_0A},   {CMD_0B},
										 {CMD_0B2}, {CMD_0B3}, {CMD_0B4},  {CMD_0B5},
										 {CMD_0B6}, {CMD_0C},  {CMD_0C2},  {CMD_0D},
										 {CMD_0D2}, {CMD_0D3}, {CMD_0D4},  {CMD_0D5},
										 {CMD_0E},  {CMD_0E2}, {CMD_0D2S}, {CMD_0D3S},
										 {CMD_0F},  {CMD_0F2}, {CMD_0Di},  {CMD_0B7},
										 {CMD_0B8},  "\0" };

		// list of pointers to MFR/DEV lists for each device type (0xffff terminated)
U16*	devid_ptr[MAX_DEV+1] =	  { SIGID_00,  SIGID_0AZ, SIGID_0A,   SIGID_0B,
									SIGID_0B2, SIGID_0B3, SIGID_0B4,  SIGID_0B5,
									SIGID_0B6, SIGID_0C,  SIGID_0C2,  SIGID_0D,
									SIGID_0D2, SIGID_0D3, SIGID_0D4,  SIGID_0D5,
									SIGID_00,  SIGID_00,  SIGID_0D2S, SIGID_0D3S,
									SIGID_0F,  SIGID_0F2, SIGID_0Di,  SIGID_0B7,
									SIGID_0B8,  SIGID_END };

		// max address for each device type
U32		maxaddr_list[MAX_DEV] =	  { MAXADDR_00,  MAXADDR_0AZ, MAXADDR_0A,   MAXADDR_0B,
		 	 	 	 	 	 	 	MAXADDR_0B2, MAXADDR_0B3, MAXADDR_0B4,  MAXADDR_0B5,
									MAXADDR_0B6, MAXADDR_0C,  MAXADDR_0C2,  MAXADDR_0D,
									MAXADDR_0D2, MAXADDR_0D3, MAXADDR_0D4,  MAXADDR_0D5,
									MAXADDR_0E,  MAXADDR_0E2, MAXADDR_0D2S, MAXADDR_0D3S,
									MAXADDR_0F,  MAXADDR_0F2, MAXADDR_0Di,  MAXADDR_0B7,
									MAXADDR_0B8 };

		// list of SKT() settings
U8		skt_list[MAX_DEV] =		  { SKT_00,  SKT_0AZ, SKT_0A,   SKT_0B,
 	 	 							SKT_0B2, SKT_0B3, SKT_0B4,  SKT_0B5,
									SKT_0B6, SKT_0C,  SKT_0C2,  SKT_0D,
									SKT_0D2, SKT_0D3, SKT_0D4,  SKT_0D5,
									SKT_0E,  SKT_0E2, SKT_0D2S, SKT_0D3S,
									SKT_0F,  SKT_0F2, SKT_0Di,  SKT_0B7,
									SKT_0B8 };

		// list of SKT2() settings (ah3 latch)
U8		skt2_list[MAX_DEV] = 	  { SKT2_00,  SKT2_0AZ, SKT2_0A,   SKT2_0B,
									SKT2_0B2, SKT2_0B3, SKT2_0B4,  SKT2_0B5,
									SKT2_0B6, SKT2_0C,  SKT2_0C2,  SKT2_0D,
									SKT2_0D2, SKT2_0D3, SKT2_0D4,  SKT2_0D5,
									SKT2_0E,  SKT2_0E2, SKT2_0D2S, SKT2_0D3S,
									SKT2_0F,  SKT2_0F2, SKT2_0Di,  SKT2_0B7,
									SKT2_0B8 };

		// list of VCC/VPP (PGM mode) settings
U8		vcc_list[MAX_DEV] = 	  { VCC_00,  VCC_0AZ, VCC_0A,   VCC_0B,
									VCC_0B2, VCC_0B3, VCC_0B4,  VCC_0B5,
									VCC_0B6, VCC_0C,  VCC_0C2,  VCC_0D,
									VCC_0D2, VCC_0D3, VCC_0D4,  VCC_0D5,
									VCC_0E,  VCC_0E2, VCC_0D2S, VCC_0D3S,
									VCC_0F,  VCC_0F2, VCC_0Di,  VCC_0B7,
									VCC_0B8 };

		// VPP list
U8		vpp_list[MAX_DEV] = 	  { VPP_00,  VPP_0AZ, VPP_0A,   VPP_0B,
									VPP_0B2, VPP_0B3, VPP_0B4,  VPP_0B5,
									VPP_0B6, VPP_0C,  VPP_0C2,  VPP_0D,
									VPP_0D2, VPP_0D3, VPP_0D4,  VPP_0D5,
									VPP_0E,  VPP_0E2, VPP_0D2S, VPP_0D3S,
									VPP_0F,  VPP_0F2, VPP_0Di,  VPP_0B7,
									VPP_0B8 };

		// ah3 latch VPP enable bitmasks (value of 0 means that there is no need to control VPP for PGM VFY)
U8		vppc_list[MAX_DEV] = 	  { VPPC_00,  VPPC_0AZ, VPPC_0A,   VPPC_0B,
									VPPC_0B2, VPPC_0B3, VPPC_0B4,  VPPC_0B5,
									VPPC_0B6, VPPC_0C,  VPPC_0C2,  VPPC_0D,
									VPPC_0D2, VPPC_0D3, VPPC_0D4,  VPPC_0D5,
									VPPC_0E,  VPPC_0E2, VPPC_0D2S, VPPC_0D3S,
									VPPC_0F,  VPPC_0F2, VPPC_0Di,  VPPC_0B7,
									VPPC_0B8 };

		// identifies WE signal for programming (Port E)
U8		we_list[MAX_DEV] = { WEE_00,  WEE_0AZ, WEE_0A,   WEE_0B,
							 WEE_0B2, WEE_0B3, WEE_0B4,  WEE_0B5,
							 WEE_0B6, WEE_0C,  WEE_0C2,  WEE_0D,
							 WEE_0D2, WEE_0D3, WEE_0D4,  WEE_0D5,
							 WEE_0E,  WEE_0E2, WEE_0D2S, WEE_0D3S,
							 WEE_0F,  WEE_0F2, WEE_0Di,  WEE_0B7,
							 WEE_0B8 };

		// identifies WE timing for programming
U16		we_time[MAX_DEV] = { WET_00,  WET_0AZ, WET_0A,   WET_0B,
							 WET_0B2, WET_0B3, WET_0B4,  WET_0B5,
							 WET_0B6, WET_0C,  WET_0C2,  WET_0D,
							 WET_0D2, WET_0D3, WET_0D4,  WET_0D5,
							 WET_0E,  WET_0E2, WET_0D2S, WET_0D3S,
							 WET_0F,  WET_0F2, WET_0Di,  WET_0B7,
							 WET_0B8 };

		// identifies #PGM cycles per byte for programming
U8		max_cyc[MAX_DEV] = { MAXC_00,  MAXC_0AZ, MAXC_0A,   MAXC_0B,
							 MAXC_0B2, MAXC_0B3, MAXC_0B4,  MAXC_0B5,
							 MAXC_0B6, MAXC_0C,  MAXC_0C2,  MAXC_0D,
							 MAXC_0D2, MAXC_0D3, MAXC_0D4,  MAXC_0D5,
							 MAXC_0E,  MAXC_0E2, MAXC_0D2S, MAXC_0D3S,
							 MAXC_0F,  MAXC_0F2, MAXC_0Di,  MAXC_0B7,
							 MAXC_0B8 };

		// identifies #PGM cycles per byte for programming
U8		bankshft[MAX_DEV] = {  BANK_00,  BANK_0AZ, BANK_0A, BANK_0B,
							 BANK_0B2, BANK_0B3, BANK_0B4,  BANK_0B5,
							 BANK_0B6, BANK_0C,  BANK_0C2,  BANK_0D,
							 BANK_0D2, BANK_0D3, BANK_0D4,  BANK_0D5,
							 BANK_0E,  BANK_0E2, BANK_0D2S, BANK_0D3S,
							 BANK_0F,  BANK_0F2, BANK_0Di,  BANK_0B7,
							 BANK_0B8 };

// identifies device type
U8		dtype[MAX_DEV] = {	TYPE_00,  TYPE_0AZ, TYPE_0A,   TYPE_0B,
					 	 	TYPE_0B2, TYPE_0B3, TYPE_0B4,  TYPE_0B5,
							TYPE_0B6, TYPE_0C,  TYPE_0C2,  TYPE_0D,
							TYPE_0D2, TYPE_0D3, TYPE_0D4,  TYPE_0D5,
							TYPE_0E,  TYPE_0E2, TYPE_0D2S, TYPE_0D3S,
							TYPE_0F,  TYPE_0F2, TYPE_0Di,  TYPE_0B7,
							TYPE_0B8 };

//===================================================================================================

//=============================================================================
// local registers

#define MAX_PRESP_BUF 80
char bcmd_resp_buf[MAX_PRESP_BUF + 10];
char* bcmd_resp_ptr;
U16	device_eprom_start;					// device parameter regs
U16	device_eprom_end;
U16	device_eeprom_start;
U16	device_eeprom_end;
U16	string_addr;						// string-parse next empty address
U16 sernum;								// serial number utility register
S8	device_eprom;
S8	device_eeprom;
U8	device_type;
S8	boot_len_fixed;
U16	device_max_bootlen;
U16	device_pprog;
U16	mfrdev;								// MFR/DEV code read from device (0x0000 = n/a, 0xffff = invalid)
char device_valid;
// HM-133 MFmic support
U8	hm_buf[HM_BUFF_END];				// signal buffer
U8	hm_hptr;
U8	hm_tptr;
U8	shftm;								// fn-shift mem register (MFmic)
char srbuf[STAT_BUF_LEN];				// status sending array
U8	key_count;
char key_hold;
U8	devid;								// current device ID ordinal
U32	device_maxaddr;						// device max address
U8	pgm_stat;							// pgm status
U32	step16;								// dot step value
U32	dot_cntr;							// dot counter
U8	force_pgm;							// used to force programming even if device byte = new data

//=============================================================================
// CLI cmd processor entry point
//	Somewhere in the application, there must be a constant polling for input characters or end of
//		line signal.  The goal is to produce a command line array that was terminated by an EOL
//		(ASCII 0x0d).  This array is passed through parse_args() before calling x_cmdfn().  The
//		base command line array and the args arrays are maintained elsewhere in the application
//		(usually in main.c).
//	Uses number of args (nargs) and arg pointer array (args[]) to lookup command and dispatch to
//		a command-specific code code block for execution.
//
//	offset is srecord offset value which is maintained in main() and passed
//	forward for the srecord functions (upload), if used.
//
//	Note that the original command line array is "chopped up" by parse_args() by replacing
//		whitespace characters with null-terminators (unless brackets by quotes, as described below).
//
//	"Switch" operands, such as "-C", are processed here.  These switches set flags and are then
//		removed from the parameter arrays, so that the subsequent command code doesn't have to
//		try and filter them out.  If a switch is included in a parameter field for a command that
//		does not interpret it, the switch flag is simply ignored.
//
//	get_Dargs() (get decimal args) converts ASCII numbers into integer values and is called from
//		each individual parser so that "no-parameter-entered" defaults can be established.  To
//		enforce these defaults, first initialize the params[] array with the default values, then
//		call get_Dargs().
//
//	whitespace() defines what ASCII characters are white-space parameter separators used to separate
//		parameters within the command line array.  Multiple, consecutive whitespaces are allowed and
//		are filtered out by parse_args().
//	quotespace() defines what ASCII characters are to be used as quotes inside the parameter field.
//		Quotes allow character strings which contain whitespace to be contained within a single
//		arg[] array.  Quotes effectively suspend whitespace delimiting within quote pairs.
//		The system doesn't differentiate opening or closing quotes.  As long as it is defined in
//		quotespace(), any character can be used to open and close a quoted parameter string.
//			e.g.: if a double (") and single (') quote character are defined in quotespace(),
//			any of the following are valid quoted strings:
//				"Now is the time on schprockets when we dance'
//				'No monkeys allowed!"
//				"Go for launch"
//
//	Parameter ordinal management is specified by the command-specific parser code blocks and Fns.
//		Generally, a fixed order is easiest to manage.  Non-entered values in a list of 2 or more
//		parameters are indicated by a "-" character.  Negation of decimal values must also be
//		addressed in the cmd-specific code.  Other management schemes are possible but would be
//		up to the cmd-specific code to execute.
//
//		Parametric switches ("-x" in the command line) do not have any ordinal requirements nor can
//		any be enforced under the current architecture.
//
//=============================================================================

int x_cmdfn(U8 nargs, char* args[ARG_MAX], U32* offset){

#define	OBUF_LEN 110				// buffer length
#define	MAX_LOG_ERRS (OBUF_LEN / 4)	// max number of errors logged by verify cmd
	char	obuf[OBUF_LEN];			// gp output buffer
//	char	abuf[30];				// temp string buffer
//	char	bbuf[6];				// temp string buffer
	U32		params[ARG_MAX];		// holding array for numeric params
	U8		genbuf[32];				// holding array for U8 data
	char	c;						// char temp
//	char	d;						// char temp

// NOTE: "po" (-o) not allowed as this would disable negation of octal numerics.
//		Also, "-$" and "-0" thru "-9" would disable numeric negation
volatile	char	pf = FALSE;				// F flag
volatile	char	pt = FALSE;				// T flag, minus (set if "-t" found in args)
volatile	char	ph = FALSE;				// H flag, (set if "-h" found in args)
volatile	char	ps = FALSE;				// S flag, SUB (set if "-S" found in args)
volatile	char	pc = FALSE;				// C flag (set if "-C" found in args)
volatile	char	pw = FALSE;				// W flag (set if "-W" found in args)
volatile	char	px = FALSE;				// X flag (set if "-X" found in args)
volatile	char	pv = FALSE;				// V flag (set if <wsp>-V<wsp> found in args)
volatile	char	pr = FALSE;				// R flag (set if <wsp>-R<wsp> found in args)
volatile	char	pl = FALSE;				// L flag (set if <wsp>-L<wsp> found in args)
	int		cmd_found = TRUE;		// default to true, set to false if no valid cmd identified
//	char*	q;						// char temp pointer
	char*	s;						// char temp pointer
	char*	t;						// char temp pointer
	char	cmd_id;					// command enumerated id
//	U8		g;						// temp
//	U8		h;						// temp
	U8		i;						// temp
	U8		j;						// temp
//	U8		k;						// temp
	U16		ii;						// U16 pointer
	U16		kk;
//	U16*	ip;						// U16 pointer
	U32		aa;
	U32		dd;
	U32		bb;

	U16		ia[16];					// adc test arrays
//	U32		ib[IB_MAX];

//	S32		mem_buf8[7];			// U8 mem buffer
//	U8*		ptr0;					// U8 mem pointer
//	U16		ki;						// U16 temp
//	U16		kk;						// U16 temp
//	U32		hh;						// U16 temp
//	U16		adc_buf[8];				// adc buffer
//	U16		tadc_buf[8];			// adc buffer
//	uint32_t ii;
//	uint32_t jj;
//	volatile uint32_t* pii;					// u32 pointer
//	S32		si;
//	float	fa;
//	char	gp_buf[25];				// gen-purpose buffer

#ifdef DEBUG
//	U8		m;						// temp
//	U8		dbuf[10];				// U8 disp buf
//	S8		si;						// temp s
//	S8		sj;
//	float	fb;
#endif

	force_pgm = 0;																// clear global pgm force flag
	bchar = '\0';																// clear global escape
    if (nargs > 0){
    	if((args[0][0] != '~')){
//    		for(i = 0; i <= nargs; i++){										//upcase all args !!! might just upcase command token ???
//    			s = args[i];
//    			str_toupper(s);
//    		}
    	}
		t = args[0];															// point to first arg (cmd)
		cmd_id = cmd_srch(t);													// search for command
		s = args[1];															// point to 2nd arg (1st param)
		if(*s == '?'){
			if((cmd_id == help1) || (cmd_id == help2)){
				do_help();														// set to list all cmd helps
				putsQ("");
				for(i = 0; i < lastcmd; i++){
					if(do_cmd_help(obuf, i)) putsQ("");
				}
			}else{
				do_cmd_help(obuf, cmd_id);											// do help for cmd only
			}
		}else{
			c = parm_srch(nargs, args, "-f");									// capture F floater
			if(c){
				pf = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-s");									// capture S floater
			if(c){
				ps = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-t");									// capture T floater
			if(c){
				pt = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-h");									// capture H floater
			if(c){
				ph = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-v");									// capture v-flag floater (verbose)
			if(c){
				pv = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-c");									// capture c-flag floater
			if(c){
				pc = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-w");									// capture w-flag floater
			if(c){
				pw = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-x");									// capture x-flag select floater
			if(c){
				px = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-r");									// capture x-flag select floater
			if(c){
				pr = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-l");									// capture L-flag select floater
			if(c){
				pl = TRUE;
				nargs--;
			}
			c = parm_srch(nargs, args, "-L");									// capture L-flag select floater
			if(c){
				pl = TRUE;
				nargs--;
			}
			gas_gage(2);														// init gas gauge to disabled state

// ====== PARSING SWITCH ==========================================================================================================================================

			switch(cmd_id){														// dispatch command
				case help1:
				case help2:														// MAIN HELP
					do_help();
					break;

				case help3:														// master HELP
					do_help();													// set to list all cmd helps
					putsQ("");
					for(i = 0; i < lastcmd; i++){
						if(do_cmd_help(obuf, i)) putsQ("");
					}
					break;

				case vers:														// SW VERSION CMD
					dispSWvers();
					break;

// ==  DEBUG Fns FOLLOW +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=

				case bus_cmd:													// DUT bus test cmd
					params[0] = 0x1ffffL;
					params[1] = 0L;
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					dutpwr(1);													// power on
					for(aa=0L; aa<257; aa++){
						dataio(0L, (U8)aa, 1);
						wait(1);
					}
					dutpwr(0);													// power off
					break;

//					void	smartwatch_unlock(U8 type){
//					void	smart_write(U8 d, U8 type){
//					U8	smart_read(U8 type){

				case clk_cmd:													// smartwatch clock interrogate
					// inly process if devtyp == SKT28
					if(devid == dev28_cmd){
						fast_read();											// reset smartwatch key logic
						smartwatch_unlock(0x0e);								// unlock clock
						for(i=0; i<8; i++){										// read 8 bytes
							genbuf[i] = smart_read(0x0e);
						}
						fast_read();											// reset key logic
						putsQ("Clock data:");									// display data
						for(i=0; i<8; i++){
							sprintf(obuf,"%02x ", genbuf[i]);
							putssQ(obuf);
						}
						putsQ("");
					}else{
						putsQ("Invalid Device!");								// device must be 28c64
					}
					break;

				case adc_cmd:													// process LCD bus test cmd
					do{
						dd = adc_ave(ia, 2);							// get VPP
						aa = get_vpp();		// (mV)
						sprintf(obuf,"ADC: %4d  ", dd);
						putssQ(obuf);
						sprintf(obuf,"VPP: %4d mV  ", aa);
						putssQ(obuf);
						dd = adc_ave(ia, 1);							// get VCC
						aa = get_vcc();		// (mV)
						sprintf(obuf,"ADC: %4d  ", dd);
						putssQ(obuf);
						sprintf(obuf,"VCC: %5d mV  ", aa);
						putssQ(obuf);

						sprintf(obuf,"ADC: %4d  ", (U32)*(ia+7));
						putssQ(obuf);
						aa = 1475L - (((U32)*(ia+7) * VDDA * TCK) / 40960L) + TCK2;
						sprintf(obuf,"Tj: %3d.%d C\n", aa/10, aa%10);
						putssQ(obuf);
						wait(200);
					}while(bchar != ESC);
					break;

				case vppfon_cmd:												// process VPPF test cmd
					params[0] = 0;		// +mod
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					vppf((U8)params[0]);										// vppf on/off
					adc_in(ia, 2);
					aa = ((U32)*(ia+3) * (U32)VDDA * (U32)ADCK)/40950L;		// (mV)
					sprintf(obuf,"VppF: %d mV\n", aa);
					putssQ(obuf);
					break;

				case vccon_cmd:													// DUT power on
					params[0] = 0;		// +mod
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if((devid != dev00_cmd) || (params[0] == 88)){
						dutpwr(1);												// power on (88 interlock for debug)
						putsQ("Device ON");
					}else{
						putssQ("!! No device selected !!\n");
					}
					break;

				case vccoff_cmd:												// DUT power off
					dutpwr(0);													// power off
					putsQ("Device off");
					break;

				case tvcc_cmd:
					params[0] = 0;		// vcc setting
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					switch(params[0]){
					default:
					case 0:
						i = VCC_424;
						break;

					case 1:
						i = VCC_500;
						break;

					case 2:
						i = VCC_600;
						break;

					case 3:
						i = VCC_625;
						break;

					case 4:
						i = VCC_650;
						break;
					}
					set_vcc(i);
					wait(100);
					if(check_vcc()) putsQ("Set VCC... OK");
					else putsQ("Set VCC... !ERR!");
					break;

					case tvpp_cmd:
						params[0] = 0;		// vp setting
						get_Dargs(1, nargs, args, params);						// parse param numerics into params[] array
						switch(params[0]){
						default:
						case 0:
							i = VPP_050;
							break;

						case 1:
							i = VPP_120;
							break;

						case 2:
							i = VPP_122;
							break;

						case 3:
							i = VPP_127;
							break;
						}
						set_vpp(i);
						wait(100);
						if(check_vpp()) putsQ("Set VPP... OK");
						else putsQ("Set VPP... !ERR!");
						break;

				case mem_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
					if(pt){														// write walking 1's/0's option
						// preset params
						params[0] = 0;		// pattern type: 0, 1, or 10
						params[1] = 8;		// pattern width: 8, 16, or 32
						params[2] = 0;		// addr
						params[3] = device_maxaddr; // end
						get_Dargs(1, nargs, args, params);						// parse param numerics into params[] array
						ii = 16L;												// set 8b gas-gauge step
						switch(params[1]){
						case 32:												// trap valid width values
							ii <<= 1;											// and adjust gas-gauge step at the same time
						case 16:
							ii <<= 1;
						case 8:
							step16 = (params[3]-params[2])/ii;					// dot step value
							step16 /= 2*(params[1]+1);							// final step adjust for apparent data length
							dot_cntr = 0;										// dot counter
							putssQ("[               ] PATRN");
							for(i=0; i<22; i++){
								putssQ("\b");
							}
							aa = params[2];										// set running address reg
							sram_write_start(aa);								// open SRAM write
							do{
								aa = walkabt(aa, params[3], (U8)params[0], (U8)params[1]); // write the walking bit pattern until end is reached
								if(dot_cntr++ >= step16){
									putssQ(".");
									dot_cntr = 0;
								}
							}while(aa < params[3]);
							sram_close();										// close SRAM
							pw = 0;												// disable +mode write
							putssQ("\nDONE.\n");
							break;

						default:
							putssQ("\n!! PARAM ERR - WIDTH !!\n");				// invalid width
							break;
						}
					}else{														// if walking 1/0, don't allow +mod write & don't re-parse params
						// preset params
						params[0] = 0;		// data
						params[1] = 0;		// +mod
						params[2] = 0;		// addr
						params[3] = device_maxaddr; // end
						get_Dargs(1, nargs, args, params);						// parse param numerics into params[] array
						if(!pw) pr = 1;
						step16 = (params[3]-params[2])/16L;						// dot step value
//						step16 /= 2*(params[1]+1);
						dot_cntr = 0;											// dot counter
						putssQ("[               ] FILL ");
						for(i=0; i<22; i++){
							putssQ("\b");
						}
					}
					if(params[3] < params[2]) params[3] = 1;					// len cannot = 0
					else params[3] = params[3] - params[2];						// convert "end" to "len"
					if(pw){
						// write
						aa = params[2];
						dd = params[3];
						sram_write_start(aa);									// open SRAM write
						while(dd--){
							sram_write(aa, params[0]);							// write byte
							params[0] += params[1];								// adjust write pattern
							aa += 1;											// next address
							if(dot_cntr++ >= step16){
								putssQ(".");
								dot_cntr = 0;
							}
						}
						sram_close();											// close SRAM
						putssQ("\nDONE.\n");
					}
					// read range if enabled
					if(pr){
						dump_mem(params[2],params[2]+params[3],0, obuf);	// perform memory dump to console
					}
					break;

				case fill_cmd:													// process mem fill cmd <data> <addr> <length> <+data modifier>
					params[0] = 0xFF;	// data
					params[1] = 0;		// addr
					params[2] = device_maxaddr;		// end
					params[3] = 0;		// +mod
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[2] < params[1]) params[2] = 1;					// len cannot = 0
					else params[2] = params[2] - params[1];						// convert "end" to "len"
					sprintf(obuf,"Fill SRAM. start: $%06X  end: $%06X  data: $%02X  +mod: $%02X", params[1], params[1]+params[2], params[0], params[3]);
					putsQ(obuf);
					step16 = (params[2]-params[1])/16L;							// dot step value
					dot_cntr = 0;												// dot counter
					putssQ("[               ] Fill ");
					for(i=0; i<22; i++){
						putssQ("\b");
					}
					sram_write_start(params[1]);
					while(params[2]--){
						sram_write(params[1], params[0]);
						params[0] += params[3];
						params[1] += 1;
						if(dot_cntr++ == step16){
							putssQ(".");
							dot_cntr = 0;
						}
					}
					sram_close();
					putsQ("] Done. ");
					break;

				case copy_cmd:													// process copy from DUT to SRAM
					params[0] = 0;					// addr
					params[1] = device_maxaddr;		// end
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] < params[0]) params[1] = 1;					// len cannot = 0
					else params[1] = params[1] - params[0];						// convert "end" to "len"
					sprintf(obuf,"Copy DUT to SRAM. start: $%06X  end: $%06X... ", params[0], params[0] + params[1]);
					putssQ(obuf);
					copy_dut(params[0], params[1]);								// perform copy
					putsQ("Done.");
					break;

				case mfr_cmd:
					params[0] = 0;		// force MMFR/DEV ID
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					putssQ("Read current device:  ");
					ii = read_sigdev(1);
					mfrdev = ii;
					sprintf(obuf,"\nMFR: %02X\n", ii>>8);
					putssQ(obuf);
					sprintf(obuf,"DEV: %02X\n", ii & 0xff);
					putssQ(obuf);
					if(params[0] != 0){											// if force MFR/ID
						ii = params[0];
						putssQ("\tForce MFR/DEV:\n");
						sprintf(obuf,"\n\tMFR: %02X\n", ii>>8);
						putssQ(obuf);
						sprintf(obuf,"\tDEV: %02X\n", ii & 0xff);
						putssQ(obuf);
					}
					i = srch_mfrdev(ii);
					sprintf(obuf,"Index: %2d   Device: %s\n", i, dev_list[i]);
					putssQ(obuf);
					devid = devid_list[i];
					sprintf(obuf,"DevID: %2d\n", devid);
					putssQ(obuf);
					init_dev(devid);
					break;

				case dev_cmd:
					putssQ("Current device: ");
//					putssQ(dev_list[devid]);
					sprintf(obuf, "Device = %s  Index = %d\n", dev_list[devid], devid);
					putssQ(obuf);
					sprintf(obuf, "MAX addr = $%x\n", device_maxaddr);
					putssQ(obuf);
					if(pl){
						putssQ("Device List:\n");
						for(i=0; i<=MAX_DEV; i++){
							putssQ(dev_list[i]);
							putssQ("\n");
						}
						putssQ("\n");
					}
//					sprintf(obuf, "\nEnd addr: $%x\n\n", device_maxaddr);
//					putssQ(obuf);
					break;

				case ENUM_00:
				case ENUM_0AZ:
				case ENUM_0A:
				case ENUM_0B:
				case ENUM_0B2:
				case ENUM_0B3:
				case ENUM_0B4:
				case ENUM_0B5:
				case ENUM_0B6:
				case ENUM_0C:
				case ENUM_0C2:
				case ENUM_0D:
				case ENUM_0Di:
				case ENUM_0D2:
				case ENUM_0D3:
				case ENUM_0D4:
				case ENUM_0D5:
				case ENUM_0E:
				case ENUM_0E2:
				case ENUM_0D2S:
				case ENUM_0D3S:
				case ENUM_0F:
				case ENUM_0F2:
					init_dev(cmd_id);
					sprintf(obuf, "Set device = %s  Index = %d\n", dev_list[devid], cmd_id);
					putssQ(obuf);
					sprintf(obuf, "MAX addr = $%x\n", device_maxaddr);
					putssQ(obuf);
					break;

				case maxa_cmd:													// DUT <addr> <data> <length> <+data modifier>
					params[0] = 0;					// len
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[0] !=0){
						device_maxaddr = params[0];
					}
					sprintf(obuf, "MAX addr = $%x\n", device_maxaddr);
					putssQ(obuf);
					break;

				case dump_cmd:													// DUT <addr> <length> <-s>
					params[0] = 0;					// addr
					params[1] = device_maxaddr;		// end
					params[2] = 0;					// Vcc
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					if(ps) i = 0;
					else i = 1;
					// read device
					// set device-specific signals
					set_we_dly(we_time[devid]);							// set we timing pulse
					skt(skt_list[devid]);									// socket selects (the "a" side)
					wrport_ah3(skt2_list[devid],AH3_MASK);					// .. the "b" side
					switch(params[2]){
					default:
					case 500:
						set_vcc(VCC_500);										// init VCC and VPP
						break;

					case 424:
						set_vcc(VCC_424);										// init VCC and VPP
						break;

					case 625:
						set_vcc(VCC_625);										// init VCC and VPP
						break;

					case 650:
						set_vcc(VCC_650);										// init VCC and VPP
						break;

					}
					wait(200);
					set_vcc(VCC_500);
					set_vpp(VPP_050);
					dump_mem(params[0], params[1], i, obuf);
					break;

				case sdump_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
					params[0] = 0;					// addr
					params[1] = device_maxaddr;		// end
					params[2] = 2;					// type
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] < params[0]) params[1] = params[0] + 1;					// len cannot = 0
					if((params[2] < 1) && (params[2]>2)) params[2] = 2;			// type can be 1 or 2
					// read device
					set_vcc(VCC_500);
					if(ps){
						// process sram
						sram_read_start(params[0]);								// init SRAM seq read
						process_stx(params[0], params[1], (U8)params[2], SRAM_SRC);
						sram_close();											// close SRAM
					}else{
						// process dut
						process_stx(params[0], params[1], (U8)params[2], DUT_SRC);
					}
//					dump_mem((U32)params[0],(U32)params[0]+(U32)params[1],1, obuf);
					break;

				case bla_cmd:													// erase FLASH DUT
					params[0] = 0;					// addr
					params[1] = device_maxaddr;		// end
					params[2] = 0xff;				// erase chk
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] <params[0]) params[1] = params[0]+1;			// len cannot = 0
					// check device
					i = 0;
					bb = (params[1] - params[0])/16;
					sprintf(obuf,"Blank check (0x%02X) in range 0x%06X - 0x%06X:\n", params[2], params[0], params[1]-1);
					putssQ(obuf);
					if(dtype[devid] == IS_EPROM){
						set_vcc(VCC_424);											// set low VCC
						wait(100);
						aa = blank_dut(params[0], params[1], params[2], bb, 0);		// start, end, check byte, dot step, hilo VCC
						if(aa != params[1]){
							sprintf(obuf,"!! DEVICE NOT ERASED, low-Vcc !! Error addr = $%06x\n", aa);
							i = 1;
							putssQ(obuf);
						}else{
							putssQ("\n");
						}
						set_vcc(VCC_650);											// set high VCC
						wait(100);
						aa = blank_dut(params[0], params[1], params[2], bb, 1);		// start, end, check byte, dot step, hilo VCC
						if(aa != params[1]){
							sprintf(obuf,"!! DEVICE NOT ERASED, high-Vcc !! Error addr = $%06x\n", aa);
							putssQ(obuf);
						}else{
							if(i == 0) putssQ("Device Erased!\n");
						}
						set_vcc(VCC_500);											// VCC = normal
					}else{
						set_vcc(VCC_500);											// set normal VCC
						wait(100);
						aa = blank_dut(params[0], params[1], params[2], bb, 2);		// start, end, check byte, dot step, norm VCC
						if(aa != params[1]){
							sprintf(obuf,"!! DEVICE NOT ERASED, high-Vcc !! Error addr = $%06x\n", aa);
							putssQ(obuf);
						}else{
							if(i == 0) putssQ("Device Erased!\n");
						}
						set_vcc(VCC_500);											// VCC = normal
					}
					break;

				case vfy_cmd:													// Verify DUT against SRAM
					params[0] = 0;					// addr
					params[1] = device_maxaddr;		// end
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] <params[0]) params[1] = params[0]+1;			// len cannot = 0
					// pgm device
					vfy_dut(params[0], params[1], devid);						// start, end, devid
					break;

				case era_cmd:													// erase FLASH DUT
					// erase the WHOLE bass, er, device
					era_dut(devid);												// devid
					break;

				case pgm_cmd:													// program DUT from SRAM
					params[0] = 0;					// addr
					params[1] = device_maxaddr;		// end
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] <params[0]) params[1] = params[0]+1;			// len cannot = 0
					if(pf) force_pgm = 1;										// set force pgm
					// pgm device
					pgm_dut(params[0], params[1], devid);						// start, end, devid
					break;

/*				case sload_cmd:													// program DUT from SRAM
					handshake = 1;
					params[0] = 0;		// addr offset
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					// load sram from SREC
					while(gotmsgn()){											// clear input
						getss(obuf);
					}
					putssQ("Send SREC file ");
					process_srx(PD_STOR, obuf, &params[0]);						// get and process S or I record file (dmode, strptr, offset)
					putssQ(" Done!\n");
					break;*/

				case svfy_cmd:													// verify SRAM from SREC
					params[0] = 0;		// addr offset
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					// load sram from SREC
					process_srx(PD_VRFY, obuf, &params[0]);						// get and process S or I record file (dmode, strptr, offset)
					break;

				case pt_cmd:													// pulse CS timer test command
					params[0] = 10;
					params[1] = 0;
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					sprintf(obuf,"P0: %08x   P1: %08x\n", params[0], params[1]);
					putssQ(obuf);

/* HISTORICAL REFERENCE: IN-LINE asm to enable/disable global interrupts
//					IntMasterDisable();
					// disable master ISR
					asm(
						" CPSID I\n"
						" ISB\n"
					);

					GPIO_PORTE_DATA_R &= ~CS_N;									// /CS = low
					wait_lat((U16)params[0]);									// delay
					GPIO_PORTE_DATA_R |= CS_N;									// /CS = high
//					IntMasterEnable();
					// enable master ISR
					asm(
						" CPSIE I\n"
						" ISB\n"
					);

					putssQ("CS pulse");*/
					break;

				case test_cmd:													// process sram test cmd <addr> <data> <length> <+data modifier>
					params[0] = 0;		// addr
					params[1] = 2;		// len
					params[2] = 0;		// data
					params[3] = 0;		// +mod
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(params[1] == 0) params[1] = 1;							// len cannot = 0
					sram_write_start(params[0]);
					dd = params[2];
					kk = 0;
					bb = params[0];
					do{
						i = (U8)(dd>>24);
						kk = calcrc(i, kk, XPOLY);								// update crcsum
						sram_write(bb, i);
						i = (U8)(dd>>16);
						kk = calcrc(i, kk, XPOLY);								// update crcsum
						sram_write(bb+1, i);

						i = (U8)(dd>>8);
						kk = calcrc(i, kk, XPOLY);								// update crcsum
						sram_write(bb+2, i);
						i = (U8)(dd);
						kk = calcrc(i, kk, XPOLY);								// update crcsum
						sram_write(bb+3, i);

						bb += 4;
						dd += params[3];
					}while((bb != (params[0]+params[1])) && (bchar != ESC));
					sram_close();
					// read device
					dump_mem((U32)params[0],(U32)params[0]+(U32)params[1],0, obuf);
					sprintf(obuf,"CRC16: $%04x (written)\n", kk);
					putssQ(obuf);
					break;

				case dvt_cmd:													// process DVT cmd
					putssQ("VPP_A18 DVT (<ESC> to abort)...");
					vpp(VPP_120);
					vcc(VCC_650);
					wrport_ah3(0, VPP_OE);
					do{
						wait_lat(50);											//										{{ measured pulse = 54 us
						GPIO_PORTE_DATA_R &= ~OE_N;								// OE=VPP=off
						wait(1);												// start cyc with both off
						GPIO_PORTE_DATA_R |= OE_N;								// OE=on
						wait_lat(10);											// 										{{ measured pulse = 10.8 us
						GPIO_PORTE_DATA_R &= ~OE_N;								// OE=off
						// disable master ISR
						asm(
							" CPSID I\n"
							" ISB\n"
						);
						wrport_ah3(VPP_OE, VPP_OE);								// VPP = on								{{ measured pulse = 3.5 us
//						wait_lat(10);											// 10us between stages
//						GPIO_PORTE_DATA_R |= OE_N;								// OE=on
						wait_lat(92);											// 10us between stages					{{ measured pulse = 320 us
						wrport_ah3(0, VPP_OE);
						// enable master ISR									//										{{ need about 10us for voltages to settle
						asm(
							" CPSIE I\n"
							" ISB\n"
						);

/*						wrport_ahh(0, A18);										// A18 = VPP18 = off
						wrport_ah3(0, VPP_OE);
						wait(1);												// start cyc with both off
						wrport_ahh(A18, A18);									// A18 = 1
						wait_lat(10);
						wrport_ahh(0, A18);										// A18 = 0
						wrport_ah3(VPP_OE, VPP_OE);							// VPP18 = on
						wait_lat(10);											// 10us between stages
						wrport_ahh(A18, A18);									// A18 = on
						wait(10);
//						wait_lat(10);*/
					}while(bchar != ESC);
					vpp(VPP_050);
					vcc(VCC_424);
					putsQ("Done.");
					break;

				case upl_cmd:													// UPLOAD from serial console CMD
					params[0] = 0;		// addr offset
					get_Dargs(1, nargs, args, params);							// parse param numerics into params[] array
					if(*s == 'R'){												// if 1st param is "R",
						putsQ("Upload Response:");								// display last bcmd responses (if any)
						putsQ(bcmd_resp_buf);
					}else{
						exec_bcmd("z",obuf, offset);							// init bcmd processor
						bcmd_resp_ptr = bcmd_resp_buf;							// init bcmd response buffer
						*bcmd_resp_ptr = '\0';
						if(pv){													// process verify modifier
							j = PD_VRFY;
							putssQ("Verify");
							exec_bcmd("x",obuf, offset);						// disable bcmd processor
						}else{													// not verify, do transfer
							j = PD_STOR;
							putssQ("Send");
						}
						if(px){													// xmodem xfr prompt...
							handshake = 0;
							putsQ(" xmodem host->pgmr. Waiting for xmodem start...");
							process_xrx(RX_STATE_INIT);							// init xmodem rcv
							process_srx(j, obuf, &params[0]);					// ascii srecord receive
							do{
								i = process_xrx(RX_STATE_PROC);
								if(i == XMOD_DR) process_xrx(RX_STATE_PACK);
							}while((i != XMOD_DONE) && (i != XMOD_ABORT) && (i != XMOD_ERR));
							process_xrx(RX_STATE_CLEAR);						// close xmodem xfr
							wait(200);
							disp_crc(obuf);
						}else{
							while(gotmsgn()){
								getss(obuf);
							}
							putsQ(" ascii host->pgmr. Waiting for Srecs...");
							handshake = TRUE;
							process_srx(j, obuf, &params[0]);					// ascii srecord receive
							handshake = FALSE;
						}
						wait(500);
						putssQ("\nUpload ");
						if(process_data(0, 0, PD_QERY) != PD_OK){
							aa = process_data(0, 0, PD_QERYH);
							sprintf(obuf,"fail, addr: %06x",aa);
							putsQ(obuf);
						}else{
							putsQ("OK.");
						}
						if(bcmd_resp_ptr != bcmd_resp_buf){
							putsQ("Response:");									// display bcmd responses (if any)
							putsQ(bcmd_resp_buf);
						}
					}
					break;

				default:
				case lastcmd:													// not valid cmd
					cmd_found = FALSE;
					break;

			} //=========== END PARSING SWITCH ======================================================================================
		}
    }
	set_we(we_list[devid]);
	if(bchar == ESC) while(gotchrQ()) getchrQ();									// if ESC, clear CLI input chrs
	return cmd_found;
}

//=============================================================================
// putOK() displays OK status response if true, else err
//=============================================================================
void putOK(U8 tf){

	if(tf){
		putsQ("#-OK$");
	}else{
		putsQ("#-ERR$");
	}
	return;
}

//=============================================================================
// do_help() displays main help screen
//=============================================================================
void do_help(void){
		//          1         2         3         4         5         6         7         8
		// 12345678901234567890123456789012345678901234567890123456789012345678901234567890
	putsQ("FFPGMR, MK-II CMD List:");
	putsQ("Syntax: <cmd> <arg1> <arg2> ... args are optional depending on cmd.");
	putsQ("CMDs are case sensitive.  <arg> order is critical except for floaters.");
	putsQ("\"?\" as first <arg> gives cmd help,  \"??\" lists cmd help for all cmds.");

	putsQ("\nWhen selectively entering <args>, use \"-\" (with whitespace on either side)");
	putsQ("for <args> that keep default value.  \"$\" must precede HEX values w/o spaces.");
	putsQ("negation of numeric <args> when \"-\" immediately precedes value w/o spaces.");
	putsQ("e.g.: -100 -$100 -o73");

	putsQ("\nFloating <args>: these non-number <args> can appear anywhere in <arg>");
	putsQ("list: \"-w\" = write, \"-s\" = sram, \"-l\" or \"-L\" = List trigger");

	putsQ("\nThis programmer uses a serial SRAM to hold data to be programmed into the DUT.");
	putsQ("DUT Uploads pull directly from the DUT (SRAM is not affected except for \"copy\" cmd).");
	putsQ("Command sequence:");
	putsQ("\tSelect device & erase (if FLASH)");
	putsQ("\tBlank check (opt)");
	putsQ("\tUpload object data");
	putsQ("\tPGM/VFY");
	putsQ("\tTurn off power to DUT & remove from socket\n");
}

//=============================================================================
// do_cmd_help() displays individual cmd help using cmd_id enum
//=============================================================================
char do_cmd_help(char* obuf, U8 cmd_id){
	char 	c = TRUE;	// temps
//	U16		k;
//	U8		i;
//	char	hbuf[10];

	switch(cmd_id){														// dispatch help line
		case bus_cmd:
			putsQ("bu");
			putsQ("\tdebug: DUT bus test");
			break;

		case adc_cmd:													// process LCD bus test cmd
			putsQ("\nad");
			putsQ("\tdebug: ADC read (ESC to exit)");
			break;

		case vccon_cmd:													// process LCD bus test cmd
			putsQ("on");
			putsQ("\tDUT power ON");
			break;

		case vccoff_cmd:													// process LCD bus test cmd
			putsQ("off");
			putsQ("\tDUT power off");
			break;

		case mem_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
			putsQ("mt <-w> <data> <+mod> <srt> <end> <-r>");
			putsQ("\tSRAM mem test, \"-w\" to write, else read in hex dump format");
			putsQ("\t\"-r\" does read dump after memory fill");
			putsQ("mt <-t> <type> <width> <srt> <end> <-r>");
			putsQ("\tSRAM mem test, \"-t\" does walking 1's or 0's test");
			putsQ("\ttype = '1's, '0's, or '10' both");
			putsQ("\twidth = 8, 16, or 32 bits");
			putsQ("\tDefaults: <data> = 0, <+mod> = 0, <srt> = 0, <end> = max dev addr+1");
			putsQ("\t\t<type> = 0, <width> = 8");
			break;

		case fill_cmd:													// process mem test cmd <addr> <data> <length> <+data modifier>
			putsQ("fill <data> <srt> <end> <+mod>");
			putsQ("\tSRAM mem fill (byte), default data is 0xFF, <+mod> adds to previous location value");
			break;

		case dev_cmd:
			putssQ("dev <-L>\n");
			putssQ("\tDisplay current device or list devices <-L> (upper or lower case 'L' allowed)\n");
/*			putssQ("Device List:\n");
			for(i=0; i<=MAX_DEV; i++){
				putssQ(dev_list[i]);
				putssQ("\n");
			}
			putssQ("\n");*/
			break;

		case ENUM_0AZ:
		case ENUM_0A:
		case ENUM_0B:
		case ENUM_0B2:
		case ENUM_0B3:
		case ENUM_0B4:
		case ENUM_0B5:
		case ENUM_0B6:
		case ENUM_0C:
		case ENUM_0C2:
		case ENUM_0D:
		case ENUM_0Di:
		case ENUM_0D2:
		case ENUM_0D3:
		case ENUM_0D4:
		case ENUM_0D5:
		case ENUM_0E:
		case ENUM_0E2:
		case ENUM_0D2S:
		case ENUM_0D3S:
		case ENUM_0F:
		case ENUM_0F2:
			sprintf(obuf,"Set device =  %s", dev_list[cmd_id]);
			putssQ(obuf);
			break;

		case dump_cmd:													// Dump DUT mem <start> <end> <-s> specifies SRAM
			putsQ("dump <srt> <end> <vcc> <-s>");
			putsQ("\tDUT hex dump (SRAM if '-s' switch)");
			putsQ("\tDefaults: <srt> = 0, <end> = max dev addr+1, <vcc> = 500");
			putsQ("\t<vcc> = 424, 500, 625, or 650");
			break;

		case sdump_cmd:													// process sdump cmd <start> <end> <type> -s
			putsQ("sdump <srt> <end> <type> <-s>");
			putsQ("\tDUT SREC dump; <type> = 1, S19; <type> = 2, S28; -s send from SRAM");
			putsQ("\tDefaults: <srt> = 0, <end> = max dev addr+1, <type> = S28");
			break;

		case test_cmd:													// process sram pattern test cmd <addr> <data> <length> <+data modifier>
			putsQ("te <srt> <len>");
			putsQ("\tSRAM pattern test");
			break;

		case era_cmd:													// erase FLASH DUT
			putsQ("era");
			putsQ("\tErase FLASH/EEPROM");
			break;

		case pgm_cmd:													// program DUT from SRAM
			putsQ("pgm <srt> <end>");
			putsQ("\tPGM FLASH/EEPROM");
			putsQ("\tDefaults: <srt> = 0, <end> = max dev addr+1");
			break;

		case upl_cmd:													// program DUT from SRAM
			putsQ("upl <offs> -x");
			putsQ("\tSREC load from host (via UART)");
			putsQ("\tDefaults: <offs> = 0");
			putsQ("\t<-x> sets xmodem transfer. ASCII transfers need 20ms of line delay with xon/xoff.");
			putsQ("\t<offs> is subtracted from incoming address, defaults to 0.");
			putsQ("\t'S0-xxxxxx' embeded in SRECORD file will also set <offset> to hex addr 'xxxxxx'");
			putsQ("\t'S0b sets bank 'b' (hex) for banked DUTs");
			break;

		case copy_cmd:													// copy DUT to SRAM
			putsQ("copy <srt> <end>");
			putsQ("\tCopy DUT to SRAM ");
			putsQ("\tDefaults: <srt> = 0, <end> = max dev addr+1");
			break;

		case mfr_cmd:													// read MFR/DEV from DUT
			putsQ("mfr <devid>");
			putsQ("\tRead intelligent ID and set device if valid");
			putsQ("\t<devid> forces device setting to specified ID code");
			break;

		case vfy_cmd:													// verify DUT from SRAM
			putsQ("vfy <srt> <end>");
			putsQ("\tVerify DUT against SRAM");
			putsQ("\tDefaults: <srt> = 0, <end> = max dev addr+1");
			break;

		case svfy_cmd:													// verify DUT from SRAM
			putsQ("svfy <offs>");
			putsQ("\tSREC verify against SRAM");
			putsQ("\t<offs> is subtracted from incoming address, defaults to 0");
			break;

		case bla_cmd:													// blank-check DUT
			putsQ("bla <srt> <end> <blank_data>");
			putsQ("\tBlank check DUT");
			putsQ("\tDefaults: <srt> = 0, <end> = max dev addr+1, <blank_data> = $FF");
			break;

		case maxa_cmd:													// max device address
			putsQ("max <len>");
			putsQ("\tSet device size in bytes");
			putsQ("\tDefault: <len> = max dev addr+1");
			break;

		default:
			c = FALSE;
			break;
	}
	return c;
}
/*
//=============================================================================
// disp_error() displays standard error messages & device off status
//=============================================================================
void disp_error(U8 errnum){

	do_red_led(LED_BLINK);
	switch(errnum){
		case no_response:
			putsQ("!! ERR !! No response from DUT.");
			break;

		case no_device:
			putsQ("!! ERR !! No DUT selected.");
			break;

		case target_timeout:
			putsQ("!! ERR !! DUT timeout.");
			break;

		default:
			break;
	}
	if(!dut_pwr(TARGET_STAT)) putsQ("DEVICE OFF");		// signal device off
}*/
/*
//=============================================================================
// disp_fail() displays pgm/read error message with params
//	this is a debug function that displays the HC11 fn comms status
//	Also, this fn sets the status LED to blink to indicate a failure was encountered
//=============================================================================
void disp_fail(char* buf, char* s, U16 c, U16 d){

	do_red_led(LED_BLINK);
	sprintf(buf,"%s Failed!! errs: %02x %02x", s, (U16)c, (U16)d);
	putsQ(buf);
}*/

//=============================================================================
// is_banked() returns true if dev_id is banked
//=============================================================================
U8 is_banked(U8 dev_id){

	return bankshft[dev_id];
}
//=============================================================================
// vpp_bit() returns vpp bit map for bank-switched devices
//=============================================================================
U8 vpp_bit(void){

	if(devid == ENUM_0C) return VPPCB_0C;
	if(devid == ENUM_0C2) return VPPCB_0C2;
	return 0;
}

//=============================================================================
// disp_wait_addr() dead code
//=============================================================================
void disp_wait_addr(char* buf){

	sprintf(buf,"disp_wait_addr = dead code\n");
	putsQ(buf);
	return;
}

//=============================================================================
// exec_bcmd() dead code
//=============================================================================
void exec_bcmd(char* bcmdbuf_ptr, char* obuf, U32* offset){

}

//***********************//
// bcmd functions follow //
//***********************//

//******************************//
// hosekeeping functions follow //
//******************************//

void	set_fla(U32 maxad, char* bbuf){

	device_maxaddr = maxad;
	set_dev(DEVRST);												// reset addr/dev variables
	set_dev(0x00);													// clear mask for A[18:16]
	vpp(VPP_050);
	vppf(0);
	skt(CLR_WE_A14|CLR_VPPA15);
	skt(SET_VPPA15);
	dutpwr(1);
	vppf(1);
	wait(50);
	// read & display dev/mfg
	fast_write(RST_101);
	fast_write(RST_101);
	wait(50);
	fast_write(DEV_101);
	sprintf(bbuf,"DEV ID/MFR: %02x  %02x\n", dataio(0L, 0, RD), dataio(1L, 0, RD));
	putssQ(bbuf);
	fast_write(RD_101);
	vppf(0);
	sprintf(bbuf, "MAX addr = $%x\n", device_maxaddr);
	putssQ(bbuf);
	return;
}

//===============================================================================
// init_dev() initializes device I/O
//===============================================================================
void init_dev(U8 dev_id){

	switch(dev_id){
	default:
	case ENUM_00:
		set_dev(DEVRST);												// reset addr/dev variables
		set_dev(0x00);													// clear mask for A[18:16]
		devid = 0;
		vcc(VCC_500);
		vpp(VPP_050);
		vppf(0);
		skt(CLR_WE_A14|CLR_VPPA15);
		wrport_ah3(0, AH3_MASK);
		device_maxaddr = 0L;
		dutpwr(0);
		putsQ("No device found");
		break;

	case ENUM_0AZ:
	case ENUM_0A:
	case ENUM_0B:
	case ENUM_0B2:
	case ENUM_0B3:
	case ENUM_0B4:
	case ENUM_0B5:
	case ENUM_0B6:
	case ENUM_0B7:
	case ENUM_0B8:
	case ENUM_0C:
	case ENUM_0C2:
	case ENUM_0D:
	case ENUM_0Di:
	case ENUM_0D2:
	case ENUM_0D3:
	case ENUM_0D4:
	case ENUM_0D5:
	case ENUM_0E:
	case ENUM_0E2:
	case ENUM_0D2S:
	case ENUM_0D3S:
	case ENUM_0F:
	case ENUM_0F2:
		put_addr(0);													// init control sigs
		fast_read();
		set_dev(DEVRST);												// reset addr/dev variables
		set_dev(dev_id);												// clear mask for A[18:16]
		devid = dev_id;
		vcc(VCC_500);
		vpp(VPP_050);
		if(dev_id == ENUM_0AZ) vppf(1);
		else vppf(0);
		skt(skt_list[dev_id]);
		wrport_ah3(skt2_list[dev_id], AH3_MASK);
		device_maxaddr = maxaddr_list[dev_id];
		dutpwr(1);
		break;
	}
}

//===============================================================================
// read_sidev() manipulates the DUT to read the MFR/DEV codes by setting
//	A9 = VIHH (12V).  Does parity check on MFR code and rejects if parity incorrect
//	(should be odd).
//	Returns U16 with MFR code in MSB and DEV code in LSB
//===============================================================================
U16	read_sigdev(U8 verb){
	U8	i;		// temps
	U8	j;

	GPIO_PORTE_DATA_R = PORTE_INIT;									// port E = IPL value
	set_we(WE_N);													// set DUT WE port pin (no programming here, only WE will be for banked EPROMS)
	put_dot('/', verb);												// status dot
	dutpwr(0);														// Ensure DUT off
	wait(200);
	set_addr();														// force new address session
	vpp(VPP_050);													// VPP = 5V (failsafe, no VPP activity here)
	put_dot('|', verb);												// status dot
	vppf(0);														// ensure VPPF is off
	put_dot('\\', verb);											// status dot
	skt(CLR_WE_A14|CLR_VPPA15);										// Connect all addresses to DUT
	wrport_ah3(VCC_A17, 0xff);										// set AH3 port for universal VCC (32/28 pin)
	vcc(VCC_500);													// VCC = 5V for this operation
	fast_write(0);													// ensure /WE is idle
	put_dot('-', verb);												// status dot
	dutpwr(1);														// DUT on
	wait(100);
	put_dot('/', verb);												// status dot
	vppf(1);														// set DUT Vh = 12V (this is all we use VPPF for)
	wait(100);
	wrport_ah3(ID9, 0);												// set AH3 port to set ID/A9 a=switch = VPPF
	put_dot('*', verb);												// status dot
	//
	// We have to try a few configurations to accomodate all of the different device requirements.
	// Note: MFR device codes are 7 bits with odd parity (msb).  An invalid MFR has even parity.
	//
	put_addr(0x64000L);												// A15 = low for a few ms (bank EPROM reset)
	wait(10);
	i = fast_read();												// dummy read to init /CS/OE/WE
	wait(10);
	put_addr(0x64001L);
	j = fast_read();												// j = DEV
	put_addr(0x64000L);
	i = fast_read();												// i = MFR
	if(!is_odd_parity(i) || (j == 0xff) || (j == 0x00)){
		put_addr(0x6C001L);											// re-read with a{13:0] = 0 , a[15:14] = 1
		wait(10);
		i = fast_read();											// dummy read
		j = fast_read();											// j = DEV
		put_addr(0x6C000L);
		i = fast_read();											// i = MFR
	}
	if(!is_odd_parity(i) || (j == 0xff) || (j == 0x00)){
		wait(100);
		put_dot('2', verb);											// status
		put_addr(0x00001L);											// re-read with all addr = 0
		j = fast_read();											// j = DEV
		put_addr(0x00000L);
		i = fast_read();											// i = MFR
	}
	if(!is_odd_parity(i) || (j == 0xff) || (j == 0x00)){
		wait(100);
		put_dot('3', verb);											// status
		skt(SET_WE_A14);
		wrport_ah3(0, VCC_A17|VPP_A15EE);
		wait(1);
		put_addr(0x00001L);
		j = fast_read();											// j = DEV
		put_addr(0x00000L);
		i = fast_read();											// i = MFR
	}
	if(!is_odd_parity(i) || (j == 0xff) || (j == 0x00)){
		wait(100);
		put_dot('4', verb);											// status
		skt(CLR_WE_A14);
		put_addr(0x00001L);											// re-read with all addr = 0
		j = fast_read();											// j = dummy read
		j = fast_read();											// j = DEV
		put_addr(0x00000L);
		i = fast_read();											// i = MFR
	}
	vppf(0);														// Vh = 5V
	wrport_ah3(0, ID9);												// clear AH3 port for ID/A9 switch = A9
	wait(100);
	dutpwr(0);														// DUT off
	wait(200);
	put_dot(' ', verb);												// last status
	return ((U16)i << 8) | (U16)j;									// return result
}

//===============================================================================
// is_odd_parity() returns true if parity of data is odd
//===============================================================================
U8 is_odd_parity(U8 data){
	U8	i;
	U8	k;
							// this version takes 480ns, 1/5 as long as the for-loop bit counter version
	i = data>>1;			// each shift & EOR operation determines parity of adjacent bits
	i ^= data;				// as the algorithm progresses, the determining bits progress towards the LSB
	k = i>>2;				// all intermediate bits are ignored.
	i ^= k;
	k = i>>4;
	i ^= k;
	return (i&1);			// at the end, the lsb is 1 if parity is
							// Note that the shifts go up by a power of two, so the next step (for a 16b parity calculation)
							// would shift right 8x.  For 32b, the one after that would shift
}

//===============================================================================
// put_dot() displays a status dot if verb(ose) == true
//===============================================================================
void put_dot(char dot, U8 verb){

	if(verb){
		putcharQ('\b');		// backup...
		putcharQ(dot);		// status
	}
	return;
}
/*
U16*						 devid_ptr[] = { SIGID_00, SIGID_0A, SIGID_0B, SIGID_0B3, SIGID_0B2,
											 SIGID_0B4, SIGID_0B5, SIGID_0B6, SIGID_0C,
											 SIGID_0C2, SIGID_0D, SIGID_0D2, SIGID_0D3,
											 SIGID_0D4, SIGID_0D5, 0xffff };
*/

//===============================================================================
// srch_mfrdev() searches the dev_ptr list to see if the MFR/DEV id is present.
//	returns the device index if found (index == 0 is not found semaphore)
//===============================================================================
U8 srch_mfrdev(U16 mfrdev){
	U8		i = 0;		// temps
	U8		j = 1;
	U16*	ptr;

	while((*devid_ptr[i] != 0xffff) && (j)){
		ptr = devid_ptr[i];
		while(*ptr != 0){
			if(*ptr++ == mfrdev) j = 0;
		}
		if(j) i += 1;
	}
	if(j) i = 0;
	return i;
}

//=============================================================================
// pgm_dut() dispatches to the device algorithm passed.
//	data is pulled from the SRAM
//=============================================================================
void	pgm_dut(U32 srt, U32 end, U8 dev_id){
	U32	addr = srt;
//	U32	ii;
	U8	d;
	U8	i;
	volatile	U8	e;
#define	LOOP_MAX	10

	step16 = (end-srt)/16L;									// dot step value
	dot_cntr = 0;											// dot counter
	set_addr();
	pgm_stat = 0;											// pre-clear status
	sram_read_start(srt);									// init SRAM seq read
	putssQ("[               ] PGM  ");
	for(d=0; d<22; d++){
		putssQ("\b");
	}
	// set device-specific signals
	set_we_dly(we_time[dev_id]);							// set we timing pulse
	skt(skt_list[dev_id]);									// socket selects (the "a" side)
	wrport_ah3(skt2_list[dev_id],AH3_MASK);					// .. the "b" side
	set_vcc(vcc_list[dev_id]);								// init VCC and VPP
	set_vpp(vpp_list[dev_id]);
	switch(dev_id){
	default:
		putsQ("!! PGM ALGORITHM NOT SUPPORTED !!");
		break;

	case dev28_cmd:		// 28C64
	case dev28z_cmd:	// 28C64 A9ID space
		while((addr < end) && (bchar != ESC)){
			d = sram_read(addr);
			dataio(addr++, d, WR);
			if(dot_cntr++ >= step16){
				putssQ(".");
				dot_cntr = 0;
			}
			i = 0;
			do{
				wait_lat(DLY_01MS);
			}while((i++<LOOP_MAX) && (d != fast_read()) && (bchar != ESC));
			if(i>=LOOP_MAX) pgm_stat |= PGM_ERR;
		}
		break;

	// EPROM Algorithms (non-bank-switched
	case devEPB1_cmd:	// 27c011
	case devEPB2_cmd:	// 27c513

	case devEP1_cmd:	// 27c010
	case devEP1i_cmd:	// 27c010i
	case devEP2_cmd:	// 27c512
	case devEP3_cmd:	// 27c256
	case devEP4_cmd:	// 27c020
	case devEP5_cmd:	// 27c040
	case devEP2S_cmd:	// 27c512s
	case devEP3S_cmd:	// 27c256s
	case dev2764_cmd:	// 27Cc64
	case dev2764s_cmd:	// 27Cc64s
		pgm_ep(srt, end, dev_id);
		break;

	case devFL8_cmd:	// 28F020a
		vpp(vpp_list[dev_id]);										// turn off FLASH Vpp (failsafe)
		// write array from sram
		do{
			d = sram_read(addr);
			if(d != 0xff){
				i=0;
				put_addr(addr);								// set address
				e = fast_pgm_vfy_020(d);
				if(e != d){
					pgm_stat |= PGM_ERR;
				}
			}
			if(dot_cntr++ == step16){
				putssQ(".");
				dot_cntr = 0;
			}
		}while((++addr < end) && !(pgm_stat & PGM_ERR));
		fast_write(RD_101);
		vpp(VPP_050);										// turn off FLASH Vpp
		putssQ("] ");
		break;

	case devFL7_cmd:	// 29F010
	case devFL6_cmd:	// 29F040
		vpp(VPP_050);										// turn off FLASH Vpp (failsafe)
		// write array from sram
		do{
			d = sram_read(addr);
			if(d != 0xff){
				i=0;
//				put_addr(addr);								// set address
				e = fast_pgm_vfy_040(addr, d);
				if(e != d){
					pgm_stat |= PGM_ERR;
				}
			}
			if(dot_cntr++ == step16){
				putssQ(".");
				dot_cntr = 0;
			}
		}while((++addr < end) && !(pgm_stat & PGM_ERR));
		fast_write(RD_101);
//		vpp(VPP_050);										// turn off FLASH Vpp
		putssQ("] ");
		break;

	case devFL1_cmd:	// 28F101
	case devFL2_cmd:	// 28F512
	case devFL3_cmd:	// 28F256
	case devFL4_cmd:	// 28F010
	case devFL5_cmd:	// 28F020
		// erase the entire array to device_maxaddr
		vpp(VPP_120);										// turn on FLASH Vpp
		dot_cntr = 0;
		// write array from sram
		do{
			d = sram_read(addr);
			if(d != 0xff){
				i=0;
				put_addr(addr);								// set address
				do{
					e = fast_pgm_vfy(d);
				}while((++i<25) && (e != d));
				if(i>=25){
					pgm_stat |= PGM_ERR;
				}
			}
			if(dot_cntr++ == step16){
				putssQ(".");
				dot_cntr = 0;
			}
		}while((++addr < end) && !(pgm_stat & PGM_ERR));
		fast_write(RD_101);
		vpp(VPP_050);										// turn off FLASH Vpp
		putssQ("] ");
		break;
	}
	sram_close();											// close SRAM
	// Display results
	if(pgm_stat & PGM_ERR){
		putssQ("!! PGM ERROR !!\n");
	}
	if(pgm_stat & VFY_ERR){
		putssQ("!! High-VCC VFY ERROR !!\n");
	}
	if(pgm_stat & VFY2_ERR){
		putssQ("!! Low-VCC VFY ERROR !!\n");
	}
	if(!pgm_stat){
		putssQ("PGM OK!\n");
	}
	GPIO_PORTE_DATA_R |= OE_N|WE_N|CS_N|WEDAT_N;			// failsafe the DUT control lines for idle
	return;
}

//=============================================================================
// pgm_ep() processes EPROM algorithm
//	data is pulled from the SRAM (the sram_open Fn is called prior to this Fn call)
//=============================================================================
void	pgm_ep(U32 srt, U32 end, U8 dev_id){
	U32	addr = srt;
//	U32	ii;
	U8	d;
	U8	i;
	volatile	U8	e;
	U8	maxc = max_cyc[dev_id];								// holding reg for max# pgm cycles

	wait(50);
	// PGM cycle
	while((addr < end) && (bchar != ESC) && !(pgm_stat & ~DBG_ERR)){
		d = sram_read(addr);
		i = 0;
		put_addr(addr);										// set address
		e = fast_read();									// read existing data
		if(force_pgm) e = ~d;								// force pgm even if DUT data == SRAM data
		if(e!=d){
			do{
				if(e != d) e = datapv(addr, d, we_list[dev_id]);	// main pgm loop
			}while((++i<maxc) && (d != e));
			if((i>=maxc) && (maxc > 1)){
				pgm_stat |= DBG_ERR; //PGM_ERR;						// set error status
			}else{
				//test for type B
/*				if(typeb){
					datapv(addr, d, we_list[dev_id]);
					datapv(addr, d, we_list[dev_id]);
					datapv(addr, d, we_list[dev_id]);
				}*/
			}
		}
		addr++;
		if(dot_cntr++ >= step16){
			putssQ(".");
			dot_cntr = 0;
		}
	}
	sram_close();											// close SRAM


/*
	// PGM cycle
	while((addr < end) && (bchar != ESC) && !pgm_stat){
		d = sram_read(addr);
		i = 0;
		put_addr(addr);										// set address
		do{
			e = ~fast_read();								// pre-read
			if(e != d) e = datapv(addr, d, we_list[dev_id]);	// main pgm loop

//			e = datapv(addr, d, vppc_list[dev_id]);
		}while((++i<maxc) && (d != e));
		if((i>=maxc) && (maxc > 1)) pgm_stat |= PGM_ERR;	// set error status
		if(dot_cntr++ >= step16){
			putssQ(".");
			dot_cntr = 0;
		}
		addr++;
	}
	sram_close();											// close SRAM


	if(!pgm_stat){											// if PGM error, skip verify
		// PGM/VFY cycle
		addr = srt;
		putssQ("] PVFY ");
		for(d=0; d<22; d++){								// re-cycle gas-guage
			putssQ("\b");
		}
		dot_cntr = 0;
		sram_read_start(srt);								// init SRAM seq read
		while((addr < end) && (bchar != ESC)){
			d = sram_read(addr);
			put_addr(addr);									// set address
			e = fast_read();								// read location to verify
//			if(e != d) datapv(addr, d, we_list[dev_id]);	// verify fail, one last pgm
			datapv(addr, d, we_list[dev_id]);	// verify fail, one last pgm
			addr++;
			if(dot_cntr++ >= step16){
				putssQ("-");
				dot_cntr = 0;
			}
		}
*/
//		sram_close();										// close SRAM
		// VFY 1 cycle
		addr = srt;
		putssQ("] HiVFY");
		for(d=0; d<22; d++){								// re-cycle gas-guage
			putssQ("\b");
		}
		dot_cntr = 0;
		set_vpp(VPP_050);
		wait(100);
		sram_read_start(srt);								// init SRAM seq read
		while((addr < end) && (bchar != ESC)){
			d = sram_read(addr);
			put_addr(addr);									// set address
			e = fast_read();
			if(e != d) pgm_stat |= VFY_ERR;					// verify error
			addr++;
			if(dot_cntr++ >= step16){
				putssQ("|");
				dot_cntr = 0;
			}
		}
		sram_close();										// close SRAM
		// VFY 2 cycle
		addr = srt;
		putssQ("] LoVFY");
		for(d=0; d<22; d++){								// re-cycle gas-guage
			putssQ("\b");
		}
		dot_cntr = 0;
		set_vcc(VCC_424);
		wait(100);
		sram_read_start(srt);								// init SRAM seq read
		while((addr < end) && (bchar != ESC)){
			d = sram_read(addr);
			put_addr(addr);									// set address
			e = fast_read();
			if(e != d) pgm_stat |= VFY2_ERR;				// verify 2 error
			addr++;
			if(dot_cntr++ >= step16){
				putssQ("*");
				dot_cntr = 0;
			}
		}
		sram_close();										// close SRAM

	putsQ("] Done! ");
	set_vcc(VCC_500);
	set_vpp(VPP_050);
	return;
}

//=============================================================================
// era_dut() dispatches to the device algorithm passed.
//=============================================================================
void	era_dut(U8 dev_id){

	pgm_stat = 0;											// pre-clear status
	switch(dev_id){
	default:
		putsQ("!! DEVICE ERROR !!");
		break;

	case dev28_cmd:		// 28C64
		vppoe_wr(DLY_10MS);									// send erase pulse to DUT
		putssQ("Done!\n");
		break;

	case devFL7_cmd:	// 29F010
	case devFL6_cmd:	// 29F040
		vpp(VPP_050);
		vppf(0);
		vcc(VCC_500);
		putssQ("Chip Erase: ");
		wait(20);											// wait for serial string to clear the queue...
		if(fast_era_040() == 0xff){
			putcharQ('\b');		// backup...
			putssQ(" Done!\n");
		}else{
			putcharQ('\b');		// backup...
			putsQ(" !! ERASE ERROR !!");
		}
		break;

	case devFL8_cmd:	// 28F020a
		vpp(vpp_list[dev_id]);
		vppf(0);
		vcc(VCC_500);
		putssQ("Chip Erase: ");
		wait(20);											// wait for serial string to clear the queue...
		if(fast_era_020() == 0xff){
			putcharQ('\b');		// backup...
			putssQ(" Done!\n");
		}else{
			putcharQ('\b');		// backup...
			putsQ(" !! ERASE ERROR !!");
		}
		break;

	case devFL1_cmd:	// 28F101
	case devFL2_cmd:	// 28F512
	case devFL3_cmd:	// 28F256
	case devFL4_cmd:	// 28F010
	case devFL5_cmd:	// 28F020
		// erase the entire array to device_maxaddr
		vpp(VPP_120);
		era_fla((device_maxaddr)>>4);
		vppf(0);
		if(pgm_stat & ERA_ERR){
			putsQ("!! ERASE ERROR1 !!");
		}
		if(pgm_stat & PGM_ERR){
			putsQ("!! ERASE ERROR0 !!");
		}
		if(pgm_stat & ESC_ERR){
			putsQ("!! ABORT ERROR !!");
		}
		if(!pgm_stat){
			putssQ("Done!\n");
		}
		vpp(VPP_050);
		break;
	}
	return;
}

//=============================================================================
// vfy_dut() dispatches to the device algorithm passed.
//=============================================================================
void	vfy_dut(U32 srt, U32 end, U8 dev_id){
	U32	ea = 0xFFFFFFFFL;
	char	ebuf[10];

	pgm_stat = 0;											// pre-clear status
	sram_read_start(srt);									// init SRAM seq read
	switch(dev_id){
	default:
		putsQ("!! DEVICE ERROR !!");
		break;

	case devEPB1_cmd:	// 27c011
	case devEPB2_cmd:	// 27c513

	case devEP1_cmd:	// 27c010
	case devEP1i_cmd:	// 27c010i
	case devEP2_cmd:	// 27c512
	case devEP3_cmd:	// 27c256
	case devEP4_cmd:	// 27c020
	case devEP5_cmd:	// 27c040
	case devEP2S_cmd:	// 27c512s
	case devEP3S_cmd:	// 27c256s
	case dev2764_cmd:	// 27Cc64
	case dev2764s_cmd:	// 27Cc64s

	case dev28_cmd:		// 28C64
	case devFL1_cmd:	// 28F101
	case devFL2_cmd:	// 28F512
	case devFL3_cmd:	// 28F256
	case devFL4_cmd:	// 28F010
	case devFL5_cmd:	// 28F020

	case devFL8_cmd:	// 28F020a
	case devFL7_cmd:	// 29F010
	case devFL6_cmd:	// 29F040
		// verify array
		ea = vfy_fla(srt, end, (end-srt)>>4);
		if(pgm_stat & VFY_ERR){
			putssQ("!! VERIFY ERROR @addr: $");
			sprintf(ebuf, "%06X", ea);
			putssQ(ebuf);
			putsQ(" !!");
		}
		if(!pgm_stat){
			putsQ("Passed!");
		}
		break;
	}
	sram_close();											// init SRAM seq read
	return;
}

//=============================================================================
// blank_dut() blank-checks the DUT
//	if return address is less than end, there was an error at that address.
//=============================================================================
U32	blank_dut(U32 srt, U32 end, U8 check, U32 dotcnt, U8 hilo){
	U32	eaddr = srt;
	U32	dot_cntr = 0;
	U32	ii;
	U8	d;

	if(hilo == 1){
		putssQ("Vhi  [                ] Blank check");

	}else{
		if(hilo == 2){
			putssQ("     [                ] Blank check");
		}else{
			putssQ("Vlow [                ] Blank check");
		}
	}
	for(d=0; d<29; d++){
		putssQ("\b");
	}
	do{
		d = dataio(eaddr, 0, RD);
		if(dot_cntr++ == dotcnt){
			putssQ(".");
			dot_cntr = 0;
		}
	}while((++eaddr < end) && (d == check));
	if(eaddr < end){
		ii = eaddr;									// fill gas gauge with blanks
		while(ii++ < end){
			if(dot_cntr++ == dotcnt){
				putssQ("-");
				dot_cntr = 0;
			}
		}
		eaddr--;
		putsQ(" ]                    ");
	}else{
		if(hilo){
			putsQ(".] Done!              ");
		}else{
			putsQ(" ]                    ");
		}
	}
	return eaddr;
}

//=============================================================================
// era_fla() erases a FLASH device (such as the 28F101)
//=============================================================================
void	era_fla(U32 dotcnt){
	U32	eaddr = 0L;
	U32	dot_cntr = 0L;
	U16	i;
	volatile U8	d;
	volatile U8	c;
	volatile U8	j;

	gasg_srt();												// preset gas guage artifacts
	// write array to zeros ===================================
	do{
		put_addr(eaddr);									// preset addr
//		fast_write(RD_101);
//		if(dataio(eaddr, 0, RD) != 0){
			i=0;
			do{
				c = ~fast_read();							// get inverse of current mem location
				if(c != 0xff){
					d = fast_pgm_vfy(c);					// only write 1's to 0, prevent's over-write of 0's)
				}
			}while((++i<25) && (d != 0x00) && (c != 0xff));
			if(i>=25){
				pgm_stat |= PGM_ERR;
			}
//		}
		if(dot_cntr++ == (dotcnt<<1)){
			putssQ(".");
			dot_cntr = 0;
		}
		if(bchar == ESC) pgm_stat |= ESC_ERR;
	}while((++eaddr < device_maxaddr) && !(pgm_stat));
	// perform erase ===========================================
	putssQ("|");
	dot_cntr = 0L;
	eaddr = 0L;
	wait(1);
	i = 0;
	put_addr(eaddr);										// set addr
	do{
		fast_write(ERA_101);								// erase setup
		fast_write(ERA_101);
		wait(10);											// 10ms delay
		do{
			fast_write(ERAV_101);							// erase vfy
			wait_lat(DLY_6US);								// 10us delay
			d = fast_read();								// read array
			if(d == 0xff){
				eaddr += 1;
				put_addr(eaddr);							// set next addr
			}
			if(dot_cntr++ == (dotcnt<<1)){					// process gas-gauge
				putssQ(".");
				dot_cntr = 0;
			}
			if(bchar == ESC){								// look for abort
				eaddr = device_maxaddr;
				pgm_stat |= ESC_ERR;
			}
		}while((d == 0xff) && (eaddr < device_maxaddr));	// loop until err data or done
	}while((d != 0xff) && (eaddr < device_maxaddr) && (++i < 1000));
	if(i>=1000){
		pgm_stat |= ERA_ERR;								// set error status
	}
	fast_write(RD_101);
	putssQ("] \n");
	return;
}

//=============================================================================
// era_fla9() erases a FLASH device (such as the 29F040)
//=============================================================================
void	era_fla9(U32 dotcnt){
	U32	eaddr = 0L;
	U32	dot_cntr = 0L;
	U16	i;
	volatile U8	d;
	volatile U8	j;

	gasg_srt();												// preset gas guage artifacts
	// write array to zeros ==================================
	do{
		put_addr(eaddr);									// preset addr
//		fast_write(RD_101);
//		if(dataio(eaddr, 0, RD) != 0){
			i=0;
			do{
				d = ~fast_read();							// get inverse of current mem location
				d = fast_pgm_vfy(d);						// send it back (write 1's to 0, prevent's over-write of 0's)
			}while((++i<25) && (d != 0x00));
			if(i>=25){
				pgm_stat |= PGM_ERR;
			}
//		}
		if(dot_cntr++ == (dotcnt<<1)){
			putssQ(".");
			dot_cntr = 0;
		}
		if(bchar == ESC) pgm_stat |= ESC_ERR;
	}while((++eaddr < device_maxaddr) && !(pgm_stat));
	// perform erase ==========================================
	putssQ("|");
	dot_cntr = 0L;
	eaddr = 0L;
	wait(1);
	i = 0;
	put_addr(eaddr);										// set addr
	do{
		fast_write(ERA_101);								// erase setup
		fast_write(ERA_101);
		wait(10);											// 10ms delay
		do{
			fast_write(ERAV_101);							// erase vfy
			wait_lat(DLY_10US);								// 10us delay
			d = fast_read();								// read array
			if(d == 0xff){
				eaddr += 1;
				put_addr(eaddr);							// set next addr
			}
			if(dot_cntr++ == (dotcnt<<1)){					// process gas-gauge
				putssQ(".");
				dot_cntr = 0;
			}
			if(bchar == ESC){								// look for abort
				eaddr = device_maxaddr;
				pgm_stat |= ESC_ERR;
			}
		}while((d == 0xff) && (eaddr < device_maxaddr));	// loop until err data or done
	}while((d != 0xff) && (eaddr < device_maxaddr) && (++i < 1000));
	if(i>=1000){
		pgm_stat |= ERA_ERR;								// set error status
	}
	fast_write(RD_101);
	putssQ("] \n");
	return;
}

//=============================================================================
// pgm_fla() programs a FLASH device (such as the 28C101) from sram
//=============================================================================
void	pgm_fla(U32 end, U32 dotcnt){
	U32	eaddr = 0L;
	U32	dot_cntr = 0L;
	U8	i;
	volatile U8	d;
	volatile U8	e;

	gasg_srt();
	vppf(1);											// turn on FLASH Vpp
	fast_write(RST_101);
	fast_write(RST_101);
	fast_write(RD_101);
	// write array from sram
	do{
		d = sram_read(eaddr);
		if(d != 0xff){
			put_addr(eaddr);							// set addr
			i=0;
			do{
				e = fast_pgm_vfy(d);
			}while((++i<25) && (e != d));
			if(i>=25){
				pgm_stat |= PGM_ERR;
			}
		}
		if(dot_cntr++ == dotcnt){
			putssQ(".");
			dot_cntr = 0;
		}
	}while((++eaddr < end) && !(pgm_stat & PGM_ERR));
	fast_write(RD_101);
	vppf(0);											// turn off FLASH Vpp
	putssQ("] ");
	return;
}

//=============================================================================
// vfy_fla() programs a FLASH device (such as the 28C101) from sram
//=============================================================================
U32	vfy_fla(U32 srt, U32 end, U32 dotcnt){
	U32	vaddr = srt;
	U32	dot_cntr = 0L;
	U8	d;
	U8	e;

	gasg_srt();
	// write array from sram
	do{
		d = sram_read(vaddr);
		e = dataio(vaddr, 0, RD);
		if(e != d) pgm_stat |= VFY_ERR;
		if(dot_cntr++ == dotcnt){
			putssQ(".");
			dot_cntr = 0;
		}
	}while((++vaddr < end) && !(pgm_stat & VFY_ERR));
	putssQ("] ");
	return vaddr-1;
}

//=============================================================================
// smartwatch_unlock() unlocks smartwatch device
//=============================================================================
U8	sw_key[] = { 0xc5, 0x3a, 0xa3, 0x5c, 0xc5, 0x3a, 0xa3, 0x5c };

void	smartwatch_unlock(U8 type){
	volatile U8	j;

	for(j=0; j<sizeof(sw_key); j++){
		smart_write(sw_key[j], type);
	}
	return;
}

//=============================================================================
// smart_write() writes a byte to a smartwatch device
//	type == "0x0c" is the "C" device, else the "E" device is accessed
//=============================================================================
void	smart_write(U8 d, U8 type){
	volatile U8	i;

	for(i=0x01; i!=0; i<<=1){
		if(type == SMWA_C){
			ds1216c_bit(i & d, 1);
		}else{
			ds1216e_bit(i & d, 1);
		}
	}
	return;
}

//=============================================================================
// smart_read() reads a byte from a smartwatch device
//	type == "0x0c" is the "C" device, else the "E" device is accessed
//=============================================================================
U8	smart_read(U8 type){
	volatile U8	i;
	U8	j;
	U8	d=0;

	for(i=0x01; i!=0; i<<=1){
		if(type == SMWA_C){
			j = ds1216c_bit(0,0);
		}else{
			j = ds1216e_bit(0,0);
		}
		if(j) d |= i;
	}
	return d;
}


//=============================================================================
// gasg_srt() posts initial gas gauge artifacts to terminal
//=============================================================================
void	gasg_srt(void){
	U8	d;

	putssQ("[                ] ");
	for(d=0; d<18; d++){
		putssQ("\b");
	}
	return;
}

//=============================================================================
// dump_mem() displays SRAM memory in hexdump format
//	dut = 1, accesses dut, else access SRAM
//=============================================================================
void dump_mem(U32 addrb, U32 addre, U8 dut, char* obuf){
	U8	j;
	U8	data[16];
	U8	d;
	U32	ii = addrb;
	U16	crcsum = 0;

	j = 255;
	if(dut){
		do{
			if((j==0)||(j>LINELEN)){
				if(j==0){
					dump_str(data);
				}
				sprintf(obuf,"\n%05x: ", ii);
				putssQ(obuf);
				j = LINELEN;
			}
			d = dataio(ii, 0, RD);
			data[LINELEN-j] = d;
			crcsum = calcrc(d, crcsum, XPOLY);			// update crcsum
			sprintf(obuf,"%02x ", d);
			putssQ(obuf);
			ii += 1;
			j -= 1;
		}while((ii != addre) && (bchar != ESC));
		dump_str(data);
	}else{
		sram_read_start(addrb);
		do{
			if((j==0)||(j>LINELEN)){
				if(j==0){
					dump_str(data);
				}
				sprintf(obuf,"\n%05x: ", ii);
				putssQ(obuf);
				j = LINELEN;
			}
			d = sram_read(ii);
			data[LINELEN-j] = d;
			crcsum = calcrc(d, crcsum, XPOLY);			// update crcsum
			sprintf(obuf,"%02x ", d);
			putssQ(obuf);
			ii += 1;
			j -= 1;
		}while((ii != addre) && (bchar != ESC));
		dump_str(data);
		sram_close();
	}
	if(bchar == ESC){
		putssQ("\n!! ABORTED !!\n");
	}else{
		sprintf(obuf,"\nCRC16: $%04x\n", crcsum);
		putssQ(obuf);
	}
	return;
}
/*
for(i=XM_DATASTART;i<XM_DATAEND;i++){
	if(xcrc){
		checksum = calcrc(xmbuf[i], checksum, XPOLY); // if crc, update crcsum
	}else{
		checksum += (U16)xmbuf[i]; // else do checksum
		checksum &= 0xff;
	}
}*/

void	dump_str(U8* data){
	U8		i;
	char	c;

	putssQ("    ");
	for(i=0; i<LINELEN; i++){
		c = (char)data[i];
		if((c < ' ') || (c > '~')) c = '.';
		putcharQ(c);
	}
	return;
}


//=============================================================================
// copy_dut() reads DUT into SRAM
//=============================================================================
void copy_dut(U32 addrb, U32 addre){
	U8	d;
	U32	ii = addrb;

	sram_write_start(addrb);
	do{
		d = dataio(ii, 0, RD);
		sram_write(ii, d);
		ii += 1;
	}while((ii != addre) && (bchar != ESC));
	sram_close();
	return;
}

//-----------------------------------------------------------------------------
// calcrc() calculates incremental crcsum using supplied poly
//	(xmodem poly = 0x1021)
//-----------------------------------------------------------------------------
U16 calcrc(U8 c, U16 oldcrc, U16 poly){

	U16 crc;
	U8	i;

	crc = oldcrc ^ ((U16)c << 8);
	for (i = 0; i < 8; ++i){
		if (crc & 0x8000) crc = (crc << 1) ^ poly;
		else crc = crc << 1;
	 }
	 return crc;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// process_CMD() handles periodic polling tasks for the cmd_fn.c file scope
//-----------------------------------------------------------------------------

char process_CMD(U8 flag){

	if(flag == PROC_INIT){
		// init file-local statics
		return 0;
	}
	return 0;
}

//=============================================================================
// get BCD param from string
//=============================================================================
void get_BCD32(char *sptr, U32 *bcdval){

	char*	s = sptr;

	*bcdval = 0;
	while(*s){
		*bcdval <<= 4;
		*bcdval |= asc_hex(*s++);
	}
	return;
}

//=============================================================================
// get numeric params from command line args
//	argsrt specifies the first item to be searched and aligns argsrt with params[0]
//	for multi-arg cmds, fields must be entered in order.
//=============================================================================
U8 get_Dargs(U8 argsrt, U8 nargs, char* args[ARG_MAX], U32 params[8]){

	char*	s;
	U32*	ptr1;
	S32		temp32;
	U8		i;
	U8		count = 0;
	U8		neg;			// negation flag

	if(argsrt < nargs){											// test for start in limit (abort if not)
		for(i = argsrt; i < nargs; i++){						// convert strings to values
			neg = 0;
			s = args[i];										// set pointers to array items
			ptr1 = &params[i - argsrt];
			if((*s == '-') && (*(s+1) != '\0')){
				neg = 1;
				*s++;
			}
			switch(*s){
				case '-':										// skip if user specified default
				case '\0':										// or if arg is empty
					break;

				default:
					count += sscanf(s,"%d",&temp32);			// get decimal value
					if(neg) temp32 *= -1;						// negate
					*ptr1 = (U32)temp32;
					break;

				case '$':
					s++;
					count += sscanf(s,"%x",&temp32);			// get hex if leading "$"
					if(neg) temp32 = ~temp32 + 1;				// negate
					*ptr1 = temp32;
					break;

				case 'O':
				case 'o':
					s++;
					count += sscanf(s,"%o",&temp32);			// get octal if leading "O"
					if(neg) temp32 = ~temp32 + 1;				// negate
					*ptr1 = temp32;
					break;
			}
		}
	}
	return count;
}

//=============================================================================
// search for command keywords, return cmd ID if found
//	uses the cmd_list[] array which is constructed as an array of null terminated
//	strings compressed into a single string definition.  Commands are added by
//	placing the minimum required text from the command name with a '\0' terminating
//	null.  cmd_list[] is terminated by an $ff after all of the command names.
//	cmd_enum{} holds an enumerated, named list of all valid commands.  The enum
//	definition must be at the top of this file, so the commented-out version shown
//	below must be copied and pasted to the top of the file whan any changes are
//	made (commands added or deleted).
//
//	Some thought must be put into the order of command names.  Shorter matching
//	names (e.g., single chr entries) must follow longer names to allow the algortihm
//	to properly trap the shorter cmd name.
//	
//=============================================================================
cmd_type cmd_srch(char* string){
// dummy end of list, used to break out of search loop
const char end_list[] = {0xff};
// list of minimum length command words. cmd words are separated by '\0' and list terminated with 0xff
//const char cmd_list[] = {"H\0K\0A\0D\0L\0P\0E\0U\0S\0TI\0T\0?\0H\0VERS\0\xff"};
//enum cmd_enum{ hm_data,kp_data,adc_tst,log_data,tst_pwm,tst_enc,tstuart1,timer_tst,tst_tempa,help1,help2,vers,lastcmd,helpcmd };
//!!! make changes to cmd_enum here, move them to top of file, then un-comment !!!

	char*	ptr;							// temp ptr
	char	cmdid = 0;						// start at beginning of cmd_enum
	char	i;								// temp
	char	found = FALSE;					// cmd found flag (default to not found)

	ptr = cmd_list[cmdid];										// start at beginning of search list
	while((*ptr & 0x80) != 0x80){								// process until 0xff found in search list
		i = strncmp(string, ptr, strlen(ptr));					// inbound string match search list?
		if(i){
			cmdid++;											// no, advance to next cmdid
			ptr = cmd_list[cmdid];
//			while(*ptr++);										// skip to next item in search list
		}else{
			ptr = (char*)end_list;								// found match,
			found = TRUE;										// set break-out criteria
		}
	}
	if(!found) cmdid = lastcmd;									// not found, set error cmd id
	return cmdid;
}

/*	char*	ptr;							// temp ptr
	char	cmdid = 0;						// start at beginning of cmd_enum
	char	i;								// temp
	char	found = FALSE;					// cmd found flag (default to not found)

	ptr = (char*)cmd_list;										// start at beginning of search list
	while((*ptr & 0x80) != 0x80){								// process until 0xff found in search list
		i = strncmp(string, ptr, strlen(ptr));					// inbound string match search list?
		if(i){
			cmdid++;											// no, advance to next cmdid 
			while(*ptr++);										// skip to next item in search list
		}else{
			ptr = (char*)end_list;										// found match,
			found = TRUE;										// set break-out criteria
		}
	}
	if(!found) cmdid = lastcmd;									// not found, set error cmd id
	return cmdid;
}*/

//=============================================================================
// parm_srch() looks for a match of parm_str in any non-empty args[] strings
//	if found, remove the args entry from param list and return 1st chr of parm_str,
//	else return '\0'
//=============================================================================
char parm_srch(U8 nargs, char* args[ARG_MAX], char* parm_str){

	U8		i;								// counter temp
	char	c = '\0';						// first chr of matched parm_str (first time thru loop, there is no match)
	static char null_str[] = "";			// null string that persists

//	if(nargs > 1){
	    for(i = 1; i <= nargs; i++){							// search starting with first args[] item
			if(c){												// if(c!=null)...
				args[i] = args[i+1];							// if there was a match, move the subsequent pointers down one
			}else{
				if(strlen(parm_str) == strlen(args[i])){		// in order to match, the lengths have to be equal...
					if(strncmp(args[i], parm_str, strlen(parm_str)) == 0){ // look for match
						c = *parm_str;							// if match, capture 1st chr in matched string
						i--;									// back-up one to edit this item out of the list
					}
				}
			}
	    }
//	}
 	if(c != '\0'){
		args[ARG_MAX - 1] = null_str;							// if there was a match, the last pointer goes to null
		
	}
	return c;													// return first chr in matched string, or null if no match
}

//=============================================================================
// disp_esc() if param true, display "Press esc to exit" msg
//=============================================================================
void disp_esc(char flag){

	if(flag){
		putsQ("  Press <ESC> to exit.");
	}
	putsQ("");
}

//=============================================================================
// convert all chrs in string to upper case
//=============================================================================
void str_toupper(char *string){

    while(*string != '\0'){
        *string++ = toupper(*string);
    }
}

//=============================================================================
// parse command line array for delimited arguments.  Called prior to entry into x_cmdfn().
//  on exit, the args[] array (an array of char pointers) holds each delimited argument
//	from the command string input:
//  args[0] holds first arg (the command token)
//  args[1] holds next arg
//  args[2] etc...
//  up to args[ARG_MAX]
//
//  nargs holds number of arguments collected.  i.e., nargs = 3 specifies that args[0] .. args[3]
//      all hold arguments (three total, including the command).
//=============================================================================
int parse_args(char* cmd_string, char* args[ARG_MAX]){
	int i;
	char quote_c = 0;
	static char null_string[2] = "";

    // clear args pointers
    for (i=0; i<ARG_MAX; i++){
        args[i] = null_string;
    }
    i = 0;
    do{
        if(quotespace(*cmd_string, 0)){         // process quotes until end quote or end of string
            quote_c = *cmd_string;              // close quote must = open quote
            args[i++] = ++cmd_string;               // start args with 1st char after quote
            while(!quotespace(*cmd_string,quote_c)){
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                cmd_string++;
            }
            *cmd_string++ = '\0';               // replace end quote with null
        }
        if(*cmd_string == '\0'){
            return i;                           // end of cmd string, exit
        }
        if(!whitespace(*cmd_string)){
            args[i++] = cmd_string++;			// when non-whitespace encountered, assign arg[] pointer
            if(i > ARG_MAX){
                return i;						// until all args used up
            }
            do{
                if(*cmd_string == '\0'){
                    return i;                   // end of cmd string, exit
                }
                if(whitespace(*cmd_string)){
                    *cmd_string = '\0';			// then look for next whitespace and delimit (terminate) the arg[] string
                    break;
                }
                cmd_string++;					// loop until end of cmd_string or next whitespace
            } while (1);
        }
        cmd_string++;							// loop...
    } while (1);
    // no return here, we'll never get here anyway...
}

//=============================================================================
// parse_ehex() for embeded hex ($$) arguments
//  on exit, the string holds the original text with %xx replaced by a single
//	hex byte.
//=============================================================================
void parse_ehex(char * sptr){
	char* tptr;
	U8	i;

	while(*sptr){
		if((*sptr == '$') && (*(sptr+1) == '$')){
			i = asc_hex(*(sptr+2)) << 4;
			i |= asc_hex(*(sptr+3));
			*sptr++ = i;
			tptr = sptr;
			do{
				*tptr = *(tptr+3);
				tptr++;
			}while(*(tptr+2));
		}else{
			sptr++;
		}
	}
}
//=============================================================================
// test characer for whitespace
//=============================================================================
int whitespace(char c){

    switch (c){					// These are all valid whitespace:
        case '\n':          	// newline
        case '\r':          	// cr
        case '\t':          	// tab
        case 0x20:{         	// space
		case '/':				// slash is also wsp
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// test characer for quote
//=============================================================================
int quotespace(char c, char qu_c){

    if(qu_c == '\0'){
        switch (c){				// if qu_c is null, these are valid quotes:
            case '\'':          // single
            case '\"':          // double
            case '\t':          // tab
                return TRUE;
            }
    } else {
        if(c == qu_c){			// else, only qu_c results in a TRUE match
            return TRUE;
        }
    }
    return FALSE;
}

//=============================================================================
// gas_gage() display up to 16 "*" chrs based on count rate.
//	Gauge appearance:
//	[****************]	all OK
//	[***.............]	errors detected
//
//	"len" cmds:
//	0: process gauge counter/display
//	1: set gauge error character = "."
//	2: disable gage counter/display (set clen = 0)
//	all others: set creset = count = len/16, display initial gauge characters
//	This calculation identifies how many bytes are in 1/16th of the total
//	byte count (len).  For count events (len == 0), this Fn decrements count, &
//	displays a gauge chr when count == 0.  count is then reloaded with creset.
//	process continues until 16 gauge chrs have been displayed.  After this,
//	any further count events result in no further change to the display.
//=============================================================================
U8 gas_gage(U16 len){

#define LENCMD_MAX 2		// max # of gas-gage() cmds

	static U16	creset;		// holding reg for data counter reset value
	static U16	count;		// data counter
	static U8	clen;		// gage chr counter
	static U8	gchr;		// gage chr storage
		   U8	c = 0;		// gage printed flag

	if(len <= LENCMD_MAX){
		if(!len && clen){
			if(--count == 0){ 
				putchar(gchr);					// disp gage chr
				count = creset;					// reset loop counters
				clen--;
				if(clen == 0) putchar(']');		// if end of gage, print end bracket
				c = 1;
			}
		}else{
			if(len == 1) gchr = '.';			// if error flag, change gauge chr to err mode
			if(len == 2) clen = 0;				// disable gauge
		}
	}else{
		creset = count = len >> 4;				// init count & count reset (creset) = len/16
		if(creset == 0) creset = 1;				// if overall length too short, set 1:1
		clen = 16;								// 16 gage chrs max
		gchr = '*';								// set * as gage chr
		putchar('[');							// print start bracket
		for(c = 0; c < 16; c++) putchar(' ');
		putchar(']');							// place end bracket for scale
		for(c = 0; c < 17; c++) putchar('\b');	// backspace to start of scale
		c = 1;
	}
	return c;
}

//=============================================================================
// log_error_byte() places error data into log buffer.  Log format is:
//	(device) (host) (addrH) (addrL).  Called by target verify fns to allow
//	a limited number of errors to be trapped (limit is the buffer used to
//	hold the error log).
//	returns updated pointer to next available log entry
//=============================================================================
U8* log_error_byte(U8* lbuf, U8 d, U8 h, U16 a){

	*lbuf++ = d;								// store device data
	*lbuf++ = h;								// store host data
	*lbuf++ = (U8)(a >> 8);						// store addr
	*lbuf++ = (U8)(a & 0xff);
	return lbuf;								// return updated pointer
}

//=============================================================================
// disp_error_log() displays errors logged into error string.  Log format is:
//	(device) (host) (addrH) (addrL)
//	Display format is:
//	nn: Dev ($xx) != $xx @$xxxx\n = 28 printed chrs
//	nn = err number (ordinal)
//	xx = data bytes
//	xxxx = error address
//=============================================================================
void disp_error_log(U8* lbuf, U16 len){

	char obuf[32];				// local buffer
	// use U16 type to simplify sprintf variable list
	U16  i;						// loop counter
	U16  d;						// device data
	U16  h;						// host data
	U16  a;						// addr

	len++;										// add 1 to end so that we can start loop at "1"
	for(i = 1; i < len; i++){					// loop from 1 to len+1 entries
		d = (U16)*lbuf++ & 0xff;				// format device data
		h = (U16)*lbuf++ & 0xff;				// format host data
		a = ((U16)*lbuf++ & 0xff) << 8;			// format addr
		a |= (U16)*lbuf++ & 0xff;
		sprintf(obuf,"%02u: Dev ($%02x) != $%02x @$%04x", i, d, h, a); // display err line
		putsQ(obuf);
	}
}

//=============================================================================
// bcmd_resp_init() inits bcmd_resp_ptr
//=============================================================================
void bcmd_resp_init(void){

	bcmd_resp_ptr = bcmd_resp_buf;
	*bcmd_resp_ptr = '\0';
}

//=============================================================================
// asc_hex() converts ascii chr to 4-bit hex.  Returns 0xff if error
//=============================================================================
U8 asc_hex(S8 c){

	U8 i;

	if((c >= 'a') && (c <= 'f')) c = c - ('a' - 'A');	// upcase
	if((c >= '0') && (c <= '9')){			// if decimal digit,
		i = (U8)(c - '0');					// subtract ASCII '0' to get hex nybble
	}else{
		if((c >= 'A') && (c <= 'F')){		// if hex digit,
			i = (U8)(c - 'A' + 0x0A);		// subtract ASCII 'A', then add 0x0A to get hex nybble
		}else{
			i = 0xff;						// if not valid hex digit, set error return
		}
	}
	return i;	
}

//=============================================================================
// temp_float() converts MCP9800 binary temp to a float (degrees C)
//=============================================================================
float temp_float(U16 k){
	U8		i;			// temp
	U8		j = 0;		// temp sign
	float	fa;			// temp float

	if(k & 0x8000){												// if negative,
		j = 1;													// preserve sign and
		k = ~k + 1;												// convert value to positive
	}
	i = k >> 8;													// get integer portion
	fa = (float)i;												// convert to float
	if(k & 0x0080) fa += 0.5;									// add fractional portion
	if(k & 0x0040) fa += 0.25;
	if(k & 0x0020) fa += 0.125;
	if(k & 0x0010) fa += 0.0625;
	if(j){														// if negative, convert
		fa *= -1;
	}
	return fa;
}


//=============================================================================
// walkabt() writes a walking 1's, 0's, or both pattern to the SRAM
//	Assumes that an SRAM open function call has been previously executed and
//	SRAM close must be called when the pattern is complete.
//	type = 0x00 for 0's, 0x01 for 1's, or 0x0A (d10) for both
//	width = 8, 16, or 32 (bits)
// Writes a single complete pattern sequence but stops once the end address
//	is surpassed.
// Returns next possible address to calling loop
//=============================================================================
U32 walkabt(U32 srt, U32 end, U8 type, U8 width){
	U8	i;
	U32	dd;

	if((type == 0) || (type == 10)){
		// walking 0's first:
		i = 0;
		dd=0xFFFFFFFEL;
		while((srt < end) && !(i>width+1)){
			if(i == 0){
				srt = swrite(srt, 0xFFFFFFFFL, width);
				i++;
			}else{
				srt = swrite(srt, dd, width);
				dd = (dd<<1) | 1L;
			}
			i++;
		}
	}
	if((type == 1) || (type == 10)){
		// walking 1's next:
		i = 0;
		dd=0x1L;
		while((srt < end) && !(i>width+1)){
			if(i == 0){
				srt = swrite(srt, 0x0L, width);
				i++;
			}else{
				srt = swrite(srt, dd, width);
				dd = (dd<<1);
			}
			i++;
		}
	}
	return srt;
}

char	spin_ary[] = { "|/-\\" };
#define	SPIN_LEN	3

//=============================================================================
// put_spin() displays next step in the console spin-wheel status display
//	init == 0xff is init cmd
//	else, init = 1 if verbose, otherwise 0
//=============================================================================
void put_spin(U8 init){
static	U8	indx;

	if(init == 0xff){
		indx = 0;
	}else{
		put_dot(spin_ary[indx], init);				// status dot
		if(++indx > SPIN_LEN) indx = 0;

	}
	return;
}

// eof
